cd ..
exec ./edit.sh $@
