cd ..
exec ./run.sh $@
