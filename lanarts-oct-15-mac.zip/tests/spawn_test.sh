cd ..
exec ./spawn_test.sh $@
