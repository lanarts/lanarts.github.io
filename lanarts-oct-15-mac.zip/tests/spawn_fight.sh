cd ..
exec ./spawn_fight.sh $@
