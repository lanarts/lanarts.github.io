In this folder are the compiled assets that are taken from the raw spr_* folders. 
Lua files that call Lanarts functions are generated, as this is the most flexible format for representing game data.
These Lua files set up the sprite data for Lanarts.
