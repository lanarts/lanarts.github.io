local Display = require 'core.Display'
local M = nilprotect {}
-- spr_books resource loads:
M['spr_books.book_of_the_dead'] = Display.image_load 'spr_books/book_of_the_dead.png'
yield_point()
M['spr_books.bronze'] = Display.image_load 'spr_books/bronze.png'
yield_point()
M['spr_books.cloth'] = Display.image_load 'spr_books/cloth.png'
yield_point()
M['spr_books.copper'] = Display.image_load 'spr_books/copper.png'
yield_point()
M['spr_books.cyan'] = Display.image_load 'spr_books/cyan.png'
yield_point()
M['spr_books.dark_blue'] = Display.image_load 'spr_books/dark_blue.png'
yield_point()
M['spr_books.dark_brown'] = Display.image_load 'spr_books/dark_brown.png'
yield_point()
M['spr_books.dark_gray'] = Display.image_load 'spr_books/dark_gray.png'
yield_point()
M['spr_books.dark_green'] = Display.image_load 'spr_books/dark_green.png'
yield_point()
M['spr_books.gold'] = Display.image_load 'spr_books/gold.png'
yield_point()
M['spr_books.leather'] = Display.image_load 'spr_books/leather.png'
yield_point()
M['spr_books.light_blue'] = Display.image_load 'spr_books/light_blue.png'
yield_point()
M['spr_books.light_brown'] = Display.image_load 'spr_books/light_brown.png'
yield_point()
M['spr_books.light_gray'] = Display.image_load 'spr_books/light_gray.png'
yield_point()
M['spr_books.light_green'] = Display.image_load 'spr_books/light_green.png'
yield_point()
M['spr_books.magenta'] = Display.image_load 'spr_books/magenta.png'
yield_point()
M['spr_books.manual1'] = Display.image_load 'spr_books/manual1.png'
yield_point()
M['spr_books.manual2'] = Display.image_load 'spr_books/manual2.png'
yield_point()
M['spr_books.metal_blue'] = Display.image_load 'spr_books/metal_blue.png'
yield_point()
M['spr_books.metal_cyan'] = Display.image_load 'spr_books/metal_cyan.png'
yield_point()
M['spr_books.metal_green'] = Display.image_load 'spr_books/metal_green.png'
yield_point()
M['spr_books.parchment'] = Display.image_load 'spr_books/parchment.png'
yield_point()
M['spr_books.pink'] = Display.image_load 'spr_books/pink.png'
yield_point()
M['spr_books.plaid'] = Display.image_load 'spr_books/plaid.png'
yield_point()
M['spr_books.purple'] = Display.image_load 'spr_books/purple.png'
yield_point()
M['spr_books.red'] = Display.image_load 'spr_books/red.png'
yield_point()
M['spr_books.silver'] = Display.image_load 'spr_books/silver.png'
yield_point()
M['spr_books.tan'] = Display.image_load 'spr_books/tan.png'
yield_point()
M['spr_books.turquoise'] = Display.image_load 'spr_books/turquoise.png'
yield_point()
M['spr_books.white'] = Display.image_load 'spr_books/white.png'
yield_point()
M['spr_books.yellow'] = Display.image_load 'spr_books/yellow.png'
yield_point()

-- spr_classes resource loads:
M['spr_classes.black_mage1'] = Display.image_load 'spr_classes/black_mage1.png'
yield_point()
M['spr_classes.black_mage2'] = Display.image_load 'spr_classes/black_mage2.png'
yield_point()
M['spr_classes.blue_mage1'] = Display.image_load 'spr_classes/blue_mage1.png'
yield_point()
M['spr_classes.blue_mage2'] = Display.image_load 'spr_classes/blue_mage2.png'
yield_point()
M['spr_classes.green_mage1'] = Display.image_load 'spr_classes/green_mage1.png'
yield_point()
M['spr_classes.green_mage2'] = Display.image_load 'spr_classes/green_mage2.png'
yield_point()
M['spr_classes.red_mage1'] = Display.image_load 'spr_classes/red_mage1.png'
yield_point()
M['spr_classes.red_mage2'] = Display.image_load 'spr_classes/red_mage2.png'
yield_point()
M['spr_classes.rogue1'] = Display.image_load 'spr_classes/rogue1.png'
yield_point()
M['spr_classes.rogue2'] = Display.image_load 'spr_classes/rogue2.png'
yield_point()
M['spr_classes.white_mage1'] = Display.image_load 'spr_classes/white_mage1.png'
yield_point()
M['spr_classes.white_mage2'] = Display.image_load 'spr_classes/white_mage2.png'
yield_point()

-- spr_classes/icons resource loads:
M['spr_classes.icons.archer'] = Display.image_load 'spr_classes/icons/archer.png'
yield_point()
M['spr_classes.icons.blackmage'] = Display.image_load 'spr_classes/icons/blackmage.png'
yield_point()
M['spr_classes.icons.bluemage'] = Display.image_load 'spr_classes/icons/bluemage.png'
yield_point()
M['spr_classes.icons.druid'] = Display.image_load 'spr_classes/icons/druid.png'
yield_point()
M['spr_classes.icons.fighter'] = Display.image_load 'spr_classes/icons/fighter.png'
yield_point()
M['spr_classes.icons.greenmage'] = Display.image_load 'spr_classes/icons/greenmage.png'
yield_point()
M['spr_classes.icons.lifelinker'] = Display.image_load 'spr_classes/icons/lifelinker.png'
yield_point()
M['spr_classes.icons.necromancer'] = Display.image_load 'spr_classes/icons/necromancer.png'
yield_point()
M['spr_classes.icons.redmage'] = Display.image_load 'spr_classes/icons/redmage.png'
yield_point()
M['spr_classes.icons.rogue'] = Display.image_load 'spr_classes/icons/rogue.png'
yield_point()
M['spr_classes.icons.whitemage'] = Display.image_load 'spr_classes/icons/whitemage.png'
yield_point()

-- spr_doors resource loads:
M['spr_doors.closed_door'] = Display.image_load 'spr_doors/closed_door.png'
yield_point()
M['spr_doors.closed_door_crypt'] = Display.image_load 'spr_doors/closed_door_crypt.png'
yield_point()
M['spr_doors.fleshy_orifice_closed'] = Display.image_load 'spr_doors/fleshy_orifice_closed.png'
yield_point()
M['spr_doors.fleshy_orifice_open'] = Display.image_load 'spr_doors/fleshy_orifice_open.png'
yield_point()
M['spr_doors.gate_closed_left'] = Display.image_load 'spr_doors/gate_closed_left.png'
yield_point()
M['spr_doors.gate_closed_left_crypt'] = Display.image_load 'spr_doors/gate_closed_left_crypt.png'
yield_point()
M['spr_doors.gate_closed_middle'] = Display.image_load 'spr_doors/gate_closed_middle.png'
yield_point()
M['spr_doors.gate_closed_middle_crypt'] = Display.image_load 'spr_doors/gate_closed_middle_crypt.png'
yield_point()
M['spr_doors.gate_closed_right'] = Display.image_load 'spr_doors/gate_closed_right.png'
yield_point()
M['spr_doors.gate_closed_right_crypt'] = Display.image_load 'spr_doors/gate_closed_right_crypt.png'
yield_point()
M['spr_doors.gate_open_left'] = Display.image_load 'spr_doors/gate_open_left.png'
yield_point()
M['spr_doors.gate_open_left_crypt'] = Display.image_load 'spr_doors/gate_open_left_crypt.png'
yield_point()
M['spr_doors.gate_open_middle'] = Display.image_load 'spr_doors/gate_open_middle.png'
yield_point()
M['spr_doors.gate_open_middle_crypt'] = Display.image_load 'spr_doors/gate_open_middle_crypt.png'
yield_point()
M['spr_doors.gate_open_right'] = Display.image_load 'spr_doors/gate_open_right.png'
yield_point()
M['spr_doors.gate_open_right_crypt'] = Display.image_load 'spr_doors/gate_open_right_crypt.png'
yield_point()
M['spr_doors.gate_runed_left'] = Display.image_load 'spr_doors/gate_runed_left.png'
yield_point()
M['spr_doors.gate_runed_middle'] = Display.image_load 'spr_doors/gate_runed_middle.png'
yield_point()
M['spr_doors.gate_runed_right'] = Display.image_load 'spr_doors/gate_runed_right.png'
yield_point()
M['spr_doors.gate_sealed_left'] = Display.image_load 'spr_doors/gate_sealed_left.png'
yield_point()
M['spr_doors.gate_sealed_middle'] = Display.image_load 'spr_doors/gate_sealed_middle.png'
yield_point()
M['spr_doors.gate_sealed_right'] = Display.image_load 'spr_doors/gate_sealed_right.png'
yield_point()
M['spr_doors.healingsqr'] = Display.image_load 'spr_doors/healingsqr.png'
yield_point()
M['spr_doors.open_door'] = Display.image_load 'spr_doors/open_door.png'
yield_point()
M['spr_doors.open_door_crypt'] = Display.image_load 'spr_doors/open_door_crypt.png'
yield_point()
M['spr_doors.runed_door'] = Display.image_load 'spr_doors/runed_door.png'
yield_point()
M['spr_doors.sealed_door'] = Display.image_load 'spr_doors/sealed_door.png'
yield_point()
M['spr_doors.vgate_closed_down'] = Display.image_load 'spr_doors/vgate_closed_down.png'
yield_point()
M['spr_doors.vgate_closed_down_crypt'] = Display.image_load 'spr_doors/vgate_closed_down_crypt.png'
yield_point()
M['spr_doors.vgate_closed_middle'] = Display.image_load 'spr_doors/vgate_closed_middle.png'
yield_point()
M['spr_doors.vgate_closed_middle_crypt'] = Display.image_load 'spr_doors/vgate_closed_middle_crypt.png'
yield_point()
M['spr_doors.vgate_closed_up'] = Display.image_load 'spr_doors/vgate_closed_up.png'
yield_point()
M['spr_doors.vgate_closed_up_crypt'] = Display.image_load 'spr_doors/vgate_closed_up_crypt.png'
yield_point()
M['spr_doors.vgate_open_down'] = Display.image_load 'spr_doors/vgate_open_down.png'
yield_point()
M['spr_doors.vgate_open_down_crypt'] = Display.image_load 'spr_doors/vgate_open_down_crypt.png'
yield_point()
M['spr_doors.vgate_open_middle'] = Display.image_load 'spr_doors/vgate_open_middle.png'
yield_point()
M['spr_doors.vgate_open_middle_crypt'] = Display.image_load 'spr_doors/vgate_open_middle_crypt.png'
yield_point()
M['spr_doors.vgate_open_up'] = Display.image_load 'spr_doors/vgate_open_up.png'
yield_point()
M['spr_doors.vgate_open_up_crypt'] = Display.image_load 'spr_doors/vgate_open_up_crypt.png'
yield_point()
M['spr_doors.vgate_runed_down'] = Display.image_load 'spr_doors/vgate_runed_down.png'
yield_point()
M['spr_doors.vgate_runed_middle'] = Display.image_load 'spr_doors/vgate_runed_middle.png'
yield_point()
M['spr_doors.vgate_runed_up'] = Display.image_load 'spr_doors/vgate_runed_up.png'
yield_point()
M['spr_doors.vgate_sealed_down'] = Display.image_load 'spr_doors/vgate_sealed_down.png'
yield_point()
M['spr_doors.vgate_sealed_middle'] = Display.image_load 'spr_doors/vgate_sealed_middle.png'
yield_point()
M['spr_doors.vgate_sealed_up'] = Display.image_load 'spr_doors/vgate_sealed_up.png'
yield_point()

-- spr_keys resource loads:
M['spr_keys.door01'] = Display.image_load 'spr_keys/door01.png'
yield_point()
M['spr_keys.door02'] = Display.image_load 'spr_keys/door02.png'
yield_point()
M['spr_keys.door03'] = Display.image_load 'spr_keys/door03.png'
yield_point()
M['spr_keys.dragon_key'] = Display.image_load 'spr_keys/dragon_key.png'
yield_point()
M['spr_keys.key01'] = Display.image_load 'spr_keys/key01.png'
yield_point()
M['spr_keys.key02'] = Display.image_load 'spr_keys/key02.png'
yield_point()
M['spr_keys.key03'] = Display.image_load 'spr_keys/key03.png'
yield_point()
M['spr_keys.magentite_door'] = Display.image_load 'spr_keys/magentite_door.png'
yield_point()
M['spr_keys.magentite_key'] = Display.image_load 'spr_keys/magentite_key.png'
yield_point()

-- spr_rings resource loads:
M['spr_rings.abolishment'] = Display.image_load 'spr_rings/abolishment.png'
yield_point()
M['spr_rings.agate'] = Display.image_load 'spr_rings/agate.png'
yield_point()
M['spr_rings.big-skull-ring'] = Display.image_load 'spr_rings/big-skull-ring.png'
yield_point()
M['spr_rings.brass'] = Display.image_load 'spr_rings/brass.png'
yield_point()
M['spr_rings.bronze'] = Display.image_load 'spr_rings/bronze.png'
yield_point()
M['spr_rings.clay'] = Display.image_load 'spr_rings/clay.png'
yield_point()
M['spr_rings.copper'] = Display.image_load 'spr_rings/copper.png'
yield_point()
M['spr_rings.coral'] = Display.image_load 'spr_rings/coral.png'
yield_point()
M['spr_rings.diamond'] = Display.image_load 'spr_rings/diamond.png'
yield_point()
M['spr_rings.emerald'] = Display.image_load 'spr_rings/emerald.png'
yield_point()
M['spr_rings.ethereal'] = Display.image_load 'spr_rings/ethereal.png'
yield_point()
M['spr_rings.glass'] = Display.image_load 'spr_rings/glass.png'
yield_point()
M['spr_rings.gold'] = Display.image_load 'spr_rings/gold.png'
yield_point()
M['spr_rings.gold_blue'] = Display.image_load 'spr_rings/gold_blue.png'
yield_point()
M['spr_rings.gold_green'] = Display.image_load 'spr_rings/gold_green.png'
yield_point()
M['spr_rings.gold_red'] = Display.image_load 'spr_rings/gold_red.png'
yield_point()
M['spr_rings.granite'] = Display.image_load 'spr_rings/granite.png'
yield_point()
M['spr_rings.iron'] = Display.image_load 'spr_rings/iron.png'
yield_point()
M['spr_rings.ivory'] = Display.image_load 'spr_rings/ivory.png'
yield_point()
M['spr_rings.jade'] = Display.image_load 'spr_rings/jade.png'
yield_point()
M['spr_rings.moonstone'] = Display.image_load 'spr_rings/moonstone.png'
yield_point()
M['spr_rings.opal'] = Display.image_load 'spr_rings/opal.png'
yield_point()
M['spr_rings.pearl'] = Display.image_load 'spr_rings/pearl.png'
yield_point()
M['spr_rings.plain_black'] = Display.image_load 'spr_rings/plain_black.png'
yield_point()
M['spr_rings.plain_red'] = Display.image_load 'spr_rings/plain_red.png'
yield_point()
M['spr_rings.plain_yellow'] = Display.image_load 'spr_rings/plain_yellow.png'
yield_point()
M['spr_rings.ruby'] = Display.image_load 'spr_rings/ruby.png'
yield_point()
M['spr_rings.silver'] = Display.image_load 'spr_rings/silver.png'
yield_point()
M['spr_rings.steel'] = Display.image_load 'spr_rings/steel.png'
yield_point()
M['spr_rings.tiger_eye'] = Display.image_load 'spr_rings/tiger_eye.png'
yield_point()
M['spr_rings.tourmaline'] = Display.image_load 'spr_rings/tourmaline.png'
yield_point()
M['spr_rings.vampirism'] = Display.image_load 'spr_rings/vampirism.png'
yield_point()
M['spr_rings.wizardsring'] = Display.image_load 'spr_rings/wizardsring.png'
yield_point()
M['spr_rings.wooden'] = Display.image_load 'spr_rings/wooden.png'
yield_point()

-- spr_weapons resource loads:
M['spr_weapons.arbalest1'] = Display.image_load 'spr_weapons/arbalest1.png'
yield_point()
M['spr_weapons.arbalest2'] = Display.image_load 'spr_weapons/arbalest2.png'
yield_point()
M['spr_weapons.arbalest3'] = Display.image_load 'spr_weapons/arbalest3.png'
yield_point()
M['spr_weapons.arrow1'] = Display.image_load 'spr_weapons/arrow1.png'
yield_point()
M['spr_weapons.arrow2'] = Display.image_load 'spr_weapons/arrow2.png'
yield_point()
M['spr_weapons.bardiche1'] = Display.image_load 'spr_weapons/bardiche1.png'
yield_point()
M['spr_weapons.bardiche2'] = Display.image_load 'spr_weapons/bardiche2.png'
yield_point()
M['spr_weapons.bardiche3'] = Display.image_load 'spr_weapons/bardiche3.png'
yield_point()
M['spr_weapons.battle_axe1'] = Display.image_load 'spr_weapons/battle_axe1.png'
yield_point()
M['spr_weapons.battle_axe2'] = Display.image_load 'spr_weapons/battle_axe2.png'
yield_point()
M['spr_weapons.battle_axe3'] = Display.image_load 'spr_weapons/battle_axe3.png'
yield_point()
M['spr_weapons.blessed_blade'] = Display.image_load 'spr_weapons/blessed_blade.png'
yield_point()
M['spr_weapons.blowgun1'] = Display.image_load 'spr_weapons/blowgun1.png'
yield_point()
M['spr_weapons.blowgun2'] = Display.image_load 'spr_weapons/blowgun2.png'
yield_point()
M['spr_weapons.broad_axe1'] = Display.image_load 'spr_weapons/broad_axe1.png'
yield_point()
M['spr_weapons.broad_axe2'] = Display.image_load 'spr_weapons/broad_axe2.png'
yield_point()
M['spr_weapons.broad_axe3'] = Display.image_load 'spr_weapons/broad_axe3.png'
yield_point()
M['spr_weapons.bullwhip'] = Display.image_load 'spr_weapons/bullwhip.png'
yield_point()
M['spr_weapons.bullwhip2'] = Display.image_load 'spr_weapons/bullwhip2.png'
yield_point()
M['spr_weapons.bullwhip3'] = Display.image_load 'spr_weapons/bullwhip3.png'
yield_point()
M['spr_weapons.club'] = Display.image_load 'spr_weapons/club.png'
yield_point()
M['spr_weapons.club2'] = Display.image_load 'spr_weapons/club2.png'
yield_point()
M['spr_weapons.crossbow_bolt1'] = Display.image_load 'spr_weapons/crossbow_bolt1.png'
yield_point()
M['spr_weapons.crossbow_bolt2'] = Display.image_load 'spr_weapons/crossbow_bolt2.png'
yield_point()
M['spr_weapons.dagger'] = Display.image_load 'spr_weapons/dagger.png'
yield_point()
M['spr_weapons.dagger2'] = Display.image_load 'spr_weapons/dagger2.png'
yield_point()
M['spr_weapons.dagger3'] = Display.image_load 'spr_weapons/dagger3.png'
yield_point()
M['spr_weapons.demon_blade'] = Display.image_load 'spr_weapons/demon_blade.png'
yield_point()
M['spr_weapons.demon_blade2'] = Display.image_load 'spr_weapons/demon_blade2.png'
yield_point()
M['spr_weapons.demon_blade3'] = Display.image_load 'spr_weapons/demon_blade3.png'
yield_point()
M['spr_weapons.demon_trident'] = Display.image_load 'spr_weapons/demon_trident.png'
yield_point()
M['spr_weapons.demon_trident2'] = Display.image_load 'spr_weapons/demon_trident2.png'
yield_point()
M['spr_weapons.demon_trident3'] = Display.image_load 'spr_weapons/demon_trident3.png'
yield_point()
M['spr_weapons.demon_whip'] = Display.image_load 'spr_weapons/demon_whip.png'
yield_point()
M['spr_weapons.demon_whip2'] = Display.image_load 'spr_weapons/demon_whip2.png'
yield_point()
M['spr_weapons.demon_whip3'] = Display.image_load 'spr_weapons/demon_whip3.png'
yield_point()
M['spr_weapons.dire_flail1'] = Display.image_load 'spr_weapons/dire_flail1.png'
yield_point()
M['spr_weapons.dire_flail2'] = Display.image_load 'spr_weapons/dire_flail2.png'
yield_point()
M['spr_weapons.dire_flail3'] = Display.image_load 'spr_weapons/dire_flail3.png'
yield_point()
M['spr_weapons.double_sword'] = Display.image_load 'spr_weapons/double_sword.png'
yield_point()
M['spr_weapons.double_sword2'] = Display.image_load 'spr_weapons/double_sword2.png'
yield_point()
M['spr_weapons.double_sword3'] = Display.image_load 'spr_weapons/double_sword3.png'
yield_point()
M['spr_weapons.epic_staff'] = Display.image_load 'spr_weapons/epic_staff.png'
yield_point()
M['spr_weapons.eveningstar1'] = Display.image_load 'spr_weapons/eveningstar1.png'
yield_point()
M['spr_weapons.eveningstar2'] = Display.image_load 'spr_weapons/eveningstar2.png'
yield_point()
M['spr_weapons.eveningstar3'] = Display.image_load 'spr_weapons/eveningstar3.png'
yield_point()
M['spr_weapons.executioner_axe1'] = Display.image_load 'spr_weapons/executioner_axe1.png'
yield_point()
M['spr_weapons.executioner_axe2'] = Display.image_load 'spr_weapons/executioner_axe2.png'
yield_point()
M['spr_weapons.executioner_axe3'] = Display.image_load 'spr_weapons/executioner_axe3.png'
yield_point()
M['spr_weapons.falchion1'] = Display.image_load 'spr_weapons/falchion1.png'
yield_point()
M['spr_weapons.falchion2'] = Display.image_load 'spr_weapons/falchion2.png'
yield_point()
M['spr_weapons.falchion3'] = Display.image_load 'spr_weapons/falchion3.png'
yield_point()
M['spr_weapons.flail1'] = Display.image_load 'spr_weapons/flail1.png'
yield_point()
M['spr_weapons.flail2'] = Display.image_load 'spr_weapons/flail2.png'
yield_point()
M['spr_weapons.flail3'] = Display.image_load 'spr_weapons/flail3.png'
yield_point()
M['spr_weapons.fustibalus'] = Display.image_load 'spr_weapons/fustibalus.png'
yield_point()
M['spr_weapons.fustibalus2'] = Display.image_load 'spr_weapons/fustibalus2.png'
yield_point()
M['spr_weapons.giant_club'] = Display.image_load 'spr_weapons/giant_club.png'
yield_point()
M['spr_weapons.giant_club2'] = Display.image_load 'spr_weapons/giant_club2.png'
yield_point()
M['spr_weapons.giant_club3'] = Display.image_load 'spr_weapons/giant_club3.png'
yield_point()
M['spr_weapons.giant_spiked_club'] = Display.image_load 'spr_weapons/giant_spiked_club.png'
yield_point()
M['spr_weapons.giant_spiked_club2'] = Display.image_load 'spr_weapons/giant_spiked_club2.png'
yield_point()
M['spr_weapons.giant_spiked_club3'] = Display.image_load 'spr_weapons/giant_spiked_club3.png'
yield_point()
M['spr_weapons.glaive1'] = Display.image_load 'spr_weapons/glaive1.png'
yield_point()
M['spr_weapons.glaive2'] = Display.image_load 'spr_weapons/glaive2.png'
yield_point()
M['spr_weapons.glaive3'] = Display.image_load 'spr_weapons/glaive3.png'
yield_point()
M['spr_weapons.greatsword1'] = Display.image_load 'spr_weapons/greatsword1.png'
yield_point()
M['spr_weapons.greatsword2'] = Display.image_load 'spr_weapons/greatsword2.png'
yield_point()
M['spr_weapons.greatsword3'] = Display.image_load 'spr_weapons/greatsword3.png'
yield_point()
M['spr_weapons.halberd1'] = Display.image_load 'spr_weapons/halberd1.png'
yield_point()
M['spr_weapons.halberd2'] = Display.image_load 'spr_weapons/halberd2.png'
yield_point()
M['spr_weapons.halberd3'] = Display.image_load 'spr_weapons/halberd3.png'
yield_point()
M['spr_weapons.hand_axe1'] = Display.image_load 'spr_weapons/hand_axe1.png'
yield_point()
M['spr_weapons.hand_axe2'] = Display.image_load 'spr_weapons/hand_axe2.png'
yield_point()
M['spr_weapons.hand_axe3'] = Display.image_load 'spr_weapons/hand_axe3.png'
yield_point()
M['spr_weapons.hand_crossbow'] = Display.image_load 'spr_weapons/hand_crossbow.png'
yield_point()
M['spr_weapons.hand_crossbow2'] = Display.image_load 'spr_weapons/hand_crossbow2.png'
yield_point()
M['spr_weapons.hand_crossbow3'] = Display.image_load 'spr_weapons/hand_crossbow3.png'
yield_point()
M['spr_weapons.i-antimagic'] = Display.image_load 'spr_weapons/i-antimagic.png'
yield_point()
M['spr_weapons.i-chaos'] = Display.image_load 'spr_weapons/i-chaos.png'
yield_point()
M['spr_weapons.i-confusion'] = Display.image_load 'spr_weapons/i-confusion.png'
yield_point()
M['spr_weapons.i-curare'] = Display.image_load 'spr_weapons/i-curare.png'
yield_point()
M['spr_weapons.i-dispersal'] = Display.image_load 'spr_weapons/i-dispersal.png'
yield_point()
M['spr_weapons.i-distortion'] = Display.image_load 'spr_weapons/i-distortion.png'
yield_point()
M['spr_weapons.i-draining'] = Display.image_load 'spr_weapons/i-draining.png'
yield_point()
M['spr_weapons.i-electrocution'] = Display.image_load 'spr_weapons/i-electrocution.png'
yield_point()
M['spr_weapons.i-evasion'] = Display.image_load 'spr_weapons/i-evasion.png'
yield_point()
M['spr_weapons.i-explosion'] = Display.image_load 'spr_weapons/i-explosion.png'
yield_point()
M['spr_weapons.i-flaming'] = Display.image_load 'spr_weapons/i-flaming.png'
yield_point()
M['spr_weapons.i-freezing'] = Display.image_load 'spr_weapons/i-freezing.png'
yield_point()
M['spr_weapons.i-frenzy'] = Display.image_load 'spr_weapons/i-frenzy.png'
yield_point()
M['spr_weapons.i-holy_wrath'] = Display.image_load 'spr_weapons/i-holy_wrath.png'
yield_point()
M['spr_weapons.i-pain'] = Display.image_load 'spr_weapons/i-pain.png'
yield_point()
M['spr_weapons.i-paralysis'] = Display.image_load 'spr_weapons/i-paralysis.png'
yield_point()
M['spr_weapons.i-penetration'] = Display.image_load 'spr_weapons/i-penetration.png'
yield_point()
M['spr_weapons.i-protection'] = Display.image_load 'spr_weapons/i-protection.png'
yield_point()
M['spr_weapons.i-reaping'] = Display.image_load 'spr_weapons/i-reaping.png'
yield_point()
M['spr_weapons.i-returning'] = Display.image_load 'spr_weapons/i-returning.png'
yield_point()
M['spr_weapons.i-sickness'] = Display.image_load 'spr_weapons/i-sickness.png'
yield_point()
M['spr_weapons.i-sleep'] = Display.image_load 'spr_weapons/i-sleep.png'
yield_point()
M['spr_weapons.i-slowing'] = Display.image_load 'spr_weapons/i-slowing.png'
yield_point()
M['spr_weapons.i-speed'] = Display.image_load 'spr_weapons/i-speed.png'
yield_point()
M['spr_weapons.i-vampirism'] = Display.image_load 'spr_weapons/i-vampirism.png'
yield_point()
M['spr_weapons.i-venom'] = Display.image_load 'spr_weapons/i-venom.png'
yield_point()
M['spr_weapons.i-vorpal'] = Display.image_load 'spr_weapons/i-vorpal.png'
yield_point()
M['spr_weapons.javelin1'] = Display.image_load 'spr_weapons/javelin1.png'
yield_point()
M['spr_weapons.javelin2'] = Display.image_load 'spr_weapons/javelin2.png'
yield_point()
M['spr_weapons.lajatang1'] = Display.image_load 'spr_weapons/lajatang1.png'
yield_point()
M['spr_weapons.lajatang2'] = Display.image_load 'spr_weapons/lajatang2.png'
yield_point()
M['spr_weapons.lajatang3'] = Display.image_load 'spr_weapons/lajatang3.png'
yield_point()
M['spr_weapons.long_sword1'] = Display.image_load 'spr_weapons/long_sword1.png'
yield_point()
M['spr_weapons.long_sword2'] = Display.image_load 'spr_weapons/long_sword2.png'
yield_point()
M['spr_weapons.long_sword3'] = Display.image_load 'spr_weapons/long_sword3.png'
yield_point()
M['spr_weapons.longbow1'] = Display.image_load 'spr_weapons/longbow1.png'
yield_point()
M['spr_weapons.longbow2'] = Display.image_load 'spr_weapons/longbow2.png'
yield_point()
M['spr_weapons.longbow3'] = Display.image_load 'spr_weapons/longbow3.png'
yield_point()
M['spr_weapons.mace1'] = Display.image_load 'spr_weapons/mace1.png'
yield_point()
M['spr_weapons.mace2'] = Display.image_load 'spr_weapons/mace2.png'
yield_point()
M['spr_weapons.mace3'] = Display.image_load 'spr_weapons/mace3.png'
yield_point()
M['spr_weapons.mace_large1'] = Display.image_load 'spr_weapons/mace_large1.png'
yield_point()
M['spr_weapons.mace_large2'] = Display.image_load 'spr_weapons/mace_large2.png'
yield_point()
M['spr_weapons.mace_large3'] = Display.image_load 'spr_weapons/mace_large3.png'
yield_point()
M['spr_weapons.morningstar1'] = Display.image_load 'spr_weapons/morningstar1.png'
yield_point()
M['spr_weapons.morningstar2'] = Display.image_load 'spr_weapons/morningstar2.png'
yield_point()
M['spr_weapons.morningstar3'] = Display.image_load 'spr_weapons/morningstar3.png'
yield_point()
M['spr_weapons.needle-c'] = Display.image_load 'spr_weapons/needle-c.png'
yield_point()
M['spr_weapons.needle-p'] = Display.image_load 'spr_weapons/needle-p.png'
yield_point()
M['spr_weapons.needle1'] = Display.image_load 'spr_weapons/needle1.png'
yield_point()
M['spr_weapons.needle2'] = Display.image_load 'spr_weapons/needle2.png'
yield_point()
M['spr_weapons.quarterstaff'] = Display.image_load 'spr_weapons/quarterstaff.png'
yield_point()
M['spr_weapons.quarterstaff2'] = Display.image_load 'spr_weapons/quarterstaff2.png'
yield_point()
M['spr_weapons.quarterstaff3'] = Display.image_load 'spr_weapons/quarterstaff3.png'
yield_point()
M['spr_weapons.quickblade1'] = Display.image_load 'spr_weapons/quickblade1.png'
yield_point()
M['spr_weapons.quickblade2'] = Display.image_load 'spr_weapons/quickblade2.png'
yield_point()
M['spr_weapons.quickblade3'] = Display.image_load 'spr_weapons/quickblade3.png'
yield_point()
M['spr_weapons.randart_dagger1'] = Display.image_load 'spr_weapons/randart_dagger1.png'
yield_point()
M['spr_weapons.randart_dagger2'] = Display.image_load 'spr_weapons/randart_dagger2.png'
yield_point()
M['spr_weapons.randart_mace1'] = Display.image_load 'spr_weapons/randart_mace1.png'
yield_point()
M['spr_weapons.randart_mace2'] = Display.image_load 'spr_weapons/randart_mace2.png'
yield_point()
M['spr_weapons.randart_mace3'] = Display.image_load 'spr_weapons/randart_mace3.png'
yield_point()
M['spr_weapons.randart_short_sword1'] = Display.image_load 'spr_weapons/randart_short_sword1.png'
yield_point()
M['spr_weapons.randart_short_sword2'] = Display.image_load 'spr_weapons/randart_short_sword2.png'
yield_point()
M['spr_weapons.randart_shortbow'] = Display.image_load 'spr_weapons/randart_shortbow.png'
yield_point()
M['spr_weapons.randart_triple_sword1'] = Display.image_load 'spr_weapons/randart_triple_sword1.png'
yield_point()
M['spr_weapons.randart_triple_sword2'] = Display.image_load 'spr_weapons/randart_triple_sword2.png'
yield_point()
M['spr_weapons.rapier1'] = Display.image_load 'spr_weapons/rapier1.png'
yield_point()
M['spr_weapons.rapier2'] = Display.image_load 'spr_weapons/rapier2.png'
yield_point()
M['spr_weapons.rapier3'] = Display.image_load 'spr_weapons/rapier3.png'
yield_point()
M['spr_weapons.rock'] = Display.image_load 'spr_weapons/rock.png'
yield_point()
M['spr_weapons.sacred_scourge'] = Display.image_load 'spr_weapons/sacred_scourge.png'
yield_point()
M['spr_weapons.scimitar1'] = Display.image_load 'spr_weapons/scimitar1.png'
yield_point()
M['spr_weapons.scimitar2'] = Display.image_load 'spr_weapons/scimitar2.png'
yield_point()
M['spr_weapons.scimitar3'] = Display.image_load 'spr_weapons/scimitar3.png'
yield_point()
M['spr_weapons.scythe1'] = Display.image_load 'spr_weapons/scythe1.png'
yield_point()
M['spr_weapons.scythe2'] = Display.image_load 'spr_weapons/scythe2.png'
yield_point()
M['spr_weapons.scythe3'] = Display.image_load 'spr_weapons/scythe3.png'
yield_point()
M['spr_weapons.short_sword1'] = Display.image_load 'spr_weapons/short_sword1.png'
yield_point()
M['spr_weapons.short_sword2'] = Display.image_load 'spr_weapons/short_sword2.png'
yield_point()
M['spr_weapons.short_sword3'] = Display.image_load 'spr_weapons/short_sword3.png'
yield_point()
M['spr_weapons.shortbow1'] = Display.image_load 'spr_weapons/shortbow1.png'
yield_point()
M['spr_weapons.shortbow2'] = Display.image_load 'spr_weapons/shortbow2.png'
yield_point()
M['spr_weapons.shortbow3'] = Display.image_load 'spr_weapons/shortbow3.png'
yield_point()
M['spr_weapons.silver_arrow1'] = Display.image_load 'spr_weapons/silver_arrow1.png'
yield_point()
M['spr_weapons.silver_arrow2'] = Display.image_load 'spr_weapons/silver_arrow2.png'
yield_point()
M['spr_weapons.silver_crossbow_bolt1'] = Display.image_load 'spr_weapons/silver_crossbow_bolt1.png'
yield_point()
M['spr_weapons.silver_crossbow_bolt2'] = Display.image_load 'spr_weapons/silver_crossbow_bolt2.png'
yield_point()
M['spr_weapons.silver_javelin1'] = Display.image_load 'spr_weapons/silver_javelin1.png'
yield_point()
M['spr_weapons.silver_javelin2'] = Display.image_load 'spr_weapons/silver_javelin2.png'
yield_point()
M['spr_weapons.silver_sling_bullet1'] = Display.image_load 'spr_weapons/silver_sling_bullet1.png'
yield_point()
M['spr_weapons.silver_sling_bullet2'] = Display.image_load 'spr_weapons/silver_sling_bullet2.png'
yield_point()
M['spr_weapons.silver_tomahawk'] = Display.image_load 'spr_weapons/silver_tomahawk.png'
yield_point()
M['spr_weapons.sling1'] = Display.image_load 'spr_weapons/sling1.png'
yield_point()
M['spr_weapons.sling2'] = Display.image_load 'spr_weapons/sling2.png'
yield_point()
M['spr_weapons.sling_bullet1'] = Display.image_load 'spr_weapons/sling_bullet1.png'
yield_point()
M['spr_weapons.sling_bullet2'] = Display.image_load 'spr_weapons/sling_bullet2.png'
yield_point()
M['spr_weapons.spear1'] = Display.image_load 'spr_weapons/spear1.png'
yield_point()
M['spr_weapons.spear2'] = Display.image_load 'spr_weapons/spear2.png'
yield_point()
M['spr_weapons.spear3'] = Display.image_load 'spr_weapons/spear3.png'
yield_point()
M['spr_weapons.spwpn_demon_axe'] = Display.image_load 'spr_weapons/spwpn_demon_axe.png'
yield_point()
M['spr_weapons.spwpn_glaive_of_prune'] = Display.image_load 'spr_weapons/spwpn_glaive_of_prune.png'
yield_point()
M['spr_weapons.spwpn_mace_of_variability'] = Display.image_load 'spr_weapons/spwpn_mace_of_variability.png'
yield_point()
M['spr_weapons.spwpn_majin'] = Display.image_load 'spr_weapons/spwpn_majin.png'
yield_point()
M['spr_weapons.spwpn_sceptre_of_asmodeus'] = Display.image_load 'spr_weapons/spwpn_sceptre_of_asmodeus.png'
yield_point()
M['spr_weapons.spwpn_sceptre_of_torment'] = Display.image_load 'spr_weapons/spwpn_sceptre_of_torment.png'
yield_point()
M['spr_weapons.spwpn_scythe_of_curses'] = Display.image_load 'spr_weapons/spwpn_scythe_of_curses.png'
yield_point()
M['spr_weapons.spwpn_singing_sword'] = Display.image_load 'spr_weapons/spwpn_singing_sword.png'
yield_point()
M['spr_weapons.spwpn_staff_of_dispater'] = Display.image_load 'spr_weapons/spwpn_staff_of_dispater.png'
yield_point()
M['spr_weapons.spwpn_staff_of_olgreb'] = Display.image_load 'spr_weapons/spwpn_staff_of_olgreb.png'
yield_point()
M['spr_weapons.spwpn_sword_of_cerebov'] = Display.image_load 'spr_weapons/spwpn_sword_of_cerebov.png'
yield_point()
M['spr_weapons.spwpn_sword_of_power'] = Display.image_load 'spr_weapons/spwpn_sword_of_power.png'
yield_point()
M['spr_weapons.spwpn_sword_of_zonguldrok'] = Display.image_load 'spr_weapons/spwpn_sword_of_zonguldrok.png'
yield_point()
M['spr_weapons.spwpn_vampires_tooth'] = Display.image_load 'spr_weapons/spwpn_vampires_tooth.png'
yield_point()
M['spr_weapons.spwpn_wrath_of_trog'] = Display.image_load 'spr_weapons/spwpn_wrath_of_trog.png'
yield_point()
M['spr_weapons.spwpn_wucad_mu'] = Display.image_load 'spr_weapons/spwpn_wucad_mu.png'
yield_point()
M['spr_weapons.staff'] = Display.image_load 'spr_weapons/staff.png'
yield_point()
M['spr_weapons.staff_mummy'] = Display.image_load 'spr_weapons/staff_mummy.png'
yield_point()
M['spr_weapons.staff_of_elements'] = Display.image_load 'spr_weapons/staff_of_elements.png'
yield_point()
M['spr_weapons.steel_arrow1'] = Display.image_load 'spr_weapons/steel_arrow1.png'
yield_point()
M['spr_weapons.steel_arrow2'] = Display.image_load 'spr_weapons/steel_arrow2.png'
yield_point()
M['spr_weapons.steel_crossbow_bolt1'] = Display.image_load 'spr_weapons/steel_crossbow_bolt1.png'
yield_point()
M['spr_weapons.steel_crossbow_bolt2'] = Display.image_load 'spr_weapons/steel_crossbow_bolt2.png'
yield_point()
M['spr_weapons.steel_javelin1'] = Display.image_load 'spr_weapons/steel_javelin1.png'
yield_point()
M['spr_weapons.steel_javelin2'] = Display.image_load 'spr_weapons/steel_javelin2.png'
yield_point()
M['spr_weapons.steel_sling_bullet1'] = Display.image_load 'spr_weapons/steel_sling_bullet1.png'
yield_point()
M['spr_weapons.steel_sling_bullet2'] = Display.image_load 'spr_weapons/steel_sling_bullet2.png'
yield_point()
M['spr_weapons.steel_tomahawk'] = Display.image_load 'spr_weapons/steel_tomahawk.png'
yield_point()
M['spr_weapons.stone'] = Display.image_load 'spr_weapons/stone.png'
yield_point()
M['spr_weapons.stone0'] = Display.image_load 'spr_weapons/stone0.png'
yield_point()
M['spr_weapons.stone_randart'] = Display.image_load 'spr_weapons/stone_randart.png'
yield_point()
M['spr_weapons.stone_randart2'] = Display.image_load 'spr_weapons/stone_randart2.png'
yield_point()
M['spr_weapons.stone_randart3'] = Display.image_load 'spr_weapons/stone_randart3.png'
yield_point()
M['spr_weapons.sword'] = Display.image_load 'spr_weapons/sword.png'
yield_point()
M['spr_weapons.throwing_net'] = Display.image_load 'spr_weapons/throwing_net.png'
yield_point()
M['spr_weapons.tomahawk1'] = Display.image_load 'spr_weapons/tomahawk1.png'
yield_point()
M['spr_weapons.tomahawk2'] = Display.image_load 'spr_weapons/tomahawk2.png'
yield_point()
M['spr_weapons.trident1'] = Display.image_load 'spr_weapons/trident1.png'
yield_point()
M['spr_weapons.trident2'] = Display.image_load 'spr_weapons/trident2.png'
yield_point()
M['spr_weapons.trident3'] = Display.image_load 'spr_weapons/trident3.png'
yield_point()
M['spr_weapons.triple_crossbow'] = Display.image_load 'spr_weapons/triple_crossbow.png'
yield_point()
M['spr_weapons.triple_crossbow2'] = Display.image_load 'spr_weapons/triple_crossbow2.png'
yield_point()
M['spr_weapons.triple_sword'] = Display.image_load 'spr_weapons/triple_sword.png'
yield_point()
M['spr_weapons.triple_sword2'] = Display.image_load 'spr_weapons/triple_sword2.png'
yield_point()
M['spr_weapons.triple_sword3'] = Display.image_load 'spr_weapons/triple_sword3.png'
yield_point()
M['spr_weapons.trishula'] = Display.image_load 'spr_weapons/trishula.png'
yield_point()
M['spr_weapons.urand_arc_blade'] = Display.image_load 'spr_weapons/urand_arc_blade.png'
yield_point()
M['spr_weapons.urand_arga'] = Display.image_load 'spr_weapons/urand_arga.png'
yield_point()
M['spr_weapons.urand_axe_of_woe'] = Display.image_load 'spr_weapons/urand_axe_of_woe.png'
yield_point()
M['spr_weapons.urand_bloodbane'] = Display.image_load 'spr_weapons/urand_bloodbane.png'
yield_point()
M['spr_weapons.urand_blowgun'] = Display.image_load 'spr_weapons/urand_blowgun.png'
yield_point()
M['spr_weapons.urand_botono'] = Display.image_load 'spr_weapons/urand_botono.png'
yield_point()
M['spr_weapons.urand_brilliance'] = Display.image_load 'spr_weapons/urand_brilliance.png'
yield_point()
M['spr_weapons.urand_chilly_death'] = Display.image_load 'spr_weapons/urand_chilly_death.png'
yield_point()
M['spr_weapons.urand_crystal_spear'] = Display.image_load 'spr_weapons/urand_crystal_spear.png'
yield_point()
M['spr_weapons.urand_cutlass'] = Display.image_load 'spr_weapons/urand_cutlass.png'
yield_point()
M['spr_weapons.urand_damnation'] = Display.image_load 'spr_weapons/urand_damnation.png'
yield_point()
M['spr_weapons.urand_dark_maul'] = Display.image_load 'spr_weapons/urand_dark_maul.png'
yield_point()
M['spr_weapons.urand_doom_knight'] = Display.image_load 'spr_weapons/urand_doom_knight.png'
yield_point()
M['spr_weapons.urand_elemental'] = Display.image_load 'spr_weapons/urand_elemental.png'
yield_point()
M['spr_weapons.urand_eos'] = Display.image_load 'spr_weapons/urand_eos.png'
yield_point()
M['spr_weapons.urand_finisher'] = Display.image_load 'spr_weapons/urand_finisher.png'
yield_point()
M['spr_weapons.urand_firestarter'] = Display.image_load 'spr_weapons/urand_firestarter.png'
yield_point()
M['spr_weapons.urand_flaming_death'] = Display.image_load 'spr_weapons/urand_flaming_death.png'
yield_point()
M['spr_weapons.urand_frostbite'] = Display.image_load 'spr_weapons/urand_frostbite.png'
yield_point()
M['spr_weapons.urand_guard'] = Display.image_load 'spr_weapons/urand_guard.png'
yield_point()
M['spr_weapons.urand_gyre'] = Display.image_load 'spr_weapons/urand_gyre.png'
yield_point()
M['spr_weapons.urand_jihad'] = Display.image_load 'spr_weapons/urand_jihad.png'
yield_point()
M['spr_weapons.urand_katana'] = Display.image_load 'spr_weapons/urand_katana.png'
yield_point()
M['spr_weapons.urand_knife_of_accuracy'] = Display.image_load 'spr_weapons/urand_knife_of_accuracy.png'
yield_point()
M['spr_weapons.urand_krishna'] = Display.image_load 'spr_weapons/urand_krishna.png'
yield_point()
M['spr_weapons.urand_leech'] = Display.image_load 'spr_weapons/urand_leech.png'
yield_point()
M['spr_weapons.urand_morg'] = Display.image_load 'spr_weapons/urand_morg.png'
yield_point()
M['spr_weapons.urand_octopus_king'] = Display.image_load 'spr_weapons/urand_octopus_king.png'
yield_point()
M['spr_weapons.urand_order'] = Display.image_load 'spr_weapons/urand_order.png'
yield_point()
M['spr_weapons.urand_piercer'] = Display.image_load 'spr_weapons/urand_piercer.png'
yield_point()
M['spr_weapons.urand_plutonium'] = Display.image_load 'spr_weapons/urand_plutonium.png'
yield_point()
M['spr_weapons.urand_punk'] = Display.image_load 'spr_weapons/urand_punk.png'
yield_point()
M['spr_weapons.urand_shillelagh'] = Display.image_load 'spr_weapons/urand_shillelagh.png'
yield_point()
M['spr_weapons.urand_skullcrusher'] = Display.image_load 'spr_weapons/urand_skullcrusher.png'
yield_point()
M['spr_weapons.urand_snakebite'] = Display.image_load 'spr_weapons/urand_snakebite.png'
yield_point()
M['spr_weapons.urand_sniper'] = Display.image_load 'spr_weapons/urand_sniper.png'
yield_point()
M['spr_weapons.urand_spellbinder'] = Display.image_load 'spr_weapons/urand_spellbinder.png'
yield_point()
M['spr_weapons.urand_spriggans_knife'] = Display.image_load 'spr_weapons/urand_spriggans_knife.png'
yield_point()
M['spr_weapons.urand_storm_bow'] = Display.image_load 'spr_weapons/urand_storm_bow.png'
yield_point()
M['spr_weapons.urand_undeadhunter'] = Display.image_load 'spr_weapons/urand_undeadhunter.png'
yield_point()
M['spr_weapons.urand_wyrmbane'] = Display.image_load 'spr_weapons/urand_wyrmbane.png'
yield_point()
M['spr_weapons.war_axe1'] = Display.image_load 'spr_weapons/war_axe1.png'
yield_point()
M['spr_weapons.war_axe2'] = Display.image_load 'spr_weapons/war_axe2.png'
yield_point()
M['spr_weapons.war_axe3'] = Display.image_load 'spr_weapons/war_axe3.png'
yield_point()

-- spr_gamepad resource loads:
M['spr_gamepad.xbox_axis_left_trigger'] = Display.image_load 'spr_gamepad/xbox_axis_left_trigger.png'
yield_point()
M['spr_gamepad.xbox_axis_right_trigger'] = Display.image_load 'spr_gamepad/xbox_axis_right_trigger.png'
yield_point()
M['spr_gamepad.xbox_button_a'] = Display.image_load 'spr_gamepad/xbox_button_a.png'
yield_point()
M['spr_gamepad.xbox_button_b'] = Display.image_load 'spr_gamepad/xbox_button_b.png'
yield_point()
M['spr_gamepad.xbox_button_back'] = Display.image_load 'spr_gamepad/xbox_button_back.png'
yield_point()
M['spr_gamepad.xbox_button_guide'] = Display.image_load 'spr_gamepad/xbox_button_guide.png'
yield_point()
M['spr_gamepad.xbox_button_left_shoulder'] = Display.image_load 'spr_gamepad/xbox_button_left_shoulder.png'
yield_point()
M['spr_gamepad.xbox_button_right_shoulder'] = Display.image_load 'spr_gamepad/xbox_button_right_shoulder.png'
yield_point()
M['spr_gamepad.xbox_button_start'] = Display.image_load 'spr_gamepad/xbox_button_start.png'
yield_point()
M['spr_gamepad.xbox_button_x'] = Display.image_load 'spr_gamepad/xbox_button_x.png'
yield_point()
M['spr_gamepad.xbox_button_y'] = Display.image_load 'spr_gamepad/xbox_button_y.png'
yield_point()
M['spr_gamepad.xbox_dpad'] = Display.image_load 'spr_gamepad/xbox_dpad.png'
yield_point()
M['spr_gamepad.xbox_right_axis_down'] = Display.image_load 'spr_gamepad/xbox_right_axis_down.png'
yield_point()
M['spr_gamepad.xbox_right_axis_left'] = Display.image_load 'spr_gamepad/xbox_right_axis_left.png'
yield_point()
M['spr_gamepad.xbox_right_axis_right'] = Display.image_load 'spr_gamepad/xbox_right_axis_right.png'
yield_point()
M['spr_gamepad.xbox_right_axis_up'] = Display.image_load 'spr_gamepad/xbox_right_axis_up.png'
yield_point()
M['spr_gamepad.xbox_right_shoulder'] = Display.image_load 'spr_gamepad/xbox_right_shoulder.png'
yield_point()

-- spr_armour resource loads:
M['spr_armour.acid_dragon_armour'] = Display.image_load 'spr_armour/acid_dragon_armour.png'
yield_point()
M['spr_armour.animal_skin1'] = Display.image_load 'spr_armour/animal_skin1.png'
yield_point()
M['spr_armour.animal_skin2'] = Display.image_load 'spr_armour/animal_skin2.png'
yield_point()
M['spr_armour.animal_skin3'] = Display.image_load 'spr_armour/animal_skin3.png'
yield_point()
M['spr_armour.blue_dragon_scale_mail'] = Display.image_load 'spr_armour/blue_dragon_scale_mail.png'
yield_point()
M['spr_armour.buckler1'] = Display.image_load 'spr_armour/buckler1.png'
yield_point()
M['spr_armour.buckler2'] = Display.image_load 'spr_armour/buckler2.png'
yield_point()
M['spr_armour.buckler3'] = Display.image_load 'spr_armour/buckler3.png'
yield_point()
M['spr_armour.buckler_spriggan'] = Display.image_load 'spr_armour/buckler_spriggan.png'
yield_point()
M['spr_armour.cap1'] = Display.image_load 'spr_armour/cap1.png'
yield_point()
M['spr_armour.cap_jester'] = Display.image_load 'spr_armour/cap_jester.png'
yield_point()
M['spr_armour.centaur_barding_blue'] = Display.image_load 'spr_armour/centaur_barding_blue.png'
yield_point()
M['spr_armour.centaur_barding_magenta'] = Display.image_load 'spr_armour/centaur_barding_magenta.png'
yield_point()
M['spr_armour.centaur_barding_metal'] = Display.image_load 'spr_armour/centaur_barding_metal.png'
yield_point()
M['spr_armour.centaur_barding_red'] = Display.image_load 'spr_armour/centaur_barding_red.png'
yield_point()
M['spr_armour.chain_mail1'] = Display.image_load 'spr_armour/chain_mail1.png'
yield_point()
M['spr_armour.chain_mail2'] = Display.image_load 'spr_armour/chain_mail2.png'
yield_point()
M['spr_armour.chain_mail3'] = Display.image_load 'spr_armour/chain_mail3.png'
yield_point()
M['spr_armour.cloak1_leather'] = Display.image_load 'spr_armour/cloak1_leather.png'
yield_point()
M['spr_armour.cloak2'] = Display.image_load 'spr_armour/cloak2.png'
yield_point()
M['spr_armour.cloak3'] = Display.image_load 'spr_armour/cloak3.png'
yield_point()
M['spr_armour.cloak4'] = Display.image_load 'spr_armour/cloak4.png'
yield_point()
M['spr_armour.cornuthaum'] = Display.image_load 'spr_armour/cornuthaum.png'
yield_point()
M['spr_armour.crystal_plate'] = Display.image_load 'spr_armour/crystal_plate.png'
yield_point()
M['spr_armour.crystal_plate2'] = Display.image_load 'spr_armour/crystal_plate2.png'
yield_point()
M['spr_armour.crystal_plate3'] = Display.image_load 'spr_armour/crystal_plate3.png'
yield_point()
M['spr_armour.dwarven_buckler1'] = Display.image_load 'spr_armour/dwarven_buckler1.png'
yield_point()
M['spr_armour.dwarven_buckler2'] = Display.image_load 'spr_armour/dwarven_buckler2.png'
yield_point()
M['spr_armour.elven_buckler1'] = Display.image_load 'spr_armour/elven_buckler1.png'
yield_point()
M['spr_armour.elven_buckler2'] = Display.image_load 'spr_armour/elven_buckler2.png'
yield_point()
M['spr_armour.elven_leather_helm'] = Display.image_load 'spr_armour/elven_leather_helm.png'
yield_point()
M['spr_armour.gauntlet1'] = Display.image_load 'spr_armour/gauntlet1.png'
yield_point()
M['spr_armour.glove1'] = Display.image_load 'spr_armour/glove1.png'
yield_point()
M['spr_armour.glove2'] = Display.image_load 'spr_armour/glove2.png'
yield_point()
M['spr_armour.glove3'] = Display.image_load 'spr_armour/glove3.png'
yield_point()
M['spr_armour.glove4'] = Display.image_load 'spr_armour/glove4.png'
yield_point()
M['spr_armour.glove5'] = Display.image_load 'spr_armour/glove5.png'
yield_point()
M['spr_armour.gloves_confusion'] = Display.image_load 'spr_armour/gloves_confusion.png'
yield_point()
M['spr_armour.gloves_confusion_randart'] = Display.image_load 'spr_armour/gloves_confusion_randart.png'
yield_point()
M['spr_armour.gloves_fear'] = Display.image_load 'spr_armour/gloves_fear.png'
yield_point()
M['spr_armour.gloves_fear_randart'] = Display.image_load 'spr_armour/gloves_fear_randart.png'
yield_point()
M['spr_armour.gold_dragon_armour'] = Display.image_load 'spr_armour/gold_dragon_armour.png'
yield_point()
M['spr_armour.green_robe'] = Display.image_load 'spr_armour/green_robe.png'
yield_point()
M['spr_armour.hat1'] = Display.image_load 'spr_armour/hat1.png'
yield_point()
M['spr_armour.hat2'] = Display.image_load 'spr_armour/hat2.png'
yield_point()
M['spr_armour.hat3'] = Display.image_load 'spr_armour/hat3.png'
yield_point()
M['spr_armour.hat4'] = Display.image_load 'spr_armour/hat4.png'
yield_point()
M['spr_armour.hat5'] = Display.image_load 'spr_armour/hat5.png'
yield_point()
M['spr_armour.helmet1'] = Display.image_load 'spr_armour/helmet1.png'
yield_point()
M['spr_armour.helmet2'] = Display.image_load 'spr_armour/helmet2.png'
yield_point()
M['spr_armour.helmet3'] = Display.image_load 'spr_armour/helmet3.png'
yield_point()
M['spr_armour.helmet4'] = Display.image_load 'spr_armour/helmet4.png'
yield_point()
M['spr_armour.helmet5'] = Display.image_load 'spr_armour/helmet5.png'
yield_point()
M['spr_armour.helmet_art1'] = Display.image_load 'spr_armour/helmet_art1.png'
yield_point()
M['spr_armour.helmet_art2'] = Display.image_load 'spr_armour/helmet_art2.png'
yield_point()
M['spr_armour.helmet_art3'] = Display.image_load 'spr_armour/helmet_art3.png'
yield_point()
M['spr_armour.helmet_ego1'] = Display.image_load 'spr_armour/helmet_ego1.png'
yield_point()
M['spr_armour.helmet_ego2'] = Display.image_load 'spr_armour/helmet_ego2.png'
yield_point()
M['spr_armour.helmet_ego3'] = Display.image_load 'spr_armour/helmet_ego3.png'
yield_point()
M['spr_armour.helmet_ego4'] = Display.image_load 'spr_armour/helmet_ego4.png'
yield_point()
M['spr_armour.i-archery'] = Display.image_load 'spr_armour/i-archery.png'
yield_point()
M['spr_armour.i-archmagi'] = Display.image_load 'spr_armour/i-archmagi.png'
yield_point()
M['spr_armour.i-cold-res'] = Display.image_load 'spr_armour/i-cold-res.png'
yield_point()
M['spr_armour.i-dexterity'] = Display.image_load 'spr_armour/i-dexterity.png'
yield_point()
M['spr_armour.i-fire-res'] = Display.image_load 'spr_armour/i-fire-res.png'
yield_point()
M['spr_armour.i-flying'] = Display.image_load 'spr_armour/i-flying.png'
yield_point()
M['spr_armour.i-intelligence'] = Display.image_load 'spr_armour/i-intelligence.png'
yield_point()
M['spr_armour.i-invisibility'] = Display.image_load 'spr_armour/i-invisibility.png'
yield_point()
M['spr_armour.i-jumping'] = Display.image_load 'spr_armour/i-jumping.png'
yield_point()
M['spr_armour.i-magic-res'] = Display.image_load 'spr_armour/i-magic-res.png'
yield_point()
M['spr_armour.i-poison-res'] = Display.image_load 'spr_armour/i-poison-res.png'
yield_point()
M['spr_armour.i-ponderous'] = Display.image_load 'spr_armour/i-ponderous.png'
yield_point()
M['spr_armour.i-positive-energy'] = Display.image_load 'spr_armour/i-positive-energy.png'
yield_point()
M['spr_armour.i-preservation'] = Display.image_load 'spr_armour/i-preservation.png'
yield_point()
M['spr_armour.i-protection'] = Display.image_load 'spr_armour/i-protection.png'
yield_point()
M['spr_armour.i-reflection'] = Display.image_load 'spr_armour/i-reflection.png'
yield_point()
M['spr_armour.i-resistance'] = Display.image_load 'spr_armour/i-resistance.png'
yield_point()
M['spr_armour.i-running'] = Display.image_load 'spr_armour/i-running.png'
yield_point()
M['spr_armour.i-see-invis'] = Display.image_load 'spr_armour/i-see-invis.png'
yield_point()
M['spr_armour.i-spirit'] = Display.image_load 'spr_armour/i-spirit.png'
yield_point()
M['spr_armour.i-stealth'] = Display.image_load 'spr_armour/i-stealth.png'
yield_point()
M['spr_armour.i-strength'] = Display.image_load 'spr_armour/i-strength.png'
yield_point()
M['spr_armour.ice_dragon_armour'] = Display.image_load 'spr_armour/ice_dragon_armour.png'
yield_point()
M['spr_armour.large_shield1'] = Display.image_load 'spr_armour/large_shield1.png'
yield_point()
M['spr_armour.large_shield2'] = Display.image_load 'spr_armour/large_shield2.png'
yield_point()
M['spr_armour.large_shield3'] = Display.image_load 'spr_armour/large_shield3.png'
yield_point()
M['spr_armour.leather_armour1'] = Display.image_load 'spr_armour/leather_armour1.png'
yield_point()
M['spr_armour.leather_armour2'] = Display.image_load 'spr_armour/leather_armour2.png'
yield_point()
M['spr_armour.leather_armour3'] = Display.image_load 'spr_armour/leather_armour3.png'
yield_point()
M['spr_armour.lshield_dd_dk'] = Display.image_load 'spr_armour/lshield_dd_dk.png'
yield_point()
M['spr_armour.lshield_louise'] = Display.image_load 'spr_armour/lshield_louise.png'
yield_point()
M['spr_armour.naga_barding_blue'] = Display.image_load 'spr_armour/naga_barding_blue.png'
yield_point()
M['spr_armour.naga_barding_magenta'] = Display.image_load 'spr_armour/naga_barding_magenta.png'
yield_point()
M['spr_armour.naga_barding_metal'] = Display.image_load 'spr_armour/naga_barding_metal.png'
yield_point()
M['spr_armour.naga_barding_red'] = Display.image_load 'spr_armour/naga_barding_red.png'
yield_point()
M['spr_armour.orcish_plate2'] = Display.image_load 'spr_armour/orcish_plate2.png'
yield_point()
M['spr_armour.pearl_dragon_armour'] = Display.image_load 'spr_armour/pearl_dragon_armour.png'
yield_point()
M['spr_armour.plate1'] = Display.image_load 'spr_armour/plate1.png'
yield_point()
M['spr_armour.plate2'] = Display.image_load 'spr_armour/plate2.png'
yield_point()
M['spr_armour.plate3'] = Display.image_load 'spr_armour/plate3.png'
yield_point()
M['spr_armour.plumed_helmet'] = Display.image_load 'spr_armour/plumed_helmet.png'
yield_point()
M['spr_armour.poison_resist_leather'] = Display.image_load 'spr_armour/poison_resist_leather.png'
yield_point()
M['spr_armour.quicksilver_dragon_scale_mail'] = Display.image_load 'spr_armour/quicksilver_dragon_scale_mail.png'
yield_point()
M['spr_armour.randart_glove1'] = Display.image_load 'spr_armour/randart_glove1.png'
yield_point()
M['spr_armour.randart_glove2'] = Display.image_load 'spr_armour/randart_glove2.png'
yield_point()
M['spr_armour.randart_glove3'] = Display.image_load 'spr_armour/randart_glove3.png'
yield_point()
M['spr_armour.randart_glove4'] = Display.image_load 'spr_armour/randart_glove4.png'
yield_point()
M['spr_armour.randart_hat'] = Display.image_load 'spr_armour/randart_hat.png'
yield_point()
M['spr_armour.randart_helmet'] = Display.image_load 'spr_armour/randart_helmet.png'
yield_point()
M['spr_armour.randart_plate'] = Display.image_load 'spr_armour/randart_plate.png'
yield_point()
M['spr_armour.randart_robe1'] = Display.image_load 'spr_armour/randart_robe1.png'
yield_point()
M['spr_armour.randart_robe2'] = Display.image_load 'spr_armour/randart_robe2.png'
yield_point()
M['spr_armour.red_dragon_scale_mail'] = Display.image_load 'spr_armour/red_dragon_scale_mail.png'
yield_point()
M['spr_armour.ring_mail1'] = Display.image_load 'spr_armour/ring_mail1.png'
yield_point()
M['spr_armour.ring_mail2'] = Display.image_load 'spr_armour/ring_mail2.png'
yield_point()
M['spr_armour.ring_mail3'] = Display.image_load 'spr_armour/ring_mail3.png'
yield_point()
M['spr_armour.robe1'] = Display.image_load 'spr_armour/robe1.png'
yield_point()
M['spr_armour.robe2'] = Display.image_load 'spr_armour/robe2.png'
yield_point()
M['spr_armour.robe_art1'] = Display.image_load 'spr_armour/robe_art1.png'
yield_point()
M['spr_armour.robe_art2'] = Display.image_load 'spr_armour/robe_art2.png'
yield_point()
M['spr_armour.robe_ego1'] = Display.image_load 'spr_armour/robe_ego1.png'
yield_point()
M['spr_armour.robe_ego2'] = Display.image_load 'spr_armour/robe_ego2.png'
yield_point()
M['spr_armour.robe_of_health'] = Display.image_load 'spr_armour/robe_of_health.png'
yield_point()
M['spr_armour.robe_of_mana'] = Display.image_load 'spr_armour/robe_of_mana.png'
yield_point()
M['spr_armour.scale_mail1'] = Display.image_load 'spr_armour/scale_mail1.png'
yield_point()
M['spr_armour.scale_mail2'] = Display.image_load 'spr_armour/scale_mail2.png'
yield_point()
M['spr_armour.scale_mail3'] = Display.image_load 'spr_armour/scale_mail3.png'
yield_point()
M['spr_armour.shadow_dragon_scale_mail'] = Display.image_load 'spr_armour/shadow_dragon_scale_mail.png'
yield_point()
M['spr_armour.shield1'] = Display.image_load 'spr_armour/shield1.png'
yield_point()
M['spr_armour.shield2'] = Display.image_load 'spr_armour/shield2.png'
yield_point()
M['spr_armour.shield3'] = Display.image_load 'spr_armour/shield3.png'
yield_point()
M['spr_armour.shield_dd'] = Display.image_load 'spr_armour/shield_dd.png'
yield_point()
M['spr_armour.shield_dd_scion'] = Display.image_load 'spr_armour/shield_dd_scion.png'
yield_point()
M['spr_armour.shield_donald'] = Display.image_load 'spr_armour/shield_donald.png'
yield_point()
M['spr_armour.silver_dragon_scale_mail'] = Display.image_load 'spr_armour/silver_dragon_scale_mail.png'
yield_point()
M['spr_armour.swamp_dragon_armour'] = Display.image_load 'spr_armour/swamp_dragon_armour.png'
yield_point()
M['spr_armour.troll_leather_armour'] = Display.image_load 'spr_armour/troll_leather_armour.png'
yield_point()
M['spr_armour.urand_alchemist'] = Display.image_load 'spr_armour/urand_alchemist.png'
yield_point()
M['spr_armour.urand_augmentation'] = Display.image_load 'spr_armour/urand_augmentation.png'
yield_point()
M['spr_armour.urand_bear'] = Display.image_load 'spr_armour/urand_bear.png'
yield_point()
M['spr_armour.urand_bk_barding'] = Display.image_load 'spr_armour/urand_bk_barding.png'
yield_point()
M['spr_armour.urand_bullseye'] = Display.image_load 'spr_armour/urand_bullseye.png'
yield_point()
M['spr_armour.urand_clouds'] = Display.image_load 'spr_armour/urand_clouds.png'
yield_point()
M['spr_armour.urand_dragon_king'] = Display.image_load 'spr_armour/urand_dragon_king.png'
yield_point()
M['spr_armour.urand_dragonmask'] = Display.image_load 'spr_armour/urand_dragonmask.png'
yield_point()
M['spr_armour.urand_dragonskin'] = Display.image_load 'spr_armour/urand_dragonskin.png'
yield_point()
M['spr_armour.urand_dyrovepreva'] = Display.image_load 'spr_armour/urand_dyrovepreva.png'
yield_point()
M['spr_armour.urand_eternal_torment'] = Display.image_load 'spr_armour/urand_eternal_torment.png'
yield_point()
M['spr_armour.urand_etheric_cage'] = Display.image_load 'spr_armour/urand_etheric_cage.png'
yield_point()
M['spr_armour.urand_faerie'] = Display.image_load 'spr_armour/urand_faerie.png'
yield_point()
M['spr_armour.urand_fencer'] = Display.image_load 'spr_armour/urand_fencer.png'
yield_point()
M['spr_armour.urand_flash'] = Display.image_load 'spr_armour/urand_flash.png'
yield_point()
M['spr_armour.urand_folly'] = Display.image_load 'spr_armour/urand_folly.png'
yield_point()
M['spr_armour.urand_gong'] = Display.image_load 'spr_armour/urand_gong.png'
yield_point()
M['spr_armour.urand_high_council'] = Display.image_load 'spr_armour/urand_high_council.png'
yield_point()
M['spr_armour.urand_ignorance'] = Display.image_load 'spr_armour/urand_ignorance.png'
yield_point()
M['spr_armour.urand_kryias'] = Display.image_load 'spr_armour/urand_kryias.png'
yield_point()
M['spr_armour.urand_lear'] = Display.image_load 'spr_armour/urand_lear.png'
yield_point()
M['spr_armour.urand_lightning_scales'] = Display.image_load 'spr_armour/urand_lightning_scales.png'
yield_point()
M['spr_armour.urand_maxwell'] = Display.image_load 'spr_armour/urand_maxwell.png'
yield_point()
M['spr_armour.urand_misfortune'] = Display.image_load 'spr_armour/urand_misfortune.png'
yield_point()
M['spr_armour.urand_moon_troll_leather_armour'] = Display.image_load 'spr_armour/urand_moon_troll_leather_armour.png'
yield_point()
M['spr_armour.urand_night'] = Display.image_load 'spr_armour/urand_night.png'
yield_point()
M['spr_armour.urand_orange_crystal'] = Display.image_load 'spr_armour/urand_orange_crystal.png'
yield_point()
M['spr_armour.urand_pondering'] = Display.image_load 'spr_armour/urand_pondering.png'
yield_point()
M['spr_armour.urand_ratskin_cloak'] = Display.image_load 'spr_armour/urand_ratskin_cloak.png'
yield_point()
M['spr_armour.urand_resistance'] = Display.image_load 'spr_armour/urand_resistance.png'
yield_point()
M['spr_armour.urand_salamander'] = Display.image_load 'spr_armour/urand_salamander.png'
yield_point()
M['spr_armour.urand_starlight'] = Display.image_load 'spr_armour/urand_starlight.png'
yield_point()
M['spr_armour.urand_talos'] = Display.image_load 'spr_armour/urand_talos.png'
yield_point()
M['spr_armour.urand_thief'] = Display.image_load 'spr_armour/urand_thief.png'
yield_point()
M['spr_armour.urand_vines'] = Display.image_load 'spr_armour/urand_vines.png'
yield_point()
M['spr_armour.urand_war'] = Display.image_load 'spr_armour/urand_war.png'
yield_point()
M['spr_armour.urand_warlock'] = Display.image_load 'spr_armour/urand_warlock.png'
yield_point()
M['spr_armour.urand_zhor'] = Display.image_load 'spr_armour/urand_zhor.png'
yield_point()
M['spr_armour.white_robe'] = Display.image_load 'spr_armour/white_robe.png'
yield_point()

-- spr_effects resource loads:
M['spr_effects.animated_weapon'] = Display.image_load 'spr_effects/animated_weapon.png'
yield_point()
M['spr_effects.berserk'] = Display.image_load 'spr_effects/berserk.png'
yield_point()
M['spr_effects.black-power'] = Display.image_load 'spr_effects/black-power.png'
yield_point()
M['spr_effects.black-resist'] = Display.image_load 'spr_effects/black-resist.png'
yield_point()
M['spr_effects.blind'] = Display.image_load 'spr_effects/blind.png'
yield_point()
M['spr_effects.bound_soul'] = Display.image_load 'spr_effects/bound_soul.png'
yield_point()
M['spr_effects.confusion'] = Display.image_load 'spr_effects/confusion.png'
yield_point()
M['spr_effects.constricted'] = Display.image_load 'spr_effects/constricted.png'
yield_point()
M['spr_effects.deathnote'] = Display.image_load 'spr_effects/deathnote.png'
yield_point()
M['spr_effects.deaths_door'] = Display.image_load 'spr_effects/deaths_door.png'
yield_point()
M['spr_effects.demon_pentagram1'] = Display.image_load 'spr_effects/demon_pentagram1.png'
yield_point()
M['spr_effects.demon_pentagram2'] = Display.image_load 'spr_effects/demon_pentagram2.png'
yield_point()
M['spr_effects.demon_pentagram3'] = Display.image_load 'spr_effects/demon_pentagram3.png'
yield_point()
M['spr_effects.demon_pentagram4'] = Display.image_load 'spr_effects/demon_pentagram4.png'
yield_point()
M['spr_effects.demon_pentagram5'] = Display.image_load 'spr_effects/demon_pentagram5.png'
yield_point()
M['spr_effects.dragon_fireball'] = Display.animation_create(Display.images_load 'spr_effects/dragon_fireball.32x32.png%32x32', 0.1)
yield_point()
M['spr_effects.drain'] = Display.image_load 'spr_effects/drain.png'
yield_point()
M['spr_effects.fire-anim'] = Display.animation_create(Display.images_load 'spr_effects/fire-anim.32x32.png%32x32', 0.1)
yield_point()
M['spr_effects.fireball2'] = Display.image_load 'spr_effects/fireball2.png'
yield_point()
M['spr_effects.fireball_small'] = Display.image_load 'spr_effects/fireball_small.png'
yield_point()
M['spr_effects.firebolt'] = Display.directional_create(Display.images_load 'spr_effects/firebolt.32x32.dir.png%32x32')
yield_point()
M['spr_effects.fleeing'] = Display.image_load 'spr_effects/fleeing.png'
yield_point()
M['spr_effects.friendly'] = Display.image_load 'spr_effects/friendly.png'
yield_point()
M['spr_effects.glowing'] = Display.image_load 'spr_effects/glowing.png'
yield_point()
M['spr_effects.good_neutral'] = Display.image_load 'spr_effects/good_neutral.png'
yield_point()
M['spr_effects.hasted'] = Display.image_load 'spr_effects/hasted.png'
yield_point()
M['spr_effects.i-c-teleport'] = Display.image_load 'spr_effects/i-c-teleport.png'
yield_point()
M['spr_effects.i-cold-big'] = Display.image_load 'spr_effects/i-cold-big.png'
yield_point()
M['spr_effects.i-dex'] = Display.image_load 'spr_effects/i-dex.png'
yield_point()
M['spr_effects.i-evasion'] = Display.image_load 'spr_effects/i-evasion.png'
yield_point()
M['spr_effects.i-fire-big'] = Display.image_load 'spr_effects/i-fire-big.png'
yield_point()
M['spr_effects.i-fire'] = Display.image_load 'spr_effects/i-fire.png'
yield_point()
M['spr_effects.i-flight'] = Display.image_load 'spr_effects/i-flight.png'
yield_point()
M['spr_effects.i-ice'] = Display.image_load 'spr_effects/i-ice.png'
yield_point()
M['spr_effects.i-int'] = Display.image_load 'spr_effects/i-int.png'
yield_point()
M['spr_effects.i-life-protection'] = Display.image_load 'spr_effects/i-life-protection.png'
yield_point()
M['spr_effects.i-loudness'] = Display.image_load 'spr_effects/i-loudness.png'
yield_point()
M['spr_effects.i-magical-power'] = Display.image_load 'spr_effects/i-magical-power.png'
yield_point()
M['spr_effects.i-poison-big'] = Display.image_load 'spr_effects/i-poison-big.png'
yield_point()
M['spr_effects.i-protection-big'] = Display.image_load 'spr_effects/i-protection-big.png'
yield_point()
M['spr_effects.i-protection'] = Display.image_load 'spr_effects/i-protection.png'
yield_point()
M['spr_effects.i-r-cold-big'] = Display.image_load 'spr_effects/i-r-cold-big.png'
yield_point()
M['spr_effects.i-r-cold'] = Display.image_load 'spr_effects/i-r-cold.png'
yield_point()
M['spr_effects.i-r-corrosion'] = Display.image_load 'spr_effects/i-r-corrosion.png'
yield_point()
M['spr_effects.i-r-fire-big'] = Display.image_load 'spr_effects/i-r-fire-big.png'
yield_point()
M['spr_effects.i-r-fire'] = Display.image_load 'spr_effects/i-r-fire.png'
yield_point()
M['spr_effects.i-r-magic'] = Display.image_load 'spr_effects/i-r-magic.png'
yield_point()
M['spr_effects.i-r-poison-big'] = Display.image_load 'spr_effects/i-r-poison-big.png'
yield_point()
M['spr_effects.i-r-poison'] = Display.image_load 'spr_effects/i-r-poison.png'
yield_point()
M['spr_effects.i-s-attr'] = Display.image_load 'spr_effects/i-s-attr.png'
yield_point()
M['spr_effects.i-see-invis'] = Display.image_load 'spr_effects/i-see-invis.png'
yield_point()
M['spr_effects.i-slaying'] = Display.image_load 'spr_effects/i-slaying.png'
yield_point()
M['spr_effects.i-stealth'] = Display.image_load 'spr_effects/i-stealth.png'
yield_point()
M['spr_effects.i-str'] = Display.image_load 'spr_effects/i-str.png'
yield_point()
M['spr_effects.i-teleport'] = Display.image_load 'spr_effects/i-teleport.png'
yield_point()
M['spr_effects.i-wizardry'] = Display.image_load 'spr_effects/i-wizardry.png'
yield_point()
M['spr_effects.iceball'] = Display.image_load 'spr_effects/iceball.png'
yield_point()
M['spr_effects.idealised'] = Display.image_load 'spr_effects/idealised.png'
yield_point()
M['spr_effects.infested'] = Display.image_load 'spr_effects/infested.png'
yield_point()
M['spr_effects.inner_flame'] = Display.image_load 'spr_effects/inner_flame.png'
yield_point()
M['spr_effects.lightningbolt'] = Display.directional_create(Display.images_load 'spr_effects/lightningbolt.32x32.dir.png%32x32')
yield_point()
M['spr_effects.may_stab_brand'] = Display.image_load 'spr_effects/may_stab_brand.png'
yield_point()
M['spr_effects.might'] = Display.image_load 'spr_effects/might.png'
yield_point()
M['spr_effects.neutral'] = Display.image_load 'spr_effects/neutral.png'
yield_point()
M['spr_effects.new_stair'] = Display.image_load 'spr_effects/new_stair.png'
yield_point()
M['spr_effects.pain_mirror'] = Display.image_load 'spr_effects/pain_mirror.png'
yield_point()
M['spr_effects.petrified'] = Display.image_load 'spr_effects/petrified.png'
yield_point()
M['spr_effects.petrifying'] = Display.image_load 'spr_effects/petrifying.png'
yield_point()
M['spr_effects.poison'] = Display.image_load 'spr_effects/poison.png'
yield_point()
M['spr_effects.recall'] = Display.image_load 'spr_effects/recall.png'
yield_point()
M['spr_effects.shock-resist'] = Display.image_load 'spr_effects/shock-resist.png'
yield_point()
M['spr_effects.shock'] = Display.image_load 'spr_effects/shock.png'
yield_point()
M['spr_effects.skullnado'] = Display.image_load 'spr_effects/skullnado.png'
yield_point()
M['spr_effects.sleeping'] = Display.image_load 'spr_effects/sleeping.png'
yield_point()
M['spr_effects.slowed'] = Display.image_load 'spr_effects/slowed.png'
yield_point()
M['spr_effects.something_under'] = Display.image_load 'spr_effects/something_under.png'
yield_point()
M['spr_effects.sticky_flame'] = Display.image_load 'spr_effects/sticky_flame.png'
yield_point()
M['spr_effects.stormcloud'] = Display.animation_create(Display.images_load 'spr_effects/stormcloud.128x84.png%128x84', 0.1)
yield_point()
M['spr_effects.stormcloud_shadow'] = Display.image_load 'spr_effects/stormcloud_shadow.png'
yield_point()
M['spr_effects.summoned'] = Display.image_load 'spr_effects/summoned.png'
yield_point()
M['spr_effects.summoned_durable'] = Display.image_load 'spr_effects/summoned_durable.png'
yield_point()
M['spr_effects.sword'] = Display.image_load 'spr_effects/sword.png'
yield_point()
M['spr_effects.tornado'] = Display.image_load 'spr_effects/tornado.png'
yield_point()
M['spr_effects.waterbolt'] = Display.directional_create(Display.images_load 'spr_effects/waterbolt.32x32.dir.png%32x32')
yield_point()
M['spr_effects.weapon_confusion'] = Display.image_load 'spr_effects/weapon_confusion.png'
yield_point()
M['spr_effects.weapon_poison'] = Display.image_load 'spr_effects/weapon_poison.png'
yield_point()
M['spr_effects.weapon_vampirism'] = Display.image_load 'spr_effects/weapon_vampirism.png'
yield_point()

-- spr_spells resource loads:
M['spr_spells.agony'] = Display.image_load 'spr_spells/agony.png'
yield_point()
M['spr_spells.air_elementals'] = Display.image_load 'spr_spells/air_elementals.png'
yield_point()
M['spr_spells.airstrike'] = Display.image_load 'spr_spells/airstrike.png'
yield_point()
M['spr_spells.alistairs_intoxication'] = Display.image_load 'spr_spells/alistairs_intoxication.png'
yield_point()
M['spr_spells.animate_dead'] = Display.image_load 'spr_spells/animate_dead.png'
yield_point()
M['spr_spells.animate_skeleton'] = Display.image_load 'spr_spells/animate_skeleton.png'
yield_point()
M['spr_spells.apportation'] = Display.image_load 'spr_spells/apportation.png'
yield_point()
M['spr_spells.arrow'] = Display.image_load 'spr_spells/arrow.png'
yield_point()
M['spr_spells.bat_form'] = Display.image_load 'spr_spells/bat_form.png'
yield_point()
M['spr_spells.battlesphere'] = Display.image_load 'spr_spells/battlesphere.png'
yield_point()
M['spr_spells.beastly_appendage'] = Display.image_load 'spr_spells/beastly_appendage.png'
yield_point()
M['spr_spells.beckoning'] = Display.image_load 'spr_spells/beckoning.png'
yield_point()
M['spr_spells.beogh'] = Display.image_load 'spr_spells/beogh.png'
yield_point()
M['spr_spells.berserker_rage'] = Display.image_load 'spr_spells/berserker_rage.png'
yield_point()
M['spr_spells.blade_hands'] = Display.image_load 'spr_spells/blade_hands.png'
yield_point()
M['spr_spells.blink'] = Display.image_load 'spr_spells/blink.png'
yield_point()
M['spr_spells.bolt_corrosive'] = Display.image_load 'spr_spells/bolt_corrosive.png'
yield_point()
M['spr_spells.bolt_explosive'] = Display.image_load 'spr_spells/bolt_explosive.png'
yield_point()
M['spr_spells.bolt_inacc'] = Display.image_load 'spr_spells/bolt_inacc.png'
yield_point()
M['spr_spells.bolt_of_cold'] = Display.image_load 'spr_spells/bolt_of_cold.png'
yield_point()
M['spr_spells.bolt_of_draining'] = Display.image_load 'spr_spells/bolt_of_draining.png'
yield_point()
M['spr_spells.bolt_of_fire'] = Display.image_load 'spr_spells/bolt_of_fire.png'
yield_point()
M['spr_spells.bolt_of_magma'] = Display.image_load 'spr_spells/bolt_of_magma.png'
yield_point()
M['spr_spells.bolt_random'] = Display.image_load 'spr_spells/bolt_random.png'
yield_point()
M['spr_spells.bolt_thunder'] = Display.image_load 'spr_spells/bolt_thunder.png'
yield_point()
M['spr_spells.borgnjors_revivification'] = Display.image_load 'spr_spells/borgnjors_revivification.png'
yield_point()
M['spr_spells.brain_feed'] = Display.image_load 'spr_spells/brain_feed.png'
yield_point()
M['spr_spells.breathe_acid'] = Display.image_load 'spr_spells/breathe_acid.png'
yield_point()
M['spr_spells.breathe_energy'] = Display.image_load 'spr_spells/breathe_energy.png'
yield_point()
M['spr_spells.breathe_fire'] = Display.image_load 'spr_spells/breathe_fire.png'
yield_point()
M['spr_spells.breathe_frost'] = Display.image_load 'spr_spells/breathe_frost.png'
yield_point()
M['spr_spells.breathe_lightning'] = Display.image_load 'spr_spells/breathe_lightning.png'
yield_point()
M['spr_spells.breathe_mephitic'] = Display.image_load 'spr_spells/breathe_mephitic.png'
yield_point()
M['spr_spells.breathe_poison'] = Display.image_load 'spr_spells/breathe_poison.png'
yield_point()
M['spr_spells.breathe_steam'] = Display.image_load 'spr_spells/breathe_steam.png'
yield_point()
M['spr_spells.call_canine_familiar'] = Display.image_load 'spr_spells/call_canine_familiar.png'
yield_point()
M['spr_spells.call_down_damnation'] = Display.image_load 'spr_spells/call_down_damnation.png'
yield_point()
M['spr_spells.call_imp'] = Display.image_load 'spr_spells/call_imp.png'
yield_point()
M['spr_spells.cantrip'] = Display.image_load 'spr_spells/cantrip.png'
yield_point()
M['spr_spells.cause_fear'] = Display.image_load 'spr_spells/cause_fear.png'
yield_point()
M['spr_spells.chain_lightning'] = Display.image_load 'spr_spells/chain_lightning.png'
yield_point()
M['spr_spells.chain_lightning2'] = Display.image_load 'spr_spells/chain_lightning2.png'
yield_point()
M['spr_spells.cigotuvis_embrace'] = Display.image_load 'spr_spells/cigotuvis_embrace.png'
yield_point()
M['spr_spells.cloud'] = Display.animation_create(Display.images_load 'spr_spells/cloud.32x32.png%32x32', 0.1)
yield_point()
M['spr_spells.cloud_cone'] = Display.image_load 'spr_spells/cloud_cone.png'
yield_point()
M['spr_spells.cold_breath'] = Display.image_load 'spr_spells/cold_breath.png'
yield_point()
M['spr_spells.confuse'] = Display.image_load 'spr_spells/confuse.png'
yield_point()
M['spr_spells.confusing_touch'] = Display.image_load 'spr_spells/confusing_touch.png'
yield_point()
M['spr_spells.conjure_ball_lightning'] = Display.image_load 'spr_spells/conjure_ball_lightning.png'
yield_point()
M['spr_spells.conjure_flame'] = Display.image_load 'spr_spells/conjure_flame.png'
yield_point()
M['spr_spells.control_undead'] = Display.image_load 'spr_spells/control_undead.png'
yield_point()
M['spr_spells.controlled_blink'] = Display.image_load 'spr_spells/controlled_blink.png'
yield_point()
M['spr_spells.corona'] = Display.image_load 'spr_spells/corona.png'
yield_point()
M['spr_spells.corpse_rot'] = Display.image_load 'spr_spells/corpse_rot.png'
yield_point()
M['spr_spells.darkness'] = Display.image_load 'spr_spells/darkness.png'
yield_point()
M['spr_spells.dazzling_spray'] = Display.image_load 'spr_spells/dazzling_spray.png'
yield_point()
M['spr_spells.death_channel'] = Display.image_load 'spr_spells/death_channel.png'
yield_point()
M['spr_spells.deaths_door'] = Display.image_load 'spr_spells/deaths_door.png'
yield_point()
M['spr_spells.deflect_missiles'] = Display.image_load 'spr_spells/deflect_missiles.png'
yield_point()
M['spr_spells.delayed_fireball'] = Display.image_load 'spr_spells/delayed_fireball.png'
yield_point()
M['spr_spells.dig'] = Display.image_load 'spr_spells/dig.png'
yield_point()
M['spr_spells.discord'] = Display.image_load 'spr_spells/discord.png'
yield_point()
M['spr_spells.disjunction'] = Display.image_load 'spr_spells/disjunction.png'
yield_point()
M['spr_spells.dispel_undead'] = Display.image_load 'spr_spells/dispel_undead.png'
yield_point()
M['spr_spells.dispersal'] = Display.image_load 'spr_spells/dispersal.png'
yield_point()
M['spr_spells.dragon_form'] = Display.image_load 'spr_spells/dragon_form.png'
yield_point()
M['spr_spells.earth_elementals'] = Display.image_load 'spr_spells/earth_elementals.png'
yield_point()
M['spr_spells.end_transformation'] = Display.image_load 'spr_spells/end_transformation.png'
yield_point()
M['spr_spells.enslavement'] = Display.image_load 'spr_spells/enslavement.png'
yield_point()
M['spr_spells.ensorcelled_hibernation'] = Display.image_load 'spr_spells/ensorcelled_hibernation.png'
yield_point()
M['spr_spells.evoke_berserk'] = Display.image_load 'spr_spells/evoke_berserk.png'
yield_point()
M['spr_spells.evoke_fog'] = Display.image_load 'spr_spells/evoke_fog.png'
yield_point()
M['spr_spells.evoke_invisibility'] = Display.image_load 'spr_spells/evoke_invisibility.png'
yield_point()
M['spr_spells.evoke_invisibility_end'] = Display.image_load 'spr_spells/evoke_invisibility_end.png'
yield_point()
M['spr_spells.excruciating_wounds'] = Display.image_load 'spr_spells/excruciating_wounds.png'
yield_point()
M['spr_spells.fake_mara_summon'] = Display.image_load 'spr_spells/fake_mara_summon.png'
yield_point()
M['spr_spells.fake_rakshasa_summon'] = Display.image_load 'spr_spells/fake_rakshasa_summon.png'
yield_point()
M['spr_spells.fear_strike'] = Display.image_load 'spr_spells/fear_strike.png'
yield_point()
M['spr_spells.fire_breath'] = Display.image_load 'spr_spells/fire_breath.png'
yield_point()
M['spr_spells.fire_elementals'] = Display.image_load 'spr_spells/fire_elementals.png'
yield_point()
M['spr_spells.fire_storm'] = Display.image_load 'spr_spells/fire_storm.png'
yield_point()
M['spr_spells.fireball'] = Display.image_load 'spr_spells/fireball.png'
yield_point()
M['spr_spells.flame_tongue'] = Display.image_load 'spr_spells/flame_tongue.png'
yield_point()
M['spr_spells.flight'] = Display.image_load 'spr_spells/flight.png'
yield_point()
M['spr_spells.flight_end'] = Display.image_load 'spr_spells/flight_end.png'
yield_point()
M['spr_spells.force_lance'] = Display.image_load 'spr_spells/force_lance.png'
yield_point()
M['spr_spells.forgelink'] = Display.image_load 'spr_spells/forgelink.png'
yield_point()
M['spr_spells.freeze'] = Display.image_load 'spr_spells/freeze.png'
yield_point()
M['spr_spells.freezing_cloud'] = Display.image_load 'spr_spells/freezing_cloud.png'
yield_point()
M['spr_spells.fulminant_prism'] = Display.image_load 'spr_spells/fulminant_prism.png'
yield_point()
M['spr_spells.gravitas'] = Display.image_load 'spr_spells/gravitas.png'
yield_point()
M['spr_spells.greaterpain'] = Display.image_load 'spr_spells/greaterpain.png'
yield_point()
M['spr_spells.haste'] = Display.image_load 'spr_spells/haste.png'
yield_point()
M['spr_spells.haste_other'] = Display.image_load 'spr_spells/haste_other.png'
yield_point()
M['spr_spells.haunt'] = Display.image_load 'spr_spells/haunt.png'
yield_point()
M['spr_spells.hurl_damnation'] = Display.image_load 'spr_spells/hurl_damnation.png'
yield_point()
M['spr_spells.hydra_form'] = Display.image_load 'spr_spells/hydra_form.png'
yield_point()
M['spr_spells.ice_form'] = Display.image_load 'spr_spells/ice_form.png'
yield_point()
M['spr_spells.ice_storm'] = Display.image_load 'spr_spells/ice_storm.png'
yield_point()
M['spr_spells.iceblast'] = Display.image_load 'spr_spells/iceblast.png'
yield_point()
M['spr_spells.iceform'] = Display.image_load 'spr_spells/iceform.png'
yield_point()
M['spr_spells.ignite_poison'] = Display.image_load 'spr_spells/ignite_poison.png'
yield_point()
M['spr_spells.infestation'] = Display.image_load 'spr_spells/infestation.png'
yield_point()
M['spr_spells.infusion'] = Display.image_load 'spr_spells/infusion.png'
yield_point()
M['spr_spells.inner_flame'] = Display.image_load 'spr_spells/inner_flame.png'
yield_point()
M['spr_spells.invisibility'] = Display.image_load 'spr_spells/invisibility.png'
yield_point()
M['spr_spells.iron_elementals'] = Display.image_load 'spr_spells/iron_elementals.png'
yield_point()
M['spr_spells.iron_shot'] = Display.image_load 'spr_spells/iron_shot.png'
yield_point()
M['spr_spells.irradiate'] = Display.image_load 'spr_spells/irradiate.png'
yield_point()
M['spr_spells.iskenderuns_mystic_blast'] = Display.image_load 'spr_spells/iskenderuns_mystic_blast.png'
yield_point()
M['spr_spells.ledas_liquefaction'] = Display.image_load 'spr_spells/ledas_liquefaction.png'
yield_point()
M['spr_spells.lees_rapid_deconstruction'] = Display.image_load 'spr_spells/lees_rapid_deconstruction.png'
yield_point()
M['spr_spells.lehudibs_crystal_spear'] = Display.image_load 'spr_spells/lehudibs_crystal_spear.png'
yield_point()
M['spr_spells.lightning_bolt'] = Display.image_load 'spr_spells/lightning_bolt.png'
yield_point()
M['spr_spells.ludaze'] = Display.image_load 'spr_spells/ludaze.png'
yield_point()
M['spr_spells.magic_dart'] = Display.image_load 'spr_spells/magic_dart.png'
yield_point()
M['spr_spells.malign_gateway'] = Display.image_load 'spr_spells/malign_gateway.png'
yield_point()
M['spr_spells.manatake'] = Display.image_load 'spr_spells/manatake.png'
yield_point()
M['spr_spells.mass_abjuration'] = Display.image_load 'spr_spells/mass_abjuration.png'
yield_point()
M['spr_spells.mass_confusion'] = Display.image_load 'spr_spells/mass_confusion.png'
yield_point()
M['spr_spells.memorise'] = Display.image_load 'spr_spells/memorise.png'
yield_point()
M['spr_spells.mephitic_cloud'] = Display.image_load 'spr_spells/mephitic_cloud.png'
yield_point()
M['spr_spells.metabolic_englaciation'] = Display.image_load 'spr_spells/metabolic_englaciation.png'
yield_point()
M['spr_spells.metal_splinters'] = Display.image_load 'spr_spells/metal_splinters.png'
yield_point()
M['spr_spells.miasma_breath'] = Display.image_load 'spr_spells/miasma_breath.png'
yield_point()
M['spr_spells.monstrous_menagerie'] = Display.image_load 'spr_spells/monstrous_menagerie.png'
yield_point()
M['spr_spells.necromutation'] = Display.image_load 'spr_spells/necromutation.png'
yield_point()
M['spr_spells.olgrebs_toxic_radiance'] = Display.image_load 'spr_spells/olgrebs_toxic_radiance.png'
yield_point()
M['spr_spells.orb_of_destruction'] = Display.image_load 'spr_spells/orb_of_destruction.png'
yield_point()
M['spr_spells.ozocubus_armour'] = Display.image_load 'spr_spells/ozocubus_armour.png'
yield_point()
M['spr_spells.ozocubus_refrigeration'] = Display.image_load 'spr_spells/ozocubus_refrigeration.png'
yield_point()
M['spr_spells.pain'] = Display.image_load 'spr_spells/pain.png'
yield_point()
M['spr_spells.paralyse'] = Display.image_load 'spr_spells/paralyse.png'
yield_point()
M['spr_spells.passage_of_golubria'] = Display.image_load 'spr_spells/passage_of_golubria.png'
yield_point()
M['spr_spells.passwall'] = Display.image_load 'spr_spells/passwall.png'
yield_point()
M['spr_spells.petrify'] = Display.image_load 'spr_spells/petrify.png'
yield_point()
M['spr_spells.poison_arrow'] = Display.image_load 'spr_spells/poison_arrow.png'
yield_point()
M['spr_spells.poisonous_cloud'] = Display.image_load 'spr_spells/poisonous_cloud.png'
yield_point()
M['spr_spells.polymorph'] = Display.image_load 'spr_spells/polymorph.png'
yield_point()
M['spr_spells.porkalator'] = Display.image_load 'spr_spells/porkalator.png'
yield_point()
M['spr_spells.portal_projectile'] = Display.image_load 'spr_spells/portal_projectile.png'
yield_point()
M['spr_spells.quicksilver_bolt'] = Display.image_load 'spr_spells/quicksilver_bolt.png'
yield_point()
M['spr_spells.recall'] = Display.image_load 'spr_spells/recall.png'
yield_point()
M['spr_spells.recharge'] = Display.image_load 'spr_spells/recharge.png'
yield_point()
M['spr_spells.regeneration'] = Display.image_load 'spr_spells/regeneration.png'
yield_point()
M['spr_spells.repel_missiles'] = Display.image_load 'spr_spells/repel_missiles.png'
yield_point()
M['spr_spells.ring_of_flames'] = Display.image_load 'spr_spells/ring_of_flames.png'
yield_point()
M['spr_spells.sandblast'] = Display.image_load 'spr_spells/sandblast.png'
yield_point()
M['spr_spells.scattershot'] = Display.image_load 'spr_spells/scattershot.png'
yield_point()
M['spr_spells.searing_ray'] = Display.image_load 'spr_spells/searing_ray.png'
yield_point()
M['spr_spells.shaft_self'] = Display.image_load 'spr_spells/shaft_self.png'
yield_point()
M['spr_spells.shatter'] = Display.image_load 'spr_spells/shatter.png'
yield_point()
M['spr_spells.shock'] = Display.image_load 'spr_spells/shock.png'
yield_point()
M['spr_spells.shroud_of_golubria'] = Display.image_load 'spr_spells/shroud_of_golubria.png'
yield_point()
M['spr_spells.silence'] = Display.image_load 'spr_spells/silence.png'
yield_point()
M['spr_spells.simulacrum'] = Display.image_load 'spr_spells/simulacrum.png'
yield_point()
M['spr_spells.skullthrow'] = Display.image_load 'spr_spells/skullthrow.png'
yield_point()
M['spr_spells.sloading'] = Display.image_load 'spr_spells/sloading.png'
yield_point()
M['spr_spells.slow'] = Display.image_load 'spr_spells/slow.png'
yield_point()
M['spr_spells.song_of_slaying'] = Display.image_load 'spr_spells/song_of_slaying.png'
yield_point()
M['spr_spells.spectral_weapon'] = Display.image_load 'spr_spells/spectral_weapon.png'
yield_point()
M['spr_spells.spell-wall'] = Display.image_load 'spr_spells/spell-wall.png'
yield_point()
M['spr_spells.spell_icon_chain_lightning'] = Display.image_load 'spr_spells/spell_icon_chain_lightning.png'
yield_point()
M['spr_spells.spell_icon_inner_fire'] = Display.image_load 'spr_spells/spell_icon_inner_fire.png'
yield_point()
M['spr_spells.spell_icon_lightning_bolt'] = Display.image_load 'spr_spells/spell_icon_lightning_bolt.png'
yield_point()
M['spr_spells.spell_icon_ring_of_flames'] = Display.image_load 'spr_spells/spell_icon_ring_of_flames.png'
yield_point()
M['spr_spells.spellforged_servitor'] = Display.image_load 'spr_spells/spellforged_servitor.png'
yield_point()
M['spr_spells.spider_form'] = Display.image_load 'spr_spells/spider_form.png'
yield_point()
M['spr_spells.spit_acid'] = Display.image_load 'spr_spells/spit_acid.png'
yield_point()
M['spr_spells.spit_poison'] = Display.image_load 'spr_spells/spit_poison.png'
yield_point()
M['spr_spells.static_discharge'] = Display.image_load 'spr_spells/static_discharge.png'
yield_point()
M['spr_spells.statue_form'] = Display.image_load 'spr_spells/statue_form.png'
yield_point()
M['spr_spells.steam_ball'] = Display.image_load 'spr_spells/steam_ball.png'
yield_point()
M['spr_spells.sticks_to_snakes'] = Display.image_load 'spr_spells/sticks_to_snakes.png'
yield_point()
M['spr_spells.sticky_flame'] = Display.image_load 'spr_spells/sticky_flame.png'
yield_point()
M['spr_spells.sticky_flame_range'] = Display.image_load 'spr_spells/sticky_flame_range.png'
yield_point()
M['spr_spells.sticky_flame_splash'] = Display.image_load 'spr_spells/sticky_flame_splash.png'
yield_point()
M['spr_spells.sting'] = Display.image_load 'spr_spells/sting.png'
yield_point()
M['spr_spells.stone_arrow'] = Display.image_load 'spr_spells/stone_arrow.png'
yield_point()
M['spr_spells.stop_recall'] = Display.image_load 'spr_spells/stop_recall.png'
yield_point()
M['spr_spells.stop_singing'] = Display.image_load 'spr_spells/stop_singing.png'
yield_point()
M['spr_spells.sublimation_of_blood'] = Display.image_load 'spr_spells/sublimation_of_blood.png'
yield_point()
M['spr_spells.summon'] = Display.image_load 'spr_spells/summon.png'
yield_point()
M['spr_spells.summon_butterflies'] = Display.image_load 'spr_spells/summon_butterflies.png'
yield_point()
M['spr_spells.summon_demon'] = Display.image_load 'spr_spells/summon_demon.png'
yield_point()
M['spr_spells.summon_dragon'] = Display.image_load 'spr_spells/summon_dragon.png'
yield_point()
M['spr_spells.summon_drakes'] = Display.image_load 'spr_spells/summon_drakes.png'
yield_point()
M['spr_spells.summon_eyeballs'] = Display.image_load 'spr_spells/summon_eyeballs.png'
yield_point()
M['spr_spells.summon_forest'] = Display.image_load 'spr_spells/summon_forest.png'
yield_point()
M['spr_spells.summon_greater_demon'] = Display.image_load 'spr_spells/summon_greater_demon.png'
yield_point()
M['spr_spells.summon_guardian_golem'] = Display.image_load 'spr_spells/summon_guardian_golem.png'
yield_point()
M['spr_spells.summon_hell_beast'] = Display.image_load 'spr_spells/summon_hell_beast.png'
yield_point()
M['spr_spells.summon_horrible_things'] = Display.image_load 'spr_spells/summon_horrible_things.png'
yield_point()
M['spr_spells.summon_hydra'] = Display.image_load 'spr_spells/summon_hydra.png'
yield_point()
M['spr_spells.summon_ice_beast'] = Display.image_load 'spr_spells/summon_ice_beast.png'
yield_point()
M['spr_spells.summon_lightning_spire'] = Display.image_load 'spr_spells/summon_lightning_spire.png'
yield_point()
M['spr_spells.summon_mana_viper'] = Display.image_load 'spr_spells/summon_mana_viper.png'
yield_point()
M['spr_spells.summon_minor_demon'] = Display.image_load 'spr_spells/summon_minor_demon.png'
yield_point()
M['spr_spells.summon_mushrooms'] = Display.image_load 'spr_spells/summon_mushrooms.png'
yield_point()
M['spr_spells.summon_shadow_creatures'] = Display.image_load 'spr_spells/summon_shadow_creatures.png'
yield_point()
M['spr_spells.summon_small_mammal'] = Display.image_load 'spr_spells/summon_small_mammal.png'
yield_point()
M['spr_spells.summon_ufetubus'] = Display.image_load 'spr_spells/summon_ufetubus.png'
yield_point()
M['spr_spells.summon_undead'] = Display.image_load 'spr_spells/summon_undead.png'
yield_point()
M['spr_spells.summon_vermin'] = Display.image_load 'spr_spells/summon_vermin.png'
yield_point()
M['spr_spells.sure_blade'] = Display.image_load 'spr_spells/sure_blade.png'
yield_point()
M['spr_spells.swiftness'] = Display.image_load 'spr_spells/swiftness.png'
yield_point()
M['spr_spells.symbol_of_torment'] = Display.image_load 'spr_spells/symbol_of_torment.png'
yield_point()
M['spr_spells.symbol_of_torment2'] = Display.image_load 'spr_spells/symbol_of_torment2.png'
yield_point()
M['spr_spells.teleport_other'] = Display.image_load 'spr_spells/teleport_other.png'
yield_point()
M['spr_spells.throw_flame'] = Display.image_load 'spr_spells/throw_flame.png'
yield_point()
M['spr_spells.throw_frost'] = Display.image_load 'spr_spells/throw_frost.png'
yield_point()
M['spr_spells.throw_icicle'] = Display.image_load 'spr_spells/throw_icicle.png'
yield_point()
M['spr_spells.tornado'] = Display.image_load 'spr_spells/tornado.png'
yield_point()
M['spr_spells.tukimas_dance'] = Display.image_load 'spr_spells/tukimas_dance.png'
yield_point()
M['spr_spells.twisted_resurrection'] = Display.image_load 'spr_spells/twisted_resurrection.png'
yield_point()
M['spr_spells.unlink'] = Display.image_load 'spr_spells/unlink.png'
yield_point()
M['spr_spells.vampiric_draining'] = Display.image_load 'spr_spells/vampiric_draining.png'
yield_point()
M['spr_spells.venom_bolt'] = Display.image_load 'spr_spells/venom_bolt.png'
yield_point()
M['spr_spells.violent_unravelling'] = Display.image_load 'spr_spells/violent_unravelling.png'
yield_point()
M['spr_spells.water_elementals'] = Display.image_load 'spr_spells/water_elementals.png'
yield_point()

-- spr_amulets resource loads:
M['spr_amulets.amethyst'] = Display.image_load 'spr_amulets/amethyst.png'
yield_point()
M['spr_amulets.berserk'] = Display.image_load 'spr_amulets/berserk.png'
yield_point()
M['spr_amulets.beryl'] = Display.image_load 'spr_amulets/beryl.png'
yield_point()
M['spr_amulets.blue'] = Display.image_load 'spr_amulets/blue.png'
yield_point()
M['spr_amulets.bone'] = Display.image_load 'spr_amulets/bone.png'
yield_point()
M['spr_amulets.brass'] = Display.image_load 'spr_amulets/brass.png'
yield_point()
M['spr_amulets.bronze'] = Display.image_load 'spr_amulets/bronze.png'
yield_point()
M['spr_amulets.cabochon'] = Display.image_load 'spr_amulets/cabochon.png'
yield_point()
M['spr_amulets.cameo'] = Display.image_load 'spr_amulets/cameo.png'
yield_point()
M['spr_amulets.citrine'] = Display.image_load 'spr_amulets/citrine.png'
yield_point()
M['spr_amulets.copper'] = Display.image_load 'spr_amulets/copper.png'
yield_point()
M['spr_amulets.diamond'] = Display.image_load 'spr_amulets/diamond.png'
yield_point()
M['spr_amulets.emerald'] = Display.image_load 'spr_amulets/emerald.png'
yield_point()
M['spr_amulets.fear_strike'] = Display.image_load 'spr_amulets/fear_strike.png'
yield_point()
M['spr_amulets.filigree'] = Display.image_load 'spr_amulets/filigree.png'
yield_point()
M['spr_amulets.fireball'] = Display.image_load 'spr_amulets/fireball.png'
yield_point()
M['spr_amulets.flourescent'] = Display.image_load 'spr_amulets/flourescent.png'
yield_point()
M['spr_amulets.garnet'] = Display.image_load 'spr_amulets/garnet.png'
yield_point()
M['spr_amulets.golden'] = Display.image_load 'spr_amulets/golden.png'
yield_point()
M['spr_amulets.greaterfireball'] = Display.image_load 'spr_amulets/greaterfireball.png'
yield_point()
M['spr_amulets.greaterpain'] = Display.image_load 'spr_amulets/greaterpain.png'
yield_point()
M['spr_amulets.greed'] = Display.image_load 'spr_amulets/greed.png'
yield_point()
M['spr_amulets.healing'] = Display.image_load 'spr_amulets/healing.png'
yield_point()
M['spr_amulets.i-dismissal'] = Display.image_load 'spr_amulets/i-dismissal.png'
yield_point()
M['spr_amulets.i-faith'] = Display.image_load 'spr_amulets/i-faith.png'
yield_point()
M['spr_amulets.i-gourmand'] = Display.image_load 'spr_amulets/i-gourmand.png'
yield_point()
M['spr_amulets.i-harm'] = Display.image_load 'spr_amulets/i-harm.png'
yield_point()
M['spr_amulets.i-inaccuracy'] = Display.image_load 'spr_amulets/i-inaccuracy.png'
yield_point()
M['spr_amulets.i-m-regeneration'] = Display.image_load 'spr_amulets/i-m-regeneration.png'
yield_point()
M['spr_amulets.i-rage'] = Display.image_load 'spr_amulets/i-rage.png'
yield_point()
M['spr_amulets.i-reflection'] = Display.image_load 'spr_amulets/i-reflection.png'
yield_point()
M['spr_amulets.i-regeneration'] = Display.image_load 'spr_amulets/i-regeneration.png'
yield_point()
M['spr_amulets.i-spirit'] = Display.image_load 'spr_amulets/i-spirit.png'
yield_point()
M['spr_amulets.iceform'] = Display.image_load 'spr_amulets/iceform.png'
yield_point()
M['spr_amulets.jade'] = Display.image_load 'spr_amulets/jade.png'
yield_point()
M['spr_amulets.jasper'] = Display.image_load 'spr_amulets/jasper.png'
yield_point()
M['spr_amulets.lapis_lazuli'] = Display.image_load 'spr_amulets/lapis_lazuli.png'
yield_point()
M['spr_amulets.light'] = Display.image_load 'spr_amulets/light.png'
yield_point()
M['spr_amulets.malachite'] = Display.image_load 'spr_amulets/malachite.png'
yield_point()
M['spr_amulets.pain'] = Display.image_load 'spr_amulets/pain.png'
yield_point()
M['spr_amulets.pearl'] = Display.image_load 'spr_amulets/pearl.png'
yield_point()
M['spr_amulets.peridot'] = Display.image_load 'spr_amulets/peridot.png'
yield_point()
M['spr_amulets.platinum'] = Display.image_load 'spr_amulets/platinum.png'
yield_point()
M['spr_amulets.protect'] = Display.image_load 'spr_amulets/protect.png'
yield_point()
M['spr_amulets.regeneration'] = Display.image_load 'spr_amulets/regeneration.png'
yield_point()
M['spr_amulets.ruby'] = Display.image_load 'spr_amulets/ruby.png'
yield_point()
M['spr_amulets.sapphire'] = Display.image_load 'spr_amulets/sapphire.png'
yield_point()
M['spr_amulets.silver'] = Display.image_load 'spr_amulets/silver.png'
yield_point()
M['spr_amulets.skull'] = Display.image_load 'spr_amulets/skull.png'
yield_point()
M['spr_amulets.soapstone'] = Display.image_load 'spr_amulets/soapstone.png'
yield_point()
M['spr_amulets.spider'] = Display.image_load 'spr_amulets/spider.png'
yield_point()
M['spr_amulets.steel'] = Display.image_load 'spr_amulets/steel.png'
yield_point()
M['spr_amulets.urand_bloodlust'] = Display.image_load 'spr_amulets/urand_bloodlust.png'
yield_point()
M['spr_amulets.zirconium'] = Display.image_load 'spr_amulets/zirconium.png'
yield_point()

-- spr_belts resource loads:
M['spr_belts.base-belt'] = Display.image_load 'spr_belts/base-belt.png'
yield_point()
M['spr_belts.life-belt'] = Display.image_load 'spr_belts/life-belt.png'
yield_point()
M['spr_belts.poison'] = Display.image_load 'spr_belts/poison.png'
yield_point()
M['spr_belts.protection'] = Display.image_load 'spr_belts/protection.png'
yield_point()
M['spr_belts.slaying'] = Display.image_load 'spr_belts/slaying.png'
yield_point()
M['spr_belts.spike'] = Display.image_load 'spr_belts/spike.png'
yield_point()
M['spr_belts.warped'] = Display.image_load 'spr_belts/warped.png'
yield_point()
M['spr_belts.wishful'] = Display.image_load 'spr_belts/wishful.png'
yield_point()

-- spr_legwear resource loads:
M['spr_legwear.gallanthorskirt'] = Display.image_load 'spr_legwear/gallanthorskirt.png'
yield_point()
M['spr_legwear.platelegs'] = Display.image_load 'spr_legwear/platelegs.png'
yield_point()
M['spr_legwear.skirt'] = Display.image_load 'spr_legwear/skirt.png'
yield_point()

-- spr_boots resource loads:
M['spr_boots.boots1_brown'] = Display.image_load 'spr_boots/boots1_brown.png'
yield_point()
M['spr_boots.boots2_jackboots'] = Display.image_load 'spr_boots/boots2_jackboots.png'
yield_point()
M['spr_boots.boots3_stripe'] = Display.image_load 'spr_boots/boots3_stripe.png'
yield_point()
M['spr_boots.boots4_green'] = Display.image_load 'spr_boots/boots4_green.png'
yield_point()
M['spr_boots.boots_iron2'] = Display.image_load 'spr_boots/boots_iron2.png'
yield_point()
M['spr_boots.festive_boots'] = Display.image_load 'spr_boots/festive_boots.png'
yield_point()
M['spr_boots.randart_leather_boots'] = Display.image_load 'spr_boots/randart_leather_boots.png'
yield_point()
M['spr_boots.shield2'] = Display.image_load 'spr_boots/shield2.png'
yield_point()
M['spr_boots.urand_assassin'] = Display.image_load 'spr_boots/urand_assassin.png'
yield_point()
M['spr_boots.urand_spider'] = Display.image_load 'spr_boots/urand_spider.png'
yield_point()

-- spr_scrolls resource loads:
M['spr_scrolls.acquirement'] = Display.image_load 'spr_scrolls/acquirement.png'
yield_point()
M['spr_scrolls.fear'] = Display.image_load 'spr_scrolls/fear.png'
yield_point()
M['spr_scrolls.identify'] = Display.image_load 'spr_scrolls/identify.png'
yield_point()
M['spr_scrolls.magic-map'] = Display.image_load 'spr_scrolls/magic-map.png'
yield_point()
M['spr_scrolls.red_mana_potion'] = Display.image_load 'spr_scrolls/red_mana_potion.png'
yield_point()
M['spr_scrolls.teleportation'] = Display.image_load 'spr_scrolls/teleportation.png'
yield_point()
M['spr_scrolls.vulnerability'] = Display.image_load 'spr_scrolls/vulnerability.png'
yield_point()

-- spr_runes resource loads:
M['spr_runes.generic'] = Display.image_load 'spr_runes/generic.png'
yield_point()
M['spr_runes.rune_abyss'] = Display.image_load 'spr_runes/rune_abyss.png'
yield_point()
M['spr_runes.rune_cerebov'] = Display.image_load 'spr_runes/rune_cerebov.png'
yield_point()
M['spr_runes.rune_cocytus'] = Display.image_load 'spr_runes/rune_cocytus.png'
yield_point()
M['spr_runes.rune_demonic_1'] = Display.image_load 'spr_runes/rune_demonic_1.png'
yield_point()
M['spr_runes.rune_demonic_2'] = Display.image_load 'spr_runes/rune_demonic_2.png'
yield_point()
M['spr_runes.rune_demonic_3'] = Display.image_load 'spr_runes/rune_demonic_3.png'
yield_point()
M['spr_runes.rune_demonic_4'] = Display.image_load 'spr_runes/rune_demonic_4.png'
yield_point()
M['spr_runes.rune_demonic_5'] = Display.image_load 'spr_runes/rune_demonic_5.png'
yield_point()
M['spr_runes.rune_demonic_6'] = Display.image_load 'spr_runes/rune_demonic_6.png'
yield_point()
M['spr_runes.rune_dis'] = Display.image_load 'spr_runes/rune_dis.png'
yield_point()
M['spr_runes.rune_elven'] = Display.image_load 'spr_runes/rune_elven.png'
yield_point()
M['spr_runes.rune_gehenna'] = Display.image_load 'spr_runes/rune_gehenna.png'
yield_point()
M['spr_runes.rune_gloorx_vloq'] = Display.image_load 'spr_runes/rune_gloorx_vloq.png'
yield_point()
M['spr_runes.rune_lom_lobon'] = Display.image_load 'spr_runes/rune_lom_lobon.png'
yield_point()
M['spr_runes.rune_mnoleg'] = Display.image_load 'spr_runes/rune_mnoleg.png'
yield_point()
M['spr_runes.rune_shoals'] = Display.image_load 'spr_runes/rune_shoals.png'
yield_point()
M['spr_runes.rune_slime'] = Display.image_load 'spr_runes/rune_slime.png'
yield_point()
M['spr_runes.rune_snake'] = Display.image_load 'spr_runes/rune_snake.png'
yield_point()
M['spr_runes.rune_spider'] = Display.image_load 'spr_runes/rune_spider.png'
yield_point()
M['spr_runes.rune_swamp'] = Display.image_load 'spr_runes/rune_swamp.png'
yield_point()
M['spr_runes.rune_tartarus'] = Display.image_load 'spr_runes/rune_tartarus.png'
yield_point()
M['spr_runes.rune_tomb'] = Display.image_load 'spr_runes/rune_tomb.png'
yield_point()
M['spr_runes.rune_vaults'] = Display.image_load 'spr_runes/rune_vaults.png'
yield_point()

-- spr_gates resource loads:
M['spr_gates.abyssal_stair'] = Display.image_load 'spr_gates/abyssal_stair.png'
yield_point()
M['spr_gates.bailey_gone'] = Display.image_load 'spr_gates/bailey_gone.png'
yield_point()
M['spr_gates.bailey_portal'] = Display.image_load 'spr_gates/bailey_portal.png'
yield_point()
M['spr_gates.bazaar_gone'] = Display.image_load 'spr_gates/bazaar_gone.png'
yield_point()
M['spr_gates.bazaar_portal'] = Display.image_load 'spr_gates/bazaar_portal.png'
yield_point()
M['spr_gates.chest-closed'] = Display.image_load 'spr_gates/chest-closed.png'
yield_point()
M['spr_gates.chest-open'] = Display.image_load 'spr_gates/chest-open.png'
yield_point()
M['spr_gates.desolation_portal'] = Display.image_load 'spr_gates/desolation_portal.png'
yield_point()
M['spr_gates.desolation_portal_closed'] = Display.image_load 'spr_gates/desolation_portal_closed.png'
yield_point()
M['spr_gates.enter'] = Display.image_load 'spr_gates/enter.png'
yield_point()
M['spr_gates.enter_abyss1'] = Display.image_load 'spr_gates/enter_abyss1.png'
yield_point()
M['spr_gates.enter_abyss2'] = Display.image_load 'spr_gates/enter_abyss2.png'
yield_point()
M['spr_gates.enter_abyss3'] = Display.image_load 'spr_gates/enter_abyss3.png'
yield_point()
M['spr_gates.enter_cocytus1'] = Display.image_load 'spr_gates/enter_cocytus1.png'
yield_point()
M['spr_gates.enter_cocytus2'] = Display.image_load 'spr_gates/enter_cocytus2.png'
yield_point()
M['spr_gates.enter_cocytus3'] = Display.image_load 'spr_gates/enter_cocytus3.png'
yield_point()
M['spr_gates.enter_crypt'] = Display.image_load 'spr_gates/enter_crypt.png'
yield_point()
M['spr_gates.enter_depths'] = Display.image_load 'spr_gates/enter_depths.png'
yield_point()
M['spr_gates.enter_dis1'] = Display.image_load 'spr_gates/enter_dis1.png'
yield_point()
M['spr_gates.enter_dis2'] = Display.image_load 'spr_gates/enter_dis2.png'
yield_point()
M['spr_gates.enter_dis3'] = Display.image_load 'spr_gates/enter_dis3.png'
yield_point()
M['spr_gates.enter_elf'] = Display.image_load 'spr_gates/enter_elf.png'
yield_point()
M['spr_gates.enter_gehenna1'] = Display.image_load 'spr_gates/enter_gehenna1.png'
yield_point()
M['spr_gates.enter_gehenna2'] = Display.image_load 'spr_gates/enter_gehenna2.png'
yield_point()
M['spr_gates.enter_gehenna3'] = Display.image_load 'spr_gates/enter_gehenna3.png'
yield_point()
M['spr_gates.enter_hell1'] = Display.image_load 'spr_gates/enter_hell1.png'
yield_point()
M['spr_gates.enter_hell2'] = Display.image_load 'spr_gates/enter_hell2.png'
yield_point()
M['spr_gates.enter_hell3'] = Display.image_load 'spr_gates/enter_hell3.png'
yield_point()
M['spr_gates.enter_lair'] = Display.image_load 'spr_gates/enter_lair.png'
yield_point()
M['spr_gates.enter_orc'] = Display.image_load 'spr_gates/enter_orc.png'
yield_point()
M['spr_gates.enter_pandemonium'] = Display.image_load 'spr_gates/enter_pandemonium.png'
yield_point()
M['spr_gates.enter_shoals'] = Display.image_load 'spr_gates/enter_shoals.png'
yield_point()
M['spr_gates.enter_slime'] = Display.image_load 'spr_gates/enter_slime.png'
yield_point()
M['spr_gates.enter_snake'] = Display.image_load 'spr_gates/enter_snake.png'
yield_point()
M['spr_gates.enter_spider'] = Display.image_load 'spr_gates/enter_spider.png'
yield_point()
M['spr_gates.enter_swamp'] = Display.image_load 'spr_gates/enter_swamp.png'
yield_point()
M['spr_gates.enter_tartarus1'] = Display.image_load 'spr_gates/enter_tartarus1.png'
yield_point()
M['spr_gates.enter_tartarus2'] = Display.image_load 'spr_gates/enter_tartarus2.png'
yield_point()
M['spr_gates.enter_tartarus3'] = Display.image_load 'spr_gates/enter_tartarus3.png'
yield_point()
M['spr_gates.enter_temple'] = Display.image_load 'spr_gates/enter_temple.png'
yield_point()
M['spr_gates.enter_tomb'] = Display.image_load 'spr_gates/enter_tomb.png'
yield_point()
M['spr_gates.enter_vaults_closed'] = Display.image_load 'spr_gates/enter_vaults_closed.png'
yield_point()
M['spr_gates.enter_vaults_open'] = Display.image_load 'spr_gates/enter_vaults_open.png'
yield_point()
M['spr_gates.enter_zot_closed'] = Display.image_load 'spr_gates/enter_zot_closed.png'
yield_point()
M['spr_gates.enter_zot_open'] = Display.image_load 'spr_gates/enter_zot_open.png'
yield_point()
M['spr_gates.epic_store'] = Display.image_load 'spr_gates/epic_store.png'
yield_point()
M['spr_gates.escape_hatch_down'] = Display.image_load 'spr_gates/escape_hatch_down.png'
yield_point()
M['spr_gates.escape_hatch_up'] = Display.image_load 'spr_gates/escape_hatch_up.png'
yield_point()
M['spr_gates.exit_abyss'] = Display.image_load 'spr_gates/exit_abyss.png'
yield_point()
M['spr_gates.exit_abyss_flickering'] = Display.image_load 'spr_gates/exit_abyss_flickering.png'
yield_point()
M['spr_gates.exit_crypt'] = Display.image_load 'spr_gates/exit_crypt.png'
yield_point()
M['spr_gates.exit_dungeon'] = Display.image_load 'spr_gates/exit_dungeon.png'
yield_point()
M['spr_gates.exit_elf'] = Display.image_load 'spr_gates/exit_elf.png'
yield_point()
M['spr_gates.exit_lair'] = Display.image_load 'spr_gates/exit_lair.png'
yield_point()
M['spr_gates.exit_orc'] = Display.image_load 'spr_gates/exit_orc.png'
yield_point()
M['spr_gates.exit_pandemonium'] = Display.image_load 'spr_gates/exit_pandemonium.png'
yield_point()
M['spr_gates.exit_pandemonium_flickering'] = Display.image_load 'spr_gates/exit_pandemonium_flickering.png'
yield_point()
M['spr_gates.exit_shoals'] = Display.image_load 'spr_gates/exit_shoals.png'
yield_point()
M['spr_gates.exit_slime'] = Display.image_load 'spr_gates/exit_slime.png'
yield_point()
M['spr_gates.exit_snake'] = Display.image_load 'spr_gates/exit_snake.png'
yield_point()
M['spr_gates.exit_spider'] = Display.image_load 'spr_gates/exit_spider.png'
yield_point()
M['spr_gates.exit_swamp'] = Display.image_load 'spr_gates/exit_swamp.png'
yield_point()
M['spr_gates.exit_temple'] = Display.image_load 'spr_gates/exit_temple.png'
yield_point()
M['spr_gates.exit_tomb'] = Display.image_load 'spr_gates/exit_tomb.png'
yield_point()
M['spr_gates.exit_vaults'] = Display.image_load 'spr_gates/exit_vaults.png'
yield_point()
M['spr_gates.expired_portal'] = Display.image_load 'spr_gates/expired_portal.png'
yield_point()
M['spr_gates.ice_cave_gone'] = Display.image_load 'spr_gates/ice_cave_gone.png'
yield_point()
M['spr_gates.ice_cave_portal'] = Display.image_load 'spr_gates/ice_cave_portal.png'
yield_point()
M['spr_gates.lab_gone'] = Display.image_load 'spr_gates/lab_gone.png'
yield_point()
M['spr_gates.lab_portal'] = Display.image_load 'spr_gates/lab_portal.png'
yield_point()
M['spr_gates.ossuary_gone'] = Display.image_load 'spr_gates/ossuary_gone.png'
yield_point()
M['spr_gates.ossuary_portal'] = Display.image_load 'spr_gates/ossuary_portal.png'
yield_point()
M['spr_gates.portal'] = Display.image_load 'spr_gates/portal.png'
yield_point()
M['spr_gates.portal_rotated'] = Display.image_load 'spr_gates/portal_rotated.png'
yield_point()
M['spr_gates.portal_unknown'] = Display.image_load 'spr_gates/portal_unknown.png'
yield_point()
M['spr_gates.return'] = Display.image_load 'spr_gates/return.png'
yield_point()
M['spr_gates.return_depths'] = Display.image_load 'spr_gates/return_depths.png'
yield_point()
M['spr_gates.return_hell'] = Display.image_load 'spr_gates/return_hell.png'
yield_point()
M['spr_gates.return_vestibule'] = Display.image_load 'spr_gates/return_vestibule.png'
yield_point()
M['spr_gates.return_zot'] = Display.image_load 'spr_gates/return_zot.png'
yield_point()
M['spr_gates.sealed_stairs_down'] = Display.image_load 'spr_gates/sealed_stairs_down.png'
yield_point()
M['spr_gates.sealed_stairs_up'] = Display.image_load 'spr_gates/sealed_stairs_up.png'
yield_point()
M['spr_gates.sewer_portal'] = Display.image_load 'spr_gates/sewer_portal.png'
yield_point()
M['spr_gates.sewer_portal_rusted'] = Display.image_load 'spr_gates/sewer_portal_rusted.png'
yield_point()
M['spr_gates.shoals_stairs_down'] = Display.image_load 'spr_gates/shoals_stairs_down.png'
yield_point()
M['spr_gates.shoals_stairs_up'] = Display.image_load 'spr_gates/shoals_stairs_up.png'
yield_point()
M['spr_gates.starry_portal'] = Display.image_load 'spr_gates/starry_portal.png'
yield_point()
M['spr_gates.stone_arch'] = Display.image_load 'spr_gates/stone_arch.png'
yield_point()
M['spr_gates.stone_arch_hell'] = Display.image_load 'spr_gates/stone_arch_hell.png'
yield_point()
M['spr_gates.stone_stairs_down'] = Display.image_load 'spr_gates/stone_stairs_down.png'
yield_point()
M['spr_gates.stone_stairs_up'] = Display.image_load 'spr_gates/stone_stairs_up.png'
yield_point()
M['spr_gates.transit_pandemonium'] = Display.image_load 'spr_gates/transit_pandemonium.png'
yield_point()
M['spr_gates.trove_gone'] = Display.image_load 'spr_gates/trove_gone.png'
yield_point()
M['spr_gates.trove_portal'] = Display.image_load 'spr_gates/trove_portal.png'
yield_point()
M['spr_gates.volcano_exit'] = Display.image_load 'spr_gates/volcano_exit.png'
yield_point()
M['spr_gates.volcano_gone'] = Display.image_load 'spr_gates/volcano_gone.png'
yield_point()
M['spr_gates.volcano_portal'] = Display.image_load 'spr_gates/volcano_portal.png'
yield_point()
M['spr_gates.wizlab_gone'] = Display.image_load 'spr_gates/wizlab_gone.png'
yield_point()
M['spr_gates.wizlab_portal0'] = Display.image_load 'spr_gates/wizlab_portal0.png'
yield_point()
M['spr_gates.wizlab_portal1'] = Display.image_load 'spr_gates/wizlab_portal1.png'
yield_point()
M['spr_gates.wizlab_portal2'] = Display.image_load 'spr_gates/wizlab_portal2.png'
yield_point()
M['spr_gates.wizlab_portal3'] = Display.image_load 'spr_gates/wizlab_portal3.png'
yield_point()
M['spr_gates.wizlab_portal4'] = Display.image_load 'spr_gates/wizlab_portal4.png'
yield_point()
M['spr_gates.wizlab_portal5'] = Display.image_load 'spr_gates/wizlab_portal5.png'
yield_point()
M['spr_gates.wizlab_portal6'] = Display.image_load 'spr_gates/wizlab_portal6.png'
yield_point()
M['spr_gates.wizlab_portal7'] = Display.image_load 'spr_gates/wizlab_portal7.png'
yield_point()
M['spr_gates.zig_portal'] = Display.image_load 'spr_gates/zig_portal.png'
yield_point()
M['spr_gates.zig_used'] = Display.image_load 'spr_gates/zig_used.png'
yield_point()

-- spr_enemies resource loads:
M['spr_enemies.good_neutral'] = Display.image_load 'spr_enemies/good_neutral.png'
yield_point()

-- spr_enemies/undead resource loads:
M['spr_enemies.undead.ancient_champion'] = Display.image_load 'spr_enemies/undead/ancient_champion.png'
yield_point()
M['spr_enemies.undead.ancient_lich'] = Display.image_load 'spr_enemies/undead/ancient_lich.png'
yield_point()
M['spr_enemies.undead.bog_body'] = Display.image_load 'spr_enemies/undead/bog_body.png'
yield_point()
M['spr_enemies.undead.bone_dragon'] = Display.image_load 'spr_enemies/undead/bone_dragon.png'
yield_point()
M['spr_enemies.undead.crawling_corpse'] = Display.image_load 'spr_enemies/undead/crawling_corpse.png'
yield_point()
M['spr_enemies.undead.curse_skull'] = Display.image_load 'spr_enemies/undead/curse_skull.png'
yield_point()
M['spr_enemies.undead.curse_toe'] = Display.image_load 'spr_enemies/undead/curse_toe.png'
yield_point()
M['spr_enemies.undead.death_cob'] = Display.image_load 'spr_enemies/undead/death_cob.png'
yield_point()
M['spr_enemies.undead.death_scarab'] = Display.image_load 'spr_enemies/undead/death_scarab.png'
yield_point()
M['spr_enemies.undead.drowned_soul'] = Display.image_load 'spr_enemies/undead/drowned_soul.png'
yield_point()
M['spr_enemies.undead.eidolon'] = Display.image_load 'spr_enemies/undead/eidolon.png'
yield_point()
M['spr_enemies.undead.flayed_ghost'] = Display.image_load 'spr_enemies/undead/flayed_ghost.png'
yield_point()
M['spr_enemies.undead.flying_skull'] = Display.image_load 'spr_enemies/undead/flying_skull.png'
yield_point()
M['spr_enemies.undead.freezing_wraith'] = Display.image_load 'spr_enemies/undead/freezing_wraith.png'
yield_point()
M['spr_enemies.undead.ghost'] = Display.image_load 'spr_enemies/undead/ghost.png'
yield_point()
M['spr_enemies.undead.ghoul'] = Display.image_load 'spr_enemies/undead/ghoul.png'
yield_point()
M['spr_enemies.undead.greater_mummy'] = Display.image_load 'spr_enemies/undead/greater_mummy.png'
yield_point()
M['spr_enemies.undead.guardian_mummy'] = Display.image_load 'spr_enemies/undead/guardian_mummy.png'
yield_point()
M['spr_enemies.undead.halazid_warlock'] = Display.image_load 'spr_enemies/undead/halazid_warlock.png'
yield_point()
M['spr_enemies.undead.hungry_ghost'] = Display.image_load 'spr_enemies/undead/hungry_ghost.png'
yield_point()
M['spr_enemies.undead.jiangshi'] = Display.image_load 'spr_enemies/undead/jiangshi.png'
yield_point()
M['spr_enemies.undead.lich'] = Display.image_load 'spr_enemies/undead/lich.png'
yield_point()
M['spr_enemies.undead.lost_soul'] = Display.image_load 'spr_enemies/undead/lost_soul.png'
yield_point()
M['spr_enemies.undead.macabre_mass'] = Display.image_load 'spr_enemies/undead/macabre_mass.png'
yield_point()
M['spr_enemies.undead.missing_ghost'] = Display.image_load 'spr_enemies/undead/missing_ghost.png'
yield_point()
M['spr_enemies.undead.mummy'] = Display.image_load 'spr_enemies/undead/mummy.png'
yield_point()
M['spr_enemies.undead.mummy_priest'] = Display.image_load 'spr_enemies/undead/mummy_priest.png'
yield_point()
M['spr_enemies.undead.necrophage'] = Display.image_load 'spr_enemies/undead/necrophage.png'
yield_point()
M['spr_enemies.undead.phantasmal_warrior'] = Display.image_load 'spr_enemies/undead/phantasmal_warrior.png'
yield_point()
M['spr_enemies.undead.phantom'] = Display.image_load 'spr_enemies/undead/phantom.png'
yield_point()
M['spr_enemies.undead.profane_servitor'] = Display.image_load 'spr_enemies/undead/profane_servitor.png'
yield_point()
M['spr_enemies.undead.revenant'] = Display.image_load 'spr_enemies/undead/revenant.png'
yield_point()
M['spr_enemies.undead.shadow'] = Display.image_load 'spr_enemies/undead/shadow.png'
yield_point()
M['spr_enemies.undead.shadow_wraith'] = Display.image_load 'spr_enemies/undead/shadow_wraith.png'
yield_point()
M['spr_enemies.undead.silent_spectre'] = Display.image_load 'spr_enemies/undead/silent_spectre.png'
yield_point()
M['spr_enemies.undead.skeletal_warrior'] = Display.image_load 'spr_enemies/undead/skeletal_warrior.png'
yield_point()
M['spr_enemies.undead.skeleton_bat'] = Display.image_load 'spr_enemies/undead/skeleton_bat.png'
yield_point()
M['spr_enemies.undead.skeleton_bird'] = Display.image_load 'spr_enemies/undead/skeleton_bird.png'
yield_point()
M['spr_enemies.undead.skeleton_centaur'] = Display.image_load 'spr_enemies/undead/skeleton_centaur.png'
yield_point()
M['spr_enemies.undead.skeleton_dragon'] = Display.image_load 'spr_enemies/undead/skeleton_dragon.png'
yield_point()
M['spr_enemies.undead.skeleton_drake'] = Display.image_load 'spr_enemies/undead/skeleton_drake.png'
yield_point()
M['spr_enemies.undead.skeleton_fish'] = Display.image_load 'spr_enemies/undead/skeleton_fish.png'
yield_point()
M['spr_enemies.undead.skeleton_frog'] = Display.image_load 'spr_enemies/undead/skeleton_frog.png'
yield_point()
M['spr_enemies.undead.skeleton_humanoid_large'] = Display.image_load 'spr_enemies/undead/skeleton_humanoid_large.png'
yield_point()
M['spr_enemies.undead.skeleton_humanoid_medium'] = Display.image_load 'spr_enemies/undead/skeleton_humanoid_medium.png'
yield_point()
M['spr_enemies.undead.skeleton_humanoid_small'] = Display.image_load 'spr_enemies/undead/skeleton_humanoid_small.png'
yield_point()
M['spr_enemies.undead.skeleton_hydra1'] = Display.image_load 'spr_enemies/undead/skeleton_hydra1.png'
yield_point()
M['spr_enemies.undead.skeleton_hydra2'] = Display.image_load 'spr_enemies/undead/skeleton_hydra2.png'
yield_point()
M['spr_enemies.undead.skeleton_hydra3'] = Display.image_load 'spr_enemies/undead/skeleton_hydra3.png'
yield_point()
M['spr_enemies.undead.skeleton_hydra4'] = Display.image_load 'spr_enemies/undead/skeleton_hydra4.png'
yield_point()
M['spr_enemies.undead.skeleton_hydra5'] = Display.image_load 'spr_enemies/undead/skeleton_hydra5.png'
yield_point()
M['spr_enemies.undead.skeleton_lizard'] = Display.image_load 'spr_enemies/undead/skeleton_lizard.png'
yield_point()
M['spr_enemies.undead.skeleton_naga'] = Display.image_load 'spr_enemies/undead/skeleton_naga.png'
yield_point()
M['spr_enemies.undead.skeleton_quadruped_large'] = Display.image_load 'spr_enemies/undead/skeleton_quadruped_large.png'
yield_point()
M['spr_enemies.undead.skeleton_quadruped_small'] = Display.image_load 'spr_enemies/undead/skeleton_quadruped_small.png'
yield_point()
M['spr_enemies.undead.skeleton_quadruped_winged'] = Display.image_load 'spr_enemies/undead/skeleton_quadruped_winged.png'
yield_point()
M['spr_enemies.undead.skeleton_snake'] = Display.image_load 'spr_enemies/undead/skeleton_snake.png'
yield_point()
M['spr_enemies.undead.skeleton_troll'] = Display.image_load 'spr_enemies/undead/skeleton_troll.png'
yield_point()
M['spr_enemies.undead.skeleton_turtle'] = Display.image_load 'spr_enemies/undead/skeleton_turtle.png'
yield_point()
M['spr_enemies.undead.skeleton_ugly_thing'] = Display.image_load 'spr_enemies/undead/skeleton_ugly_thing.png'
yield_point()
M['spr_enemies.undead.spectral_ant'] = Display.image_load 'spr_enemies/undead/spectral_ant.png'
yield_point()
M['spr_enemies.undead.spectral_bat'] = Display.image_load 'spr_enemies/undead/spectral_bat.png'
yield_point()
M['spr_enemies.undead.spectral_bee'] = Display.image_load 'spr_enemies/undead/spectral_bee.png'
yield_point()
M['spr_enemies.undead.spectral_centaur'] = Display.image_load 'spr_enemies/undead/spectral_centaur.png'
yield_point()
M['spr_enemies.undead.spectral_dragon'] = Display.image_load 'spr_enemies/undead/spectral_dragon.png'
yield_point()
M['spr_enemies.undead.spectral_drake'] = Display.image_load 'spr_enemies/undead/spectral_drake.png'
yield_point()
M['spr_enemies.undead.spectral_fish'] = Display.image_load 'spr_enemies/undead/spectral_fish.png'
yield_point()
M['spr_enemies.undead.spectral_frog'] = Display.image_load 'spr_enemies/undead/spectral_frog.png'
yield_point()
M['spr_enemies.undead.spectral_hydra1'] = Display.image_load 'spr_enemies/undead/spectral_hydra1.png'
yield_point()
M['spr_enemies.undead.spectral_hydra2'] = Display.image_load 'spr_enemies/undead/spectral_hydra2.png'
yield_point()
M['spr_enemies.undead.spectral_hydra3'] = Display.image_load 'spr_enemies/undead/spectral_hydra3.png'
yield_point()
M['spr_enemies.undead.spectral_hydra4'] = Display.image_load 'spr_enemies/undead/spectral_hydra4.png'
yield_point()
M['spr_enemies.undead.spectral_hydra5'] = Display.image_load 'spr_enemies/undead/spectral_hydra5.png'
yield_point()
M['spr_enemies.undead.spectral_kraken'] = Display.image_load 'spr_enemies/undead/spectral_kraken.png'
yield_point()
M['spr_enemies.undead.spectral_large'] = Display.image_load 'spr_enemies/undead/spectral_large.png'
yield_point()
M['spr_enemies.undead.spectral_lizard'] = Display.image_load 'spr_enemies/undead/spectral_lizard.png'
yield_point()
M['spr_enemies.undead.spectral_naga'] = Display.image_load 'spr_enemies/undead/spectral_naga.png'
yield_point()
M['spr_enemies.undead.spectral_quadruped_large'] = Display.image_load 'spr_enemies/undead/spectral_quadruped_large.png'
yield_point()
M['spr_enemies.undead.spectral_quadruped_small'] = Display.image_load 'spr_enemies/undead/spectral_quadruped_small.png'
yield_point()
M['spr_enemies.undead.spectral_small'] = Display.image_load 'spr_enemies/undead/spectral_small.png'
yield_point()
M['spr_enemies.undead.spectral_snake'] = Display.image_load 'spr_enemies/undead/spectral_snake.png'
yield_point()
M['spr_enemies.undead.spectral_spider'] = Display.image_load 'spr_enemies/undead/spectral_spider.png'
yield_point()
M['spr_enemies.undead.vampire'] = Display.image_load 'spr_enemies/undead/vampire.png'
yield_point()
M['spr_enemies.undead.vampire_knight'] = Display.image_load 'spr_enemies/undead/vampire_knight.png'
yield_point()
M['spr_enemies.undead.vampire_mage'] = Display.image_load 'spr_enemies/undead/vampire_mage.png'
yield_point()
M['spr_enemies.undead.wight'] = Display.image_load 'spr_enemies/undead/wight.png'
yield_point()
M['spr_enemies.undead.wraith'] = Display.image_load 'spr_enemies/undead/wraith.png'
yield_point()
M['spr_enemies.undead.zombie_adder'] = Display.image_load 'spr_enemies/undead/zombie_adder.png'
yield_point()
M['spr_enemies.undead.zombie_bat'] = Display.image_load 'spr_enemies/undead/zombie_bat.png'
yield_point()
M['spr_enemies.undead.zombie_bee'] = Display.image_load 'spr_enemies/undead/zombie_bee.png'
yield_point()
M['spr_enemies.undead.zombie_beetle'] = Display.image_load 'spr_enemies/undead/zombie_beetle.png'
yield_point()
M['spr_enemies.undead.zombie_bird'] = Display.image_load 'spr_enemies/undead/zombie_bird.png'
yield_point()
M['spr_enemies.undead.zombie_bug'] = Display.image_load 'spr_enemies/undead/zombie_bug.png'
yield_point()
M['spr_enemies.undead.zombie_centaur'] = Display.image_load 'spr_enemies/undead/zombie_centaur.png'
yield_point()
M['spr_enemies.undead.zombie_crab'] = Display.image_load 'spr_enemies/undead/zombie_crab.png'
yield_point()
M['spr_enemies.undead.zombie_draconian'] = Display.image_load 'spr_enemies/undead/zombie_draconian.png'
yield_point()
M['spr_enemies.undead.zombie_dragon'] = Display.image_load 'spr_enemies/undead/zombie_dragon.png'
yield_point()
M['spr_enemies.undead.zombie_drake'] = Display.image_load 'spr_enemies/undead/zombie_drake.png'
yield_point()
M['spr_enemies.undead.zombie_elephant'] = Display.image_load 'spr_enemies/undead/zombie_elephant.png'
yield_point()
M['spr_enemies.undead.zombie_elf'] = Display.image_load 'spr_enemies/undead/zombie_elf.png'
yield_point()
M['spr_enemies.undead.zombie_fawn'] = Display.image_load 'spr_enemies/undead/zombie_fawn.png'
yield_point()
M['spr_enemies.undead.zombie_fish'] = Display.image_load 'spr_enemies/undead/zombie_fish.png'
yield_point()
M['spr_enemies.undead.zombie_frog'] = Display.image_load 'spr_enemies/undead/zombie_frog.png'
yield_point()
M['spr_enemies.undead.zombie_gnoll'] = Display.image_load 'spr_enemies/undead/zombie_gnoll.png'
yield_point()
M['spr_enemies.undead.zombie_goblin'] = Display.image_load 'spr_enemies/undead/zombie_goblin.png'
yield_point()
M['spr_enemies.undead.zombie_golden_dragon'] = Display.image_load 'spr_enemies/undead/zombie_golden_dragon.png'
yield_point()
M['spr_enemies.undead.zombie_guardian_serpent'] = Display.image_load 'spr_enemies/undead/zombie_guardian_serpent.png'
yield_point()
M['spr_enemies.undead.zombie_harpy'] = Display.image_load 'spr_enemies/undead/zombie_harpy.png'
yield_point()
M['spr_enemies.undead.zombie_hobgoblin'] = Display.image_load 'spr_enemies/undead/zombie_hobgoblin.png'
yield_point()
M['spr_enemies.undead.zombie_hound'] = Display.image_load 'spr_enemies/undead/zombie_hound.png'
yield_point()
M['spr_enemies.undead.zombie_human'] = Display.image_load 'spr_enemies/undead/zombie_human.png'
yield_point()
M['spr_enemies.undead.zombie_hydra1'] = Display.image_load 'spr_enemies/undead/zombie_hydra1.png'
yield_point()
M['spr_enemies.undead.zombie_hydra2'] = Display.image_load 'spr_enemies/undead/zombie_hydra2.png'
yield_point()
M['spr_enemies.undead.zombie_hydra3'] = Display.image_load 'spr_enemies/undead/zombie_hydra3.png'
yield_point()
M['spr_enemies.undead.zombie_hydra4'] = Display.image_load 'spr_enemies/undead/zombie_hydra4.png'
yield_point()
M['spr_enemies.undead.zombie_hydra5'] = Display.image_load 'spr_enemies/undead/zombie_hydra5.png'
yield_point()
M['spr_enemies.undead.zombie_iron_dragon'] = Display.image_load 'spr_enemies/undead/zombie_iron_dragon.png'
yield_point()
M['spr_enemies.undead.zombie_jackal'] = Display.image_load 'spr_enemies/undead/zombie_jackal.png'
yield_point()
M['spr_enemies.undead.zombie_juggernaut'] = Display.image_load 'spr_enemies/undead/zombie_juggernaut.png'
yield_point()
M['spr_enemies.undead.zombie_kobold'] = Display.image_load 'spr_enemies/undead/zombie_kobold.png'
yield_point()
M['spr_enemies.undead.zombie_kraken_head'] = Display.image_load 'spr_enemies/undead/zombie_kraken_head.png'
yield_point()
M['spr_enemies.undead.zombie_large'] = Display.image_load 'spr_enemies/undead/zombie_large.png'
yield_point()
M['spr_enemies.undead.zombie_lernaean_hydra01'] = Display.image_load 'spr_enemies/undead/zombie_lernaean_hydra01.png'
yield_point()
M['spr_enemies.undead.zombie_lernaean_hydra02'] = Display.image_load 'spr_enemies/undead/zombie_lernaean_hydra02.png'
yield_point()
M['spr_enemies.undead.zombie_lernaean_hydra03'] = Display.image_load 'spr_enemies/undead/zombie_lernaean_hydra03.png'
yield_point()
M['spr_enemies.undead.zombie_lernaean_hydra04'] = Display.image_load 'spr_enemies/undead/zombie_lernaean_hydra04.png'
yield_point()
M['spr_enemies.undead.zombie_lernaean_hydra05'] = Display.image_load 'spr_enemies/undead/zombie_lernaean_hydra05.png'
yield_point()
M['spr_enemies.undead.zombie_lernaean_hydra06'] = Display.image_load 'spr_enemies/undead/zombie_lernaean_hydra06.png'
yield_point()
M['spr_enemies.undead.zombie_lernaean_hydra07'] = Display.image_load 'spr_enemies/undead/zombie_lernaean_hydra07.png'
yield_point()
M['spr_enemies.undead.zombie_lernaean_hydra08'] = Display.image_load 'spr_enemies/undead/zombie_lernaean_hydra08.png'
yield_point()
M['spr_enemies.undead.zombie_lernaean_hydra09'] = Display.image_load 'spr_enemies/undead/zombie_lernaean_hydra09.png'
yield_point()
M['spr_enemies.undead.zombie_lernaean_hydra10'] = Display.image_load 'spr_enemies/undead/zombie_lernaean_hydra10.png'
yield_point()
M['spr_enemies.undead.zombie_lindwurm'] = Display.image_load 'spr_enemies/undead/zombie_lindwurm.png'
yield_point()
M['spr_enemies.undead.zombie_lizard'] = Display.image_load 'spr_enemies/undead/zombie_lizard.png'
yield_point()
M['spr_enemies.undead.zombie_merfolk'] = Display.image_load 'spr_enemies/undead/zombie_merfolk.png'
yield_point()
M['spr_enemies.undead.zombie_minotaur'] = Display.image_load 'spr_enemies/undead/zombie_minotaur.png'
yield_point()
M['spr_enemies.undead.zombie_monkey'] = Display.image_load 'spr_enemies/undead/zombie_monkey.png'
yield_point()
M['spr_enemies.undead.zombie_naga'] = Display.image_load 'spr_enemies/undead/zombie_naga.png'
yield_point()
M['spr_enemies.undead.zombie_octopode'] = Display.image_load 'spr_enemies/undead/zombie_octopode.png'
yield_point()
M['spr_enemies.undead.zombie_ogre'] = Display.image_load 'spr_enemies/undead/zombie_ogre.png'
yield_point()
M['spr_enemies.undead.zombie_orc'] = Display.image_load 'spr_enemies/undead/zombie_orc.png'
yield_point()
M['spr_enemies.undead.zombie_quadruped_large'] = Display.image_load 'spr_enemies/undead/zombie_quadruped_large.png'
yield_point()
M['spr_enemies.undead.zombie_quadruped_small'] = Display.image_load 'spr_enemies/undead/zombie_quadruped_small.png'
yield_point()
M['spr_enemies.undead.zombie_quadruped_winged'] = Display.image_load 'spr_enemies/undead/zombie_quadruped_winged.png'
yield_point()
M['spr_enemies.undead.zombie_quicksilver_dragon'] = Display.image_load 'spr_enemies/undead/zombie_quicksilver_dragon.png'
yield_point()
M['spr_enemies.undead.zombie_quokka'] = Display.image_load 'spr_enemies/undead/zombie_quokka.png'
yield_point()
M['spr_enemies.undead.zombie_rat'] = Display.image_load 'spr_enemies/undead/zombie_rat.png'
yield_point()
M['spr_enemies.undead.zombie_roach'] = Display.image_load 'spr_enemies/undead/zombie_roach.png'
yield_point()
M['spr_enemies.undead.zombie_salamander'] = Display.image_load 'spr_enemies/undead/zombie_salamander.png'
yield_point()
M['spr_enemies.undead.zombie_scorpion'] = Display.image_load 'spr_enemies/undead/zombie_scorpion.png'
yield_point()
M['spr_enemies.undead.zombie_small'] = Display.image_load 'spr_enemies/undead/zombie_small.png'
yield_point()
M['spr_enemies.undead.zombie_snake'] = Display.image_load 'spr_enemies/undead/zombie_snake.png'
yield_point()
M['spr_enemies.undead.zombie_spider_large'] = Display.image_load 'spr_enemies/undead/zombie_spider_large.png'
yield_point()
M['spr_enemies.undead.zombie_spider_small'] = Display.image_load 'spr_enemies/undead/zombie_spider_small.png'
yield_point()
M['spr_enemies.undead.zombie_spriggan'] = Display.image_load 'spr_enemies/undead/zombie_spriggan.png'
yield_point()
M['spr_enemies.undead.zombie_troll'] = Display.image_load 'spr_enemies/undead/zombie_troll.png'
yield_point()
M['spr_enemies.undead.zombie_turtle'] = Display.image_load 'spr_enemies/undead/zombie_turtle.png'
yield_point()
M['spr_enemies.undead.zombie_ugly_thing'] = Display.image_load 'spr_enemies/undead/zombie_ugly_thing.png'
yield_point()
M['spr_enemies.undead.zombie_worm'] = Display.image_load 'spr_enemies/undead/zombie_worm.png'
yield_point()
M['spr_enemies.undead.zombie_wyvern'] = Display.image_load 'spr_enemies/undead/zombie_wyvern.png'
yield_point()
M['spr_enemies.undead.zombie_yaktaur'] = Display.image_load 'spr_enemies/undead/zombie_yaktaur.png'
yield_point()

-- spr_enemies/animals resource loads:
M['spr_enemies.animals.adder'] = Display.image_load 'spr_enemies/animals/adder.png'
yield_point()
M['spr_enemies.animals.alligator'] = Display.image_load 'spr_enemies/animals/alligator.png'
yield_point()
M['spr_enemies.animals.alligator_snapping_turtle'] = Display.image_load 'spr_enemies/animals/alligator_snapping_turtle.png'
yield_point()
M['spr_enemies.animals.anaconda'] = Display.image_load 'spr_enemies/animals/anaconda.png'
yield_point()
M['spr_enemies.animals.ball_python'] = Display.image_load 'spr_enemies/animals/ball_python.png'
yield_point()
M['spr_enemies.animals.basilisk'] = Display.image_load 'spr_enemies/animals/basilisk.png'
yield_point()
M['spr_enemies.animals.bat'] = Display.image_load 'spr_enemies/animals/bat.png'
yield_point()
M['spr_enemies.animals.bennu'] = Display.image_load 'spr_enemies/animals/bennu.png'
yield_point()
M['spr_enemies.animals.black_bear'] = Display.image_load 'spr_enemies/animals/black_bear.png'
yield_point()
M['spr_enemies.animals.black_mamba'] = Display.image_load 'spr_enemies/animals/black_mamba.png'
yield_point()
M['spr_enemies.animals.blink_frog'] = Display.image_load 'spr_enemies/animals/blink_frog.png'
yield_point()
M['spr_enemies.animals.bullfrog'] = Display.image_load 'spr_enemies/animals/bullfrog.png'
yield_point()
M['spr_enemies.animals.butterfly'] = Display.image_load 'spr_enemies/animals/butterfly.png'
yield_point()
M['spr_enemies.animals.butterfly1'] = Display.image_load 'spr_enemies/animals/butterfly1.png'
yield_point()
M['spr_enemies.animals.butterfly10'] = Display.image_load 'spr_enemies/animals/butterfly10.png'
yield_point()
M['spr_enemies.animals.butterfly2'] = Display.image_load 'spr_enemies/animals/butterfly2.png'
yield_point()
M['spr_enemies.animals.butterfly3'] = Display.image_load 'spr_enemies/animals/butterfly3.png'
yield_point()
M['spr_enemies.animals.butterfly4'] = Display.image_load 'spr_enemies/animals/butterfly4.png'
yield_point()
M['spr_enemies.animals.butterfly5'] = Display.image_load 'spr_enemies/animals/butterfly5.png'
yield_point()
M['spr_enemies.animals.butterfly6'] = Display.image_load 'spr_enemies/animals/butterfly6.png'
yield_point()
M['spr_enemies.animals.butterfly7'] = Display.image_load 'spr_enemies/animals/butterfly7.png'
yield_point()
M['spr_enemies.animals.butterfly8'] = Display.image_load 'spr_enemies/animals/butterfly8.png'
yield_point()
M['spr_enemies.animals.butterfly9'] = Display.image_load 'spr_enemies/animals/butterfly9.png'
yield_point()
M['spr_enemies.animals.catoblepas'] = Display.image_load 'spr_enemies/animals/catoblepas.png'
yield_point()
M['spr_enemies.animals.caustic_shrike'] = Display.image_load 'spr_enemies/animals/caustic_shrike.png'
yield_point()
M['spr_enemies.animals.chicken'] = Display.image_load 'spr_enemies/animals/chicken.png'
yield_point()
M['spr_enemies.animals.chicken_boss1'] = Display.image_load 'spr_enemies/animals/chicken_boss1.png'
yield_point()
M['spr_enemies.animals.chicken_boss2'] = Display.image_load 'spr_enemies/animals/chicken_boss2.png'
yield_point()
M['spr_enemies.animals.chicken_boss3'] = Display.image_load 'spr_enemies/animals/chicken_boss3.png'
yield_point()
M['spr_enemies.animals.chicken_giant'] = Display.image_load 'spr_enemies/animals/chicken_giant.png'
yield_point()
M['spr_enemies.animals.crocodile'] = Display.image_load 'spr_enemies/animals/crocodile.png'
yield_point()
M['spr_enemies.animals.dart_slug'] = Display.image_load 'spr_enemies/animals/dart_slug.png'
yield_point()
M['spr_enemies.animals.deadhydra'] = Display.image_load 'spr_enemies/animals/deadhydra.png'
yield_point()
M['spr_enemies.animals.death_yak'] = Display.image_load 'spr_enemies/animals/death_yak.png'
yield_point()
M['spr_enemies.animals.doom_hound'] = Display.image_load 'spr_enemies/animals/doom_hound.png'
yield_point()
M['spr_enemies.animals.dream_sheep'] = Display.image_load 'spr_enemies/animals/dream_sheep.png'
yield_point()
M['spr_enemies.animals.elephant'] = Display.image_load 'spr_enemies/animals/elephant.png'
yield_point()
M['spr_enemies.animals.elephant_demonic'] = Display.image_load 'spr_enemies/animals/elephant_demonic.png'
yield_point()
M['spr_enemies.animals.elephant_dire'] = Display.image_load 'spr_enemies/animals/elephant_dire.png'
yield_point()
M['spr_enemies.animals.elephant_slug'] = Display.image_load 'spr_enemies/animals/elephant_slug.png'
yield_point()
M['spr_enemies.animals.emperor_scorpion'] = Display.image_load 'spr_enemies/animals/emperor_scorpion.png'
yield_point()
M['spr_enemies.animals.fire_bat'] = Display.image_load 'spr_enemies/animals/fire_bat.png'
yield_point()
M['spr_enemies.animals.fire_crab'] = Display.image_load 'spr_enemies/animals/fire_crab.png'
yield_point()
M['spr_enemies.animals.frilled_lizard'] = Display.image_load 'spr_enemies/animals/frilled_lizard.png'
yield_point()
M['spr_enemies.animals.ghost_crab'] = Display.image_load 'spr_enemies/animals/ghost_crab.png'
yield_point()
M['spr_enemies.animals.ghost_moth'] = Display.image_load 'spr_enemies/animals/ghost_moth.png'
yield_point()
M['spr_enemies.animals.giant_cockroach'] = Display.image_load 'spr_enemies/animals/giant_cockroach.png'
yield_point()
M['spr_enemies.animals.giant_frog'] = Display.image_load 'spr_enemies/animals/giant_frog.png'
yield_point()
M['spr_enemies.animals.giant_rat'] = Display.image_load 'spr_enemies/animals/giant_rat.png'
yield_point()
M['spr_enemies.animals.goliath_beetle'] = Display.image_load 'spr_enemies/animals/goliath_beetle.png'
yield_point()
M['spr_enemies.animals.green_rat'] = Display.image_load 'spr_enemies/animals/green_rat.png'
yield_point()
M['spr_enemies.animals.hell_hog'] = Display.image_load 'spr_enemies/animals/hell_hog.png'
yield_point()
M['spr_enemies.animals.hell_hound'] = Display.image_load 'spr_enemies/animals/hell_hound.png'
yield_point()
M['spr_enemies.animals.hog'] = Display.image_load 'spr_enemies/animals/hog.png'
yield_point()
M['spr_enemies.animals.holy_swine'] = Display.image_load 'spr_enemies/animals/holy_swine.png'
yield_point()
M['spr_enemies.animals.hornet'] = Display.image_load 'spr_enemies/animals/hornet.png'
yield_point()
M['spr_enemies.animals.horse'] = Display.image_load 'spr_enemies/animals/horse.png'
yield_point()
M['spr_enemies.animals.hound'] = Display.image_load 'spr_enemies/animals/hound.png'
yield_point()
M['spr_enemies.animals.howler'] = Display.image_load 'spr_enemies/animals/howler.png'
yield_point()
M['spr_enemies.animals.hydra'] = Display.image_load 'spr_enemies/animals/hydra.png'
yield_point()
M['spr_enemies.animals.ice_beast'] = Display.image_load 'spr_enemies/animals/ice_beast.png'
yield_point()
M['spr_enemies.animals.iguana'] = Display.image_load 'spr_enemies/animals/iguana.png'
yield_point()
M['spr_enemies.animals.jackal'] = Display.image_load 'spr_enemies/animals/jackal.png'
yield_point()
M['spr_enemies.animals.jumping_spider'] = Display.image_load 'spr_enemies/animals/jumping_spider.png'
yield_point()
M['spr_enemies.animals.killer_bee'] = Display.image_load 'spr_enemies/animals/killer_bee.png'
yield_point()
M['spr_enemies.animals.komodo_dragon'] = Display.image_load 'spr_enemies/animals/komodo_dragon.png'
yield_point()
M['spr_enemies.animals.lava_fish'] = Display.image_load 'spr_enemies/animals/lava_fish.png'
yield_point()
M['spr_enemies.animals.leopard_gecko'] = Display.image_load 'spr_enemies/animals/leopard_gecko.png'
yield_point()
M['spr_enemies.animals.mana_viper'] = Display.image_load 'spr_enemies/animals/mana_viper.png'
yield_point()
M['spr_enemies.animals.moth_of_wrath'] = Display.image_load 'spr_enemies/animals/moth_of_wrath.png'
yield_point()
M['spr_enemies.animals.orange_rat'] = Display.image_load 'spr_enemies/animals/orange_rat.png'
yield_point()
M['spr_enemies.animals.orb_spider'] = Display.image_load 'spr_enemies/animals/orb_spider.png'
yield_point()
M['spr_enemies.animals.polar_bear'] = Display.image_load 'spr_enemies/animals/polar_bear.png'
yield_point()
M['spr_enemies.animals.porcupine'] = Display.image_load 'spr_enemies/animals/porcupine.png'
yield_point()
M['spr_enemies.animals.poulter'] = Display.image_load 'spr_enemies/animals/poulter.png'
yield_point()
M['spr_enemies.animals.queen_ant'] = Display.image_load 'spr_enemies/animals/queen_ant.png'
yield_point()
M['spr_enemies.animals.queen_bee'] = Display.image_load 'spr_enemies/animals/queen_bee.png'
yield_point()
M['spr_enemies.animals.quokka'] = Display.image_load 'spr_enemies/animals/quokka.png'
yield_point()
M['spr_enemies.animals.raiju'] = Display.image_load 'spr_enemies/animals/raiju.png'
yield_point()
M['spr_enemies.animals.rat'] = Display.image_load 'spr_enemies/animals/rat.png'
yield_point()
M['spr_enemies.animals.redback'] = Display.image_load 'spr_enemies/animals/redback.png'
yield_point()
M['spr_enemies.animals.scorpion'] = Display.image_load 'spr_enemies/animals/scorpion.png'
yield_point()
M['spr_enemies.animals.sea_snake'] = Display.image_load 'spr_enemies/animals/sea_snake.png'
yield_point()
M['spr_enemies.animals.shard_shrike'] = Display.image_load 'spr_enemies/animals/shard_shrike.png'
yield_point()
M['spr_enemies.animals.sheep'] = Display.image_load 'spr_enemies/animals/sheep.png'
yield_point()
M['spr_enemies.animals.shock_serpent'] = Display.image_load 'spr_enemies/animals/shock_serpent.png'
yield_point()
M['spr_enemies.animals.sky_beast'] = Display.image_load 'spr_enemies/animals/sky_beast.png'
yield_point()
M['spr_enemies.animals.snapping_turtle'] = Display.image_load 'spr_enemies/animals/snapping_turtle.png'
yield_point()
M['spr_enemies.animals.soldier_ant'] = Display.image_load 'spr_enemies/animals/soldier_ant.png'
yield_point()
M['spr_enemies.animals.spark_wasp'] = Display.image_load 'spr_enemies/animals/spark_wasp.png'
yield_point()
M['spr_enemies.animals.spider'] = Display.image_load 'spr_enemies/animals/spider.png'
yield_point()
M['spr_enemies.animals.spiny_frog'] = Display.image_load 'spr_enemies/animals/spiny_frog.png'
yield_point()
M['spr_enemies.animals.superchicken'] = Display.image_load 'spr_enemies/animals/superchicken.png'
yield_point()
M['spr_enemies.animals.tarantella'] = Display.image_load 'spr_enemies/animals/tarantella.png'
yield_point()
M['spr_enemies.animals.torpor_snail'] = Display.image_load 'spr_enemies/animals/torpor_snail.png'
yield_point()
M['spr_enemies.animals.tyrant_leech'] = Display.image_load 'spr_enemies/animals/tyrant_leech.png'
yield_point()
M['spr_enemies.animals.vampire_bat'] = Display.image_load 'spr_enemies/animals/vampire_bat.png'
yield_point()
M['spr_enemies.animals.vampire_mosquito'] = Display.image_load 'spr_enemies/animals/vampire_mosquito.png'
yield_point()
M['spr_enemies.animals.warg'] = Display.image_load 'spr_enemies/animals/warg.png'
yield_point()
M['spr_enemies.animals.water_moccasin'] = Display.image_load 'spr_enemies/animals/water_moccasin.png'
yield_point()
M['spr_enemies.animals.wolf'] = Display.image_load 'spr_enemies/animals/wolf.png'
yield_point()
M['spr_enemies.animals.wolf_spider'] = Display.image_load 'spr_enemies/animals/wolf_spider.png'
yield_point()
M['spr_enemies.animals.worker_ant'] = Display.image_load 'spr_enemies/animals/worker_ant.png'
yield_point()
M['spr_enemies.animals.worm'] = Display.image_load 'spr_enemies/animals/worm.png'
yield_point()
M['spr_enemies.animals.yak'] = Display.image_load 'spr_enemies/animals/yak.png'
yield_point()

-- spr_enemies/demons resource loads:
M['spr_enemies.demons.balrug'] = Display.image_load 'spr_enemies/demons/balrug.png'
yield_point()
M['spr_enemies.demons.blizzard_demon'] = Display.image_load 'spr_enemies/demons/blizzard_demon.png'
yield_point()
M['spr_enemies.demons.brimstone_fiend'] = Display.image_load 'spr_enemies/demons/brimstone_fiend.png'
yield_point()
M['spr_enemies.demons.cacodemon'] = Display.image_load 'spr_enemies/demons/cacodemon.png'
yield_point()
M['spr_enemies.demons.chaos_spawn1'] = Display.image_load 'spr_enemies/demons/chaos_spawn1.png'
yield_point()
M['spr_enemies.demons.chaos_spawn2'] = Display.image_load 'spr_enemies/demons/chaos_spawn2.png'
yield_point()
M['spr_enemies.demons.chaos_spawn3'] = Display.image_load 'spr_enemies/demons/chaos_spawn3.png'
yield_point()
M['spr_enemies.demons.chaos_spawn4'] = Display.image_load 'spr_enemies/demons/chaos_spawn4.png'
yield_point()
M['spr_enemies.demons.chaos_spawn5'] = Display.image_load 'spr_enemies/demons/chaos_spawn5.png'
yield_point()
M['spr_enemies.demons.crimson_imp'] = Display.image_load 'spr_enemies/demons/crimson_imp.png'
yield_point()
M['spr_enemies.demons.demonic_crawler'] = Display.image_load 'spr_enemies/demons/demonic_crawler.png'
yield_point()
M['spr_enemies.demons.efreet'] = Display.image_load 'spr_enemies/demons/efreet.png'
yield_point()
M['spr_enemies.demons.executioner'] = Display.image_load 'spr_enemies/demons/executioner.png'
yield_point()
M['spr_enemies.demons.green_death'] = Display.image_load 'spr_enemies/demons/green_death.png'
yield_point()
M['spr_enemies.demons.hell_beast'] = Display.image_load 'spr_enemies/demons/hell_beast.png'
yield_point()
M['spr_enemies.demons.hell_sentinel'] = Display.image_load 'spr_enemies/demons/hell_sentinel.png'
yield_point()
M['spr_enemies.demons.hellion'] = Display.image_load 'spr_enemies/demons/hellion.png'
yield_point()
M['spr_enemies.demons.hellwing'] = Display.image_load 'spr_enemies/demons/hellwing.png'
yield_point()
M['spr_enemies.demons.ice_devil'] = Display.image_load 'spr_enemies/demons/ice_devil.png'
yield_point()
M['spr_enemies.demons.ice_fiend'] = Display.image_load 'spr_enemies/demons/ice_fiend.png'
yield_point()
M['spr_enemies.demons.iron_imp'] = Display.image_load 'spr_enemies/demons/iron_imp.png'
yield_point()
M['spr_enemies.demons.lorocyproca'] = Display.image_load 'spr_enemies/demons/lorocyproca.png'
yield_point()
M['spr_enemies.demons.manasapper'] = Display.image_load 'spr_enemies/demons/manasapper.png'
yield_point()
M['spr_enemies.demons.neqoxec'] = Display.image_load 'spr_enemies/demons/neqoxec.png'
yield_point()
M['spr_enemies.demons.orange_demon'] = Display.image_load 'spr_enemies/demons/orange_demon.png'
yield_point()
M['spr_enemies.demons.quasit'] = Display.image_load 'spr_enemies/demons/quasit.png'
yield_point()
M['spr_enemies.demons.rakshasa'] = Display.image_load 'spr_enemies/demons/rakshasa.png'
yield_point()
M['spr_enemies.demons.reaper'] = Display.image_load 'spr_enemies/demons/reaper.png'
yield_point()
M['spr_enemies.demons.red_devil'] = Display.image_load 'spr_enemies/demons/red_devil.png'
yield_point()
M['spr_enemies.demons.rust_devil'] = Display.image_load 'spr_enemies/demons/rust_devil.png'
yield_point()
M['spr_enemies.demons.shadow_demon'] = Display.image_load 'spr_enemies/demons/shadow_demon.png'
yield_point()
M['spr_enemies.demons.shadow_imp'] = Display.image_load 'spr_enemies/demons/shadow_imp.png'
yield_point()
M['spr_enemies.demons.sixfirhy'] = Display.image_load 'spr_enemies/demons/sixfirhy.png'
yield_point()
M['spr_enemies.demons.smoke_demon'] = Display.image_load 'spr_enemies/demons/smoke_demon.png'
yield_point()
M['spr_enemies.demons.soul_eater'] = Display.image_load 'spr_enemies/demons/soul_eater.png'
yield_point()
M['spr_enemies.demons.sun_demon'] = Display.image_load 'spr_enemies/demons/sun_demon.png'
yield_point()
M['spr_enemies.demons.tormentor'] = Display.image_load 'spr_enemies/demons/tormentor.png'
yield_point()
M['spr_enemies.demons.tzitzimitl'] = Display.image_load 'spr_enemies/demons/tzitzimitl.png'
yield_point()
M['spr_enemies.demons.ufetubus'] = Display.image_load 'spr_enemies/demons/ufetubus.png'
yield_point()
M['spr_enemies.demons.white_imp'] = Display.image_load 'spr_enemies/demons/white_imp.png'
yield_point()
M['spr_enemies.demons.ynoxinul'] = Display.image_load 'spr_enemies/demons/ynoxinul.png'
yield_point()

-- spr_enemies/humanoid resource loads:
M['spr_enemies.humanoid.big_kobold'] = Display.image_load 'spr_enemies/humanoid/big_kobold.png'
yield_point()
M['spr_enemies.humanoid.boggart'] = Display.image_load 'spr_enemies/humanoid/boggart.png'
yield_point()
M['spr_enemies.humanoid.centaur-melee'] = Display.image_load 'spr_enemies/humanoid/centaur-melee.png'
yield_point()
M['spr_enemies.humanoid.centaur'] = Display.image_load 'spr_enemies/humanoid/centaur.png'
yield_point()
M['spr_enemies.humanoid.centaur_warrior-melee'] = Display.image_load 'spr_enemies/humanoid/centaur_warrior-melee.png'
yield_point()
M['spr_enemies.humanoid.centaur_warrior'] = Display.image_load 'spr_enemies/humanoid/centaur_warrior.png'
yield_point()
M['spr_enemies.humanoid.cyclops'] = Display.image_load 'spr_enemies/humanoid/cyclops.png'
yield_point()
M['spr_enemies.humanoid.death_knight'] = Display.image_load 'spr_enemies/humanoid/death_knight.png'
yield_point()
M['spr_enemies.humanoid.deep_dwarf'] = Display.image_load 'spr_enemies/humanoid/deep_dwarf.png'
yield_point()
M['spr_enemies.humanoid.deep_elf_annihilator'] = Display.image_load 'spr_enemies/humanoid/deep_elf_annihilator.png'
yield_point()
M['spr_enemies.humanoid.deep_elf_archer'] = Display.image_load 'spr_enemies/humanoid/deep_elf_archer.png'
yield_point()
M['spr_enemies.humanoid.deep_elf_blademaster'] = Display.image_load 'spr_enemies/humanoid/deep_elf_blademaster.png'
yield_point()
M['spr_enemies.humanoid.deep_elf_death_mage'] = Display.image_load 'spr_enemies/humanoid/deep_elf_death_mage.png'
yield_point()
M['spr_enemies.humanoid.deep_elf_demonologist'] = Display.image_load 'spr_enemies/humanoid/deep_elf_demonologist.png'
yield_point()
M['spr_enemies.humanoid.deep_elf_elementalist'] = Display.image_load 'spr_enemies/humanoid/deep_elf_elementalist.png'
yield_point()
M['spr_enemies.humanoid.deep_elf_high_priest'] = Display.image_load 'spr_enemies/humanoid/deep_elf_high_priest.png'
yield_point()
M['spr_enemies.humanoid.deep_elf_knight'] = Display.image_load 'spr_enemies/humanoid/deep_elf_knight.png'
yield_point()
M['spr_enemies.humanoid.deep_elf_mage'] = Display.image_load 'spr_enemies/humanoid/deep_elf_mage.png'
yield_point()
M['spr_enemies.humanoid.deep_elf_master_archer'] = Display.image_load 'spr_enemies/humanoid/deep_elf_master_archer.png'
yield_point()
M['spr_enemies.humanoid.deep_elf_sorcerer'] = Display.image_load 'spr_enemies/humanoid/deep_elf_sorcerer.png'
yield_point()
M['spr_enemies.humanoid.deep_troll'] = Display.image_load 'spr_enemies/humanoid/deep_troll.png'
yield_point()
M['spr_enemies.humanoid.deep_troll_earth_mage'] = Display.image_load 'spr_enemies/humanoid/deep_troll_earth_mage.png'
yield_point()
M['spr_enemies.humanoid.deep_troll_shaman'] = Display.image_load 'spr_enemies/humanoid/deep_troll_shaman.png'
yield_point()
M['spr_enemies.humanoid.demigod'] = Display.image_load 'spr_enemies/humanoid/demigod.png'
yield_point()
M['spr_enemies.humanoid.dryad'] = Display.image_load 'spr_enemies/humanoid/dryad.png'
yield_point()
M['spr_enemies.humanoid.dwarf'] = Display.image_load 'spr_enemies/humanoid/dwarf.png'
yield_point()
M['spr_enemies.humanoid.elf'] = Display.image_load 'spr_enemies/humanoid/elf.png'
yield_point()
M['spr_enemies.humanoid.entropy_weaver'] = Display.image_load 'spr_enemies/humanoid/entropy_weaver.png'
yield_point()
M['spr_enemies.humanoid.ettin'] = Display.image_load 'spr_enemies/humanoid/ettin.png'
yield_point()
M['spr_enemies.humanoid.faun'] = Display.image_load 'spr_enemies/humanoid/faun.png'
yield_point()
M['spr_enemies.humanoid.fire_giant'] = Display.image_load 'spr_enemies/humanoid/fire_giant.png'
yield_point()
M['spr_enemies.humanoid.formicid'] = Display.image_load 'spr_enemies/humanoid/formicid.png'
yield_point()
M['spr_enemies.humanoid.frost_giant'] = Display.image_load 'spr_enemies/humanoid/frost_giant.png'
yield_point()
M['spr_enemies.humanoid.glowing_orange_brain'] = Display.image_load 'spr_enemies/humanoid/glowing_orange_brain.png'
yield_point()
M['spr_enemies.humanoid.glowing_shapeshifter'] = Display.image_load 'spr_enemies/humanoid/glowing_shapeshifter.png'
yield_point()
M['spr_enemies.humanoid.gnoll'] = Display.image_load 'spr_enemies/humanoid/gnoll.png'
yield_point()
M['spr_enemies.humanoid.gnoll_sergeant'] = Display.image_load 'spr_enemies/humanoid/gnoll_sergeant.png'
yield_point()
M['spr_enemies.humanoid.gnoll_shaman'] = Display.image_load 'spr_enemies/humanoid/gnoll_shaman.png'
yield_point()
M['spr_enemies.humanoid.goblin'] = Display.image_load 'spr_enemies/humanoid/goblin.png'
yield_point()
M['spr_enemies.humanoid.guardian_serpent'] = Display.image_load 'spr_enemies/humanoid/guardian_serpent.png'
yield_point()
M['spr_enemies.humanoid.halfling'] = Display.image_load 'spr_enemies/humanoid/halfling.png'
yield_point()
M['spr_enemies.humanoid.harpy'] = Display.image_load 'spr_enemies/humanoid/harpy.png'
yield_point()
M['spr_enemies.humanoid.hell_knight'] = Display.image_load 'spr_enemies/humanoid/hell_knight.png'
yield_point()
M['spr_enemies.humanoid.hill_giant'] = Display.image_load 'spr_enemies/humanoid/hill_giant.png'
yield_point()
M['spr_enemies.humanoid.hippogriff'] = Display.image_load 'spr_enemies/humanoid/hippogriff.png'
yield_point()
M['spr_enemies.humanoid.hobgoblin'] = Display.image_load 'spr_enemies/humanoid/hobgoblin.png'
yield_point()
M['spr_enemies.humanoid.human'] = Display.image_load 'spr_enemies/humanoid/human.png'
yield_point()
M['spr_enemies.humanoid.human2'] = Display.image_load 'spr_enemies/humanoid/human2.png'
yield_point()
M['spr_enemies.humanoid.human3'] = Display.image_load 'spr_enemies/humanoid/human3.png'
yield_point()
M['spr_enemies.humanoid.imperial_myrmidon'] = Display.image_load 'spr_enemies/humanoid/imperial_myrmidon.png'
yield_point()
M['spr_enemies.humanoid.iron_giant'] = Display.image_load 'spr_enemies/humanoid/iron_giant.png'
yield_point()
M['spr_enemies.humanoid.iron_troll'] = Display.image_load 'spr_enemies/humanoid/iron_troll.png'
yield_point()
M['spr_enemies.humanoid.ironbrand_convoker'] = Display.image_load 'spr_enemies/humanoid/ironbrand_convoker.png'
yield_point()
M['spr_enemies.humanoid.ironheart_preserver'] = Display.image_load 'spr_enemies/humanoid/ironheart_preserver.png'
yield_point()
M['spr_enemies.humanoid.juggernaut'] = Display.image_load 'spr_enemies/humanoid/juggernaut.png'
yield_point()
M['spr_enemies.humanoid.killer_klown_blue'] = Display.image_load 'spr_enemies/humanoid/killer_klown_blue.png'
yield_point()
M['spr_enemies.humanoid.killer_klown_green'] = Display.image_load 'spr_enemies/humanoid/killer_klown_green.png'
yield_point()
M['spr_enemies.humanoid.killer_klown_purple'] = Display.image_load 'spr_enemies/humanoid/killer_klown_purple.png'
yield_point()
M['spr_enemies.humanoid.killer_klown_red'] = Display.image_load 'spr_enemies/humanoid/killer_klown_red.png'
yield_point()
M['spr_enemies.humanoid.killer_klown_yellow'] = Display.image_load 'spr_enemies/humanoid/killer_klown_yellow.png'
yield_point()
M['spr_enemies.humanoid.kobold'] = Display.image_load 'spr_enemies/humanoid/kobold.png'
yield_point()
M['spr_enemies.humanoid.kobold_demonologist'] = Display.image_load 'spr_enemies/humanoid/kobold_demonologist.png'
yield_point()
M['spr_enemies.humanoid.manticore'] = Display.image_load 'spr_enemies/humanoid/manticore.png'
yield_point()
M['spr_enemies.humanoid.meliai'] = Display.image_load 'spr_enemies/humanoid/meliai.png'
yield_point()
M['spr_enemies.humanoid.merfolk'] = Display.image_load 'spr_enemies/humanoid/merfolk.png'
yield_point()
M['spr_enemies.humanoid.merfolk_aquamancer'] = Display.image_load 'spr_enemies/humanoid/merfolk_aquamancer.png'
yield_point()
M['spr_enemies.humanoid.merfolk_aquamancer_water'] = Display.image_load 'spr_enemies/humanoid/merfolk_aquamancer_water.png'
yield_point()
M['spr_enemies.humanoid.merfolk_avatar'] = Display.image_load 'spr_enemies/humanoid/merfolk_avatar.png'
yield_point()
M['spr_enemies.humanoid.merfolk_avatar_water'] = Display.image_load 'spr_enemies/humanoid/merfolk_avatar_water.png'
yield_point()
M['spr_enemies.humanoid.merfolk_impaler'] = Display.image_load 'spr_enemies/humanoid/merfolk_impaler.png'
yield_point()
M['spr_enemies.humanoid.merfolk_impaler_water'] = Display.image_load 'spr_enemies/humanoid/merfolk_impaler_water.png'
yield_point()
M['spr_enemies.humanoid.merfolk_javelineer'] = Display.image_load 'spr_enemies/humanoid/merfolk_javelineer.png'
yield_point()
M['spr_enemies.humanoid.merfolk_javelineer_water'] = Display.image_load 'spr_enemies/humanoid/merfolk_javelineer_water.png'
yield_point()
M['spr_enemies.humanoid.merfolk_siren'] = Display.image_load 'spr_enemies/humanoid/merfolk_siren.png'
yield_point()
M['spr_enemies.humanoid.merfolk_siren_water'] = Display.image_load 'spr_enemies/humanoid/merfolk_siren_water.png'
yield_point()
M['spr_enemies.humanoid.merfolk_water'] = Display.image_load 'spr_enemies/humanoid/merfolk_water.png'
yield_point()
M['spr_enemies.humanoid.minotaur'] = Display.image_load 'spr_enemies/humanoid/minotaur.png'
yield_point()
M['spr_enemies.humanoid.naga'] = Display.image_load 'spr_enemies/humanoid/naga.png'
yield_point()
M['spr_enemies.humanoid.naga_mage'] = Display.image_load 'spr_enemies/humanoid/naga_mage.png'
yield_point()
M['spr_enemies.humanoid.naga_ritualist'] = Display.image_load 'spr_enemies/humanoid/naga_ritualist.png'
yield_point()
M['spr_enemies.humanoid.naga_sharpshooter'] = Display.image_load 'spr_enemies/humanoid/naga_sharpshooter.png'
yield_point()
M['spr_enemies.humanoid.naga_warrior'] = Display.image_load 'spr_enemies/humanoid/naga_warrior.png'
yield_point()
M['spr_enemies.humanoid.nagaraja'] = Display.image_load 'spr_enemies/humanoid/nagaraja.png'
yield_point()
M['spr_enemies.humanoid.necromancer'] = Display.image_load 'spr_enemies/humanoid/necromancer.png'
yield_point()
M['spr_enemies.humanoid.ogre'] = Display.image_load 'spr_enemies/humanoid/ogre.png'
yield_point()
M['spr_enemies.humanoid.ogre_mage'] = Display.image_load 'spr_enemies/humanoid/ogre_mage.png'
yield_point()
M['spr_enemies.humanoid.orb_guardian'] = Display.image_load 'spr_enemies/humanoid/orb_guardian.png'
yield_point()
M['spr_enemies.humanoid.orc'] = Display.image_load 'spr_enemies/humanoid/orc.png'
yield_point()
M['spr_enemies.humanoid.orc_high_priest'] = Display.image_load 'spr_enemies/humanoid/orc_high_priest.png'
yield_point()
M['spr_enemies.humanoid.orc_knight'] = Display.image_load 'spr_enemies/humanoid/orc_knight.png'
yield_point()
M['spr_enemies.humanoid.orc_priest'] = Display.image_load 'spr_enemies/humanoid/orc_priest.png'
yield_point()
M['spr_enemies.humanoid.orc_sorcerer'] = Display.image_load 'spr_enemies/humanoid/orc_sorcerer.png'
yield_point()
M['spr_enemies.humanoid.orc_warlord'] = Display.image_load 'spr_enemies/humanoid/orc_warlord.png'
yield_point()
M['spr_enemies.humanoid.orc_warrior'] = Display.image_load 'spr_enemies/humanoid/orc_warrior.png'
yield_point()
M['spr_enemies.humanoid.orc_wizard'] = Display.image_load 'spr_enemies/humanoid/orc_wizard.png'
yield_point()
M['spr_enemies.humanoid.ragged_hierophant'] = Display.image_load 'spr_enemies/humanoid/ragged_hierophant.png'
yield_point()
M['spr_enemies.humanoid.salamander'] = Display.image_load 'spr_enemies/humanoid/salamander.png'
yield_point()
M['spr_enemies.humanoid.salamander_mystic'] = Display.image_load 'spr_enemies/humanoid/salamander_mystic.png'
yield_point()
M['spr_enemies.humanoid.satyr'] = Display.image_load 'spr_enemies/humanoid/satyr.png'
yield_point()
M['spr_enemies.humanoid.servant_of_whispers'] = Display.image_load 'spr_enemies/humanoid/servant_of_whispers.png'
yield_point()
M['spr_enemies.humanoid.shapeshifter'] = Display.image_load 'spr_enemies/humanoid/shapeshifter.png'
yield_point()
M['spr_enemies.humanoid.slave'] = Display.image_load 'spr_enemies/humanoid/slave.png'
yield_point()
M['spr_enemies.humanoid.slave_freed'] = Display.image_load 'spr_enemies/humanoid/slave_freed.png'
yield_point()
M['spr_enemies.humanoid.sphinx'] = Display.image_load 'spr_enemies/humanoid/sphinx.png'
yield_point()
M['spr_enemies.humanoid.stone_giant'] = Display.image_load 'spr_enemies/humanoid/stone_giant.png'
yield_point()
M['spr_enemies.humanoid.tengu'] = Display.image_load 'spr_enemies/humanoid/tengu.png'
yield_point()
M['spr_enemies.humanoid.tengu_conjurer'] = Display.image_load 'spr_enemies/humanoid/tengu_conjurer.png'
yield_point()
M['spr_enemies.humanoid.tengu_reaver'] = Display.image_load 'spr_enemies/humanoid/tengu_reaver.png'
yield_point()
M['spr_enemies.humanoid.tengu_warrior'] = Display.image_load 'spr_enemies/humanoid/tengu_warrior.png'
yield_point()
M['spr_enemies.humanoid.titan'] = Display.image_load 'spr_enemies/humanoid/titan.png'
yield_point()
M['spr_enemies.humanoid.troll'] = Display.image_load 'spr_enemies/humanoid/troll.png'
yield_point()
M['spr_enemies.humanoid.two_headed_ogre'] = Display.image_load 'spr_enemies/humanoid/two_headed_ogre.png'
yield_point()
M['spr_enemies.humanoid.vault_guard'] = Display.image_load 'spr_enemies/humanoid/vault_guard.png'
yield_point()
M['spr_enemies.humanoid.vault_sentinel'] = Display.image_load 'spr_enemies/humanoid/vault_sentinel.png'
yield_point()
M['spr_enemies.humanoid.vault_warden'] = Display.image_load 'spr_enemies/humanoid/vault_warden.png'
yield_point()
M['spr_enemies.humanoid.water_nymph'] = Display.image_load 'spr_enemies/humanoid/water_nymph.png'
yield_point()
M['spr_enemies.humanoid.wizard'] = Display.image_load 'spr_enemies/humanoid/wizard.png'
yield_point()
M['spr_enemies.humanoid.yaktaur-melee'] = Display.image_load 'spr_enemies/humanoid/yaktaur-melee.png'
yield_point()
M['spr_enemies.humanoid.yaktaur'] = Display.image_load 'spr_enemies/humanoid/yaktaur.png'
yield_point()
M['spr_enemies.humanoid.yaktaur_captain-melee'] = Display.image_load 'spr_enemies/humanoid/yaktaur_captain-melee.png'
yield_point()
M['spr_enemies.humanoid.yaktaur_captain'] = Display.image_load 'spr_enemies/humanoid/yaktaur_captain.png'
yield_point()

-- spr_enemies/demonspawn resource loads:
M['spr_enemies.demonspawn.black_sun'] = Display.image_load 'spr_enemies/demonspawn/black_sun.png'
yield_point()
M['spr_enemies.demonspawn.blood_saint'] = Display.image_load 'spr_enemies/demonspawn/blood_saint.png'
yield_point()
M['spr_enemies.demonspawn.corrupter'] = Display.image_load 'spr_enemies/demonspawn/corrupter.png'
yield_point()
M['spr_enemies.demonspawn.demonspawn'] = Display.image_load 'spr_enemies/demonspawn/demonspawn.png'
yield_point()
M['spr_enemies.demonspawn.gelid'] = Display.image_load 'spr_enemies/demonspawn/gelid.png'
yield_point()
M['spr_enemies.demonspawn.infernal'] = Display.image_load 'spr_enemies/demonspawn/infernal.png'
yield_point()
M['spr_enemies.demonspawn.monstrous'] = Display.image_load 'spr_enemies/demonspawn/monstrous.png'
yield_point()
M['spr_enemies.demonspawn.torturous'] = Display.image_load 'spr_enemies/demonspawn/torturous.png'
yield_point()
M['spr_enemies.demonspawn.warmonger'] = Display.image_load 'spr_enemies/demonspawn/warmonger.png'
yield_point()

-- spr_enemies/draco resource loads:
M['spr_enemies.draco.draco-base-black'] = Display.image_load 'spr_enemies/draco/draco-base-black.png'
yield_point()
M['spr_enemies.draco.draco-base-brown'] = Display.image_load 'spr_enemies/draco/draco-base-brown.png'
yield_point()
M['spr_enemies.draco.draco-base-green'] = Display.image_load 'spr_enemies/draco/draco-base-green.png'
yield_point()
M['spr_enemies.draco.draco-base-grey'] = Display.image_load 'spr_enemies/draco/draco-base-grey.png'
yield_point()
M['spr_enemies.draco.draco-base-mottle'] = Display.image_load 'spr_enemies/draco/draco-base-mottle.png'
yield_point()
M['spr_enemies.draco.draco-base-pale'] = Display.image_load 'spr_enemies/draco/draco-base-pale.png'
yield_point()
M['spr_enemies.draco.draco-base-purple'] = Display.image_load 'spr_enemies/draco/draco-base-purple.png'
yield_point()
M['spr_enemies.draco.draco-base-red'] = Display.image_load 'spr_enemies/draco/draco-base-red.png'
yield_point()
M['spr_enemies.draco.draco-base-white'] = Display.image_load 'spr_enemies/draco/draco-base-white.png'
yield_point()
M['spr_enemies.draco.draco-base-yellow'] = Display.image_load 'spr_enemies/draco/draco-base-yellow.png'
yield_point()
M['spr_enemies.draco.draco-job-annihilator'] = Display.image_load 'spr_enemies/draco/draco-job-annihilator.png'
yield_point()
M['spr_enemies.draco.draco-job-knight'] = Display.image_load 'spr_enemies/draco/draco-job-knight.png'
yield_point()
M['spr_enemies.draco.draco-job-monk'] = Display.image_load 'spr_enemies/draco/draco-job-monk.png'
yield_point()
M['spr_enemies.draco.draco-job-scorcher'] = Display.image_load 'spr_enemies/draco/draco-job-scorcher.png'
yield_point()
M['spr_enemies.draco.draco-job-shifter'] = Display.image_load 'spr_enemies/draco/draco-job-shifter.png'
yield_point()
M['spr_enemies.draco.draco-job-stormcaller'] = Display.image_load 'spr_enemies/draco/draco-job-stormcaller.png'
yield_point()

-- spr_enemies/dragons resource loads:
M['spr_enemies.dragons.acid_dragon'] = Display.image_load 'spr_enemies/dragons/acid_dragon.png'
yield_point()
M['spr_enemies.dragons.death_drake'] = Display.image_load 'spr_enemies/dragons/death_drake.png'
yield_point()
M['spr_enemies.dragons.fire_dragon'] = Display.image_load 'spr_enemies/dragons/fire_dragon.png'
yield_point()
M['spr_enemies.dragons.fire_drake'] = Display.image_load 'spr_enemies/dragons/fire_drake.png'
yield_point()
M['spr_enemies.dragons.golden_dragon'] = Display.image_load 'spr_enemies/dragons/golden_dragon.png'
yield_point()
M['spr_enemies.dragons.hydra1'] = Display.image_load 'spr_enemies/dragons/hydra1.png'
yield_point()
M['spr_enemies.dragons.hydra2'] = Display.image_load 'spr_enemies/dragons/hydra2.png'
yield_point()
M['spr_enemies.dragons.hydra3'] = Display.image_load 'spr_enemies/dragons/hydra3.png'
yield_point()
M['spr_enemies.dragons.hydra4'] = Display.image_load 'spr_enemies/dragons/hydra4.png'
yield_point()
M['spr_enemies.dragons.hydra5'] = Display.image_load 'spr_enemies/dragons/hydra5.png'
yield_point()
M['spr_enemies.dragons.ice_dragon'] = Display.image_load 'spr_enemies/dragons/ice_dragon.png'
yield_point()
M['spr_enemies.dragons.iron_dragon'] = Display.image_load 'spr_enemies/dragons/iron_dragon.png'
yield_point()
M['spr_enemies.dragons.lindwurm'] = Display.image_load 'spr_enemies/dragons/lindwurm.png'
yield_point()
M['spr_enemies.dragons.quicksilver_dragon'] = Display.image_load 'spr_enemies/dragons/quicksilver_dragon.png'
yield_point()
M['spr_enemies.dragons.rime_drake'] = Display.image_load 'spr_enemies/dragons/rime_drake.png'
yield_point()
M['spr_enemies.dragons.shadow_dragon'] = Display.image_load 'spr_enemies/dragons/shadow_dragon.png'
yield_point()
M['spr_enemies.dragons.steam_dragon'] = Display.image_load 'spr_enemies/dragons/steam_dragon.png'
yield_point()
M['spr_enemies.dragons.storm_dragon'] = Display.image_load 'spr_enemies/dragons/storm_dragon.png'
yield_point()
M['spr_enemies.dragons.swamp_dragon'] = Display.image_load 'spr_enemies/dragons/swamp_dragon.png'
yield_point()
M['spr_enemies.dragons.swamp_drake'] = Display.image_load 'spr_enemies/dragons/swamp_drake.png'
yield_point()
M['spr_enemies.dragons.wind_drake'] = Display.image_load 'spr_enemies/dragons/wind_drake.png'
yield_point()
M['spr_enemies.dragons.wyvern'] = Display.image_load 'spr_enemies/dragons/wyvern.png'
yield_point()

-- spr_enemies/bosses resource loads:
M['spr_enemies.bosses.abomination'] = Display.image_load 'spr_enemies/bosses/abomination.png'
yield_point()
M['spr_enemies.bosses.agnes'] = Display.image_load 'spr_enemies/bosses/agnes.png'
yield_point()
M['spr_enemies.bosses.agnes_staveless'] = Display.image_load 'spr_enemies/bosses/agnes_staveless.png'
yield_point()
M['spr_enemies.bosses.aizul'] = Display.image_load 'spr_enemies/bosses/aizul.png'
yield_point()
M['spr_enemies.bosses.antaeus'] = Display.image_load 'spr_enemies/bosses/antaeus.png'
yield_point()
M['spr_enemies.bosses.arachne'] = Display.image_load 'spr_enemies/bosses/arachne.png'
yield_point()
M['spr_enemies.bosses.arachne_staveless'] = Display.image_load 'spr_enemies/bosses/arachne_staveless.png'
yield_point()
M['spr_enemies.bosses.asmodeus'] = Display.image_load 'spr_enemies/bosses/asmodeus.png'
yield_point()
M['spr_enemies.bosses.asterion'] = Display.image_load 'spr_enemies/bosses/asterion.png'
yield_point()
M['spr_enemies.bosses.azrael'] = Display.image_load 'spr_enemies/bosses/azrael.png'
yield_point()
M['spr_enemies.bosses.bai_suizhen'] = Display.image_load 'spr_enemies/bosses/bai_suizhen.png'
yield_point()
M['spr_enemies.bosses.bai_suizhen_dragon'] = Display.image_load 'spr_enemies/bosses/bai_suizhen_dragon.png'
yield_point()
M['spr_enemies.bosses.blork_the_orc'] = Display.image_load 'spr_enemies/bosses/blork_the_orc.png'
yield_point()
M['spr_enemies.bosses.boris'] = Display.image_load 'spr_enemies/bosses/boris.png'
yield_point()
M['spr_enemies.bosses.boss_bee'] = Display.image_load 'spr_enemies/bosses/boss_bee.png'
yield_point()
M['spr_enemies.bosses.cerebov'] = Display.image_load 'spr_enemies/bosses/cerebov.png'
yield_point()
M['spr_enemies.bosses.chuck'] = Display.image_load 'spr_enemies/bosses/chuck.png'
yield_point()
M['spr_enemies.bosses.crazy_yiuf'] = Display.image_load 'spr_enemies/bosses/crazy_yiuf.png'
yield_point()
M['spr_enemies.bosses.deathdragon'] = Display.image_load 'spr_enemies/bosses/deathdragon.png'
yield_point()
M['spr_enemies.bosses.dispater'] = Display.image_load 'spr_enemies/bosses/dispater.png'
yield_point()
M['spr_enemies.bosses.dissolution'] = Display.image_load 'spr_enemies/bosses/dissolution.png'
yield_point()
M['spr_enemies.bosses.donald'] = Display.image_load 'spr_enemies/bosses/donald.png'
yield_point()
M['spr_enemies.bosses.dowan'] = Display.image_load 'spr_enemies/bosses/dowan.png'
yield_point()
M['spr_enemies.bosses.dowan2'] = Display.image_load 'spr_enemies/bosses/dowan2.png'
yield_point()
M['spr_enemies.bosses.duvessa'] = Display.image_load 'spr_enemies/bosses/duvessa.png'
yield_point()
M['spr_enemies.bosses.duvessa2'] = Display.image_load 'spr_enemies/bosses/duvessa2.png'
yield_point()
M['spr_enemies.bosses.edmund'] = Display.image_load 'spr_enemies/bosses/edmund.png'
yield_point()
M['spr_enemies.bosses.enchantress'] = Display.image_load 'spr_enemies/bosses/enchantress.png'
yield_point()
M['spr_enemies.bosses.ereshkigal'] = Display.image_load 'spr_enemies/bosses/ereshkigal.png'
yield_point()
M['spr_enemies.bosses.erica'] = Display.image_load 'spr_enemies/bosses/erica.png'
yield_point()
M['spr_enemies.bosses.erolcha'] = Display.image_load 'spr_enemies/bosses/erolcha.png'
yield_point()
M['spr_enemies.bosses.eustachio'] = Display.image_load 'spr_enemies/bosses/eustachio.png'
yield_point()
M['spr_enemies.bosses.fannar'] = Display.image_load 'spr_enemies/bosses/fannar.png'
yield_point()
M['spr_enemies.bosses.frances'] = Display.image_load 'spr_enemies/bosses/frances.png'
yield_point()
M['spr_enemies.bosses.frederick'] = Display.image_load 'spr_enemies/bosses/frederick.png'
yield_point()
M['spr_enemies.bosses.gastronok'] = Display.image_load 'spr_enemies/bosses/gastronok.png'
yield_point()
M['spr_enemies.bosses.geryon'] = Display.image_load 'spr_enemies/bosses/geryon.png'
yield_point()
M['spr_enemies.bosses.gloorx_vloq'] = Display.image_load 'spr_enemies/bosses/gloorx_vloq.png'
yield_point()
M['spr_enemies.bosses.gragh'] = Display.image_load 'spr_enemies/bosses/gragh.png'
yield_point()
M['spr_enemies.bosses.grinder'] = Display.image_load 'spr_enemies/bosses/grinder.png'
yield_point()
M['spr_enemies.bosses.grum'] = Display.image_load 'spr_enemies/bosses/grum.png'
yield_point()
M['spr_enemies.bosses.harold'] = Display.image_load 'spr_enemies/bosses/harold.png'
yield_point()
M['spr_enemies.bosses.helldemon'] = Display.image_load 'spr_enemies/bosses/helldemon.png'
yield_point()
M['spr_enemies.bosses.ignacio'] = Display.image_load 'spr_enemies/bosses/ignacio.png'
yield_point()
M['spr_enemies.bosses.ijyb'] = Display.image_load 'spr_enemies/bosses/ijyb.png'
yield_point()
M['spr_enemies.bosses.ilsuiw'] = Display.image_load 'spr_enemies/bosses/ilsuiw.png'
yield_point()
M['spr_enemies.bosses.ilsuiw_water'] = Display.image_load 'spr_enemies/bosses/ilsuiw_water.png'
yield_point()
M['spr_enemies.bosses.jessica'] = Display.image_load 'spr_enemies/bosses/jessica.png'
yield_point()
M['spr_enemies.bosses.jester'] = Display.image_load 'spr_enemies/bosses/jester.png'
yield_point()
M['spr_enemies.bosses.jorgrun'] = Display.image_load 'spr_enemies/bosses/jorgrun.png'
yield_point()
M['spr_enemies.bosses.jory'] = Display.image_load 'spr_enemies/bosses/jory.png'
yield_point()
M['spr_enemies.bosses.joseph'] = Display.image_load 'spr_enemies/bosses/joseph.png'
yield_point()
M['spr_enemies.bosses.josephine'] = Display.image_load 'spr_enemies/bosses/josephine.png'
yield_point()
M['spr_enemies.bosses.khufu'] = Display.image_load 'spr_enemies/bosses/khufu.png'
yield_point()
M['spr_enemies.bosses.kirke'] = Display.image_load 'spr_enemies/bosses/kirke.png'
yield_point()
M['spr_enemies.bosses.lom_lobon'] = Display.image_load 'spr_enemies/bosses/lom_lobon.png'
yield_point()
M['spr_enemies.bosses.louise'] = Display.image_load 'spr_enemies/bosses/louise.png'
yield_point()
M['spr_enemies.bosses.mara'] = Display.image_load 'spr_enemies/bosses/mara.png'
yield_point()
M['spr_enemies.bosses.margery'] = Display.image_load 'spr_enemies/bosses/margery.png'
yield_point()
M['spr_enemies.bosses.maurice'] = Display.image_load 'spr_enemies/bosses/maurice.png'
yield_point()
M['spr_enemies.bosses.menkaure'] = Display.image_load 'spr_enemies/bosses/menkaure.png'
yield_point()
M['spr_enemies.bosses.mennas'] = Display.image_load 'spr_enemies/bosses/mennas.png'
yield_point()
M['spr_enemies.bosses.mnoleg'] = Display.image_load 'spr_enemies/bosses/mnoleg.png'
yield_point()
M['spr_enemies.bosses.murray'] = Display.image_load 'spr_enemies/bosses/murray.png'
yield_point()
M['spr_enemies.bosses.natasha'] = Display.image_load 'spr_enemies/bosses/natasha.png'
yield_point()
M['spr_enemies.bosses.nellie'] = Display.image_load 'spr_enemies/bosses/nellie.png'
yield_point()
M['spr_enemies.bosses.nergalle'] = Display.image_load 'spr_enemies/bosses/nergalle.png'
yield_point()
M['spr_enemies.bosses.nessos'] = Display.image_load 'spr_enemies/bosses/nessos.png'
yield_point()
M['spr_enemies.bosses.nikola'] = Display.image_load 'spr_enemies/bosses/nikola.png'
yield_point()
M['spr_enemies.bosses.pikel'] = Display.image_load 'spr_enemies/bosses/pikel.png'
yield_point()
M['spr_enemies.bosses.polyphemus'] = Display.image_load 'spr_enemies/bosses/polyphemus.png'
yield_point()
M['spr_enemies.bosses.prince_ribbit'] = Display.image_load 'spr_enemies/bosses/prince_ribbit.png'
yield_point()
M['spr_enemies.bosses.psyche'] = Display.image_load 'spr_enemies/bosses/psyche.png'
yield_point()
M['spr_enemies.bosses.purgy'] = Display.image_load 'spr_enemies/bosses/purgy.png'
yield_point()
M['spr_enemies.bosses.robin'] = Display.image_load 'spr_enemies/bosses/robin.png'
yield_point()
M['spr_enemies.bosses.roxanne'] = Display.image_load 'spr_enemies/bosses/roxanne.png'
yield_point()
M['spr_enemies.bosses.royal_jelly'] = Display.image_load 'spr_enemies/bosses/royal_jelly.png'
yield_point()
M['spr_enemies.bosses.rupert'] = Display.image_load 'spr_enemies/bosses/rupert.png'
yield_point()
M['spr_enemies.bosses.saint_roka'] = Display.image_load 'spr_enemies/bosses/saint_roka.png'
yield_point()
M['spr_enemies.bosses.serpent_of_hell-coc'] = Display.image_load 'spr_enemies/bosses/serpent_of_hell-coc.png'
yield_point()
M['spr_enemies.bosses.serpent_of_hell-dis'] = Display.image_load 'spr_enemies/bosses/serpent_of_hell-dis.png'
yield_point()
M['spr_enemies.bosses.serpent_of_hell-geh'] = Display.image_load 'spr_enemies/bosses/serpent_of_hell-geh.png'
yield_point()
M['spr_enemies.bosses.serpent_of_hell-tar'] = Display.image_load 'spr_enemies/bosses/serpent_of_hell-tar.png'
yield_point()
M['spr_enemies.bosses.sigmund'] = Display.image_load 'spr_enemies/bosses/sigmund.png'
yield_point()
M['spr_enemies.bosses.skulldragon'] = Display.image_load 'spr_enemies/bosses/skulldragon.png'
yield_point()
M['spr_enemies.bosses.snorg'] = Display.image_load 'spr_enemies/bosses/snorg.png'
yield_point()
M['spr_enemies.bosses.sojobo'] = Display.image_load 'spr_enemies/bosses/sojobo.png'
yield_point()
M['spr_enemies.bosses.sonja'] = Display.image_load 'spr_enemies/bosses/sonja.png'
yield_point()
M['spr_enemies.bosses.spider'] = Display.image_load 'spr_enemies/bosses/spider.png'
yield_point()
M['spr_enemies.bosses.stara'] = Display.image_load 'spr_enemies/bosses/stara.png'
yield_point()
M['spr_enemies.bosses.Stormcaller'] = Display.image_load 'spr_enemies/bosses/Stormcaller.png'
yield_point()
M['spr_enemies.bosses.terence'] = Display.image_load 'spr_enemies/bosses/terence.png'
yield_point()
M['spr_enemies.bosses.tiamat_black'] = Display.image_load 'spr_enemies/bosses/tiamat_black.png'
yield_point()
M['spr_enemies.bosses.tiamat_green'] = Display.image_load 'spr_enemies/bosses/tiamat_green.png'
yield_point()
M['spr_enemies.bosses.tiamat_grey'] = Display.image_load 'spr_enemies/bosses/tiamat_grey.png'
yield_point()
M['spr_enemies.bosses.tiamat_mottled'] = Display.image_load 'spr_enemies/bosses/tiamat_mottled.png'
yield_point()
M['spr_enemies.bosses.tiamat_pale'] = Display.image_load 'spr_enemies/bosses/tiamat_pale.png'
yield_point()
M['spr_enemies.bosses.tiamat_purple'] = Display.image_load 'spr_enemies/bosses/tiamat_purple.png'
yield_point()
M['spr_enemies.bosses.tiamat_red'] = Display.image_load 'spr_enemies/bosses/tiamat_red.png'
yield_point()
M['spr_enemies.bosses.tiamat_white'] = Display.image_load 'spr_enemies/bosses/tiamat_white.png'
yield_point()
M['spr_enemies.bosses.tiamat_yellow'] = Display.image_load 'spr_enemies/bosses/tiamat_yellow.png'
yield_point()
M['spr_enemies.bosses.urug'] = Display.image_load 'spr_enemies/bosses/urug.png'
yield_point()
M['spr_enemies.bosses.vashnia'] = Display.image_load 'spr_enemies/bosses/vashnia.png'
yield_point()
M['spr_enemies.bosses.xtahua'] = Display.image_load 'spr_enemies/bosses/xtahua.png'
yield_point()

-- spr_rings/randarts resource loads:
M['spr_rings.randarts.anvil'] = Display.image_load 'spr_rings/randarts/anvil.png'
yield_point()
M['spr_rings.randarts.blood'] = Display.image_load 'spr_rings/randarts/blood.png'
yield_point()
M['spr_rings.randarts.bronze-flower'] = Display.image_load 'spr_rings/randarts/bronze-flower.png'
yield_point()
M['spr_rings.randarts.dark'] = Display.image_load 'spr_rings/randarts/dark.png'
yield_point()
M['spr_rings.randarts.double'] = Display.image_load 'spr_rings/randarts/double.png'
yield_point()
M['spr_rings.randarts.eye'] = Display.image_load 'spr_rings/randarts/eye.png'
yield_point()
M['spr_rings.randarts.fire'] = Display.image_load 'spr_rings/randarts/fire.png'
yield_point()
M['spr_rings.randarts.flower'] = Display.image_load 'spr_rings/randarts/flower.png'
yield_point()
M['spr_rings.randarts.four-colour'] = Display.image_load 'spr_rings/randarts/four-colour.png'
yield_point()
M['spr_rings.randarts.green'] = Display.image_load 'spr_rings/randarts/green.png'
yield_point()
M['spr_rings.randarts.ice'] = Display.image_load 'spr_rings/randarts/ice.png'
yield_point()
M['spr_rings.randarts.pink'] = Display.image_load 'spr_rings/randarts/pink.png'
yield_point()
M['spr_rings.randarts.red-blue'] = Display.image_load 'spr_rings/randarts/red-blue.png'
yield_point()
M['spr_rings.randarts.snake'] = Display.image_load 'spr_rings/randarts/snake.png'
yield_point()
M['spr_rings.randarts.urand_mage'] = Display.image_load 'spr_rings/randarts/urand_mage.png'
yield_point()
M['spr_rings.randarts.urand_octoring'] = Display.image_load 'spr_rings/randarts/urand_octoring.png'
yield_point()
M['spr_rings.randarts.urand_robustness'] = Display.image_load 'spr_rings/randarts/urand_robustness.png'
yield_point()
M['spr_rings.randarts.urand_shadows'] = Display.image_load 'spr_rings/randarts/urand_shadows.png'
yield_point()
M['spr_rings.randarts.urand_shaolin'] = Display.image_load 'spr_rings/randarts/urand_shaolin.png'
yield_point()
M['spr_rings.randarts.vampirism'] = Display.image_load 'spr_rings/randarts/vampirism.png'
yield_point()
M['spr_rings.randarts.zircon'] = Display.image_load 'spr_rings/randarts/zircon.png'
yield_point()

-- spr_amulets/randarts resource loads:
M['spr_amulets.randarts.azure'] = Display.image_load 'spr_amulets/randarts/azure.png'
yield_point()
M['spr_amulets.randarts.cluster'] = Display.image_load 'spr_amulets/randarts/cluster.png'
yield_point()
M['spr_amulets.randarts.drop'] = Display.image_load 'spr_amulets/randarts/drop.png'
yield_point()
M['spr_amulets.randarts.knot'] = Display.image_load 'spr_amulets/randarts/knot.png'
yield_point()
M['spr_amulets.randarts.scarab'] = Display.image_load 'spr_amulets/randarts/scarab.png'
yield_point()
M['spr_amulets.randarts.sun'] = Display.image_load 'spr_amulets/randarts/sun.png'
yield_point()

-- spr_belts/randarts resource loads:
M['spr_belts.randarts.dark'] = Display.image_load 'spr_belts/randarts/dark.png'
yield_point()
M['spr_belts.randarts.emo'] = Display.image_load 'spr_belts/randarts/emo.png'
yield_point()
M['spr_belts.randarts.flashy'] = Display.image_load 'spr_belts/randarts/flashy.png'
yield_point()

-- spr_legwear/randarts resource loads:
M['spr_legwear.randarts.pants'] = Display.image_load 'spr_legwear/randarts/pants.png'
yield_point()
M['spr_legwear.randarts.pants2'] = Display.image_load 'spr_legwear/randarts/pants2.png'
yield_point()
M['spr_legwear.randarts.pants3'] = Display.image_load 'spr_legwear/randarts/pants3.png'
yield_point()
M['spr_legwear.randarts.platelegs'] = Display.image_load 'spr_legwear/randarts/platelegs.png'
yield_point()

M.resource_id_list = {
    'spr_amulets.amethyst',
    'spr_amulets.berserk',
    'spr_amulets.beryl',
    'spr_amulets.blue',
    'spr_amulets.bone',
    'spr_amulets.brass',
    'spr_amulets.bronze',
    'spr_amulets.cabochon',
    'spr_amulets.cameo',
    'spr_amulets.citrine',
    'spr_amulets.copper',
    'spr_amulets.diamond',
    'spr_amulets.emerald',
    'spr_amulets.fear_strike',
    'spr_amulets.filigree',
    'spr_amulets.fireball',
    'spr_amulets.flourescent',
    'spr_amulets.garnet',
    'spr_amulets.golden',
    'spr_amulets.greaterfireball',
    'spr_amulets.greaterpain',
    'spr_amulets.greed',
    'spr_amulets.healing',
    'spr_amulets.i-dismissal',
    'spr_amulets.i-faith',
    'spr_amulets.i-gourmand',
    'spr_amulets.i-harm',
    'spr_amulets.i-inaccuracy',
    'spr_amulets.i-m-regeneration',
    'spr_amulets.i-rage',
    'spr_amulets.i-reflection',
    'spr_amulets.i-regeneration',
    'spr_amulets.i-spirit',
    'spr_amulets.iceform',
    'spr_amulets.jade',
    'spr_amulets.jasper',
    'spr_amulets.lapis_lazuli',
    'spr_amulets.light',
    'spr_amulets.malachite',
    'spr_amulets.pain',
    'spr_amulets.pearl',
    'spr_amulets.peridot',
    'spr_amulets.platinum',
    'spr_amulets.protect',
    'spr_amulets.randarts.azure',
    'spr_amulets.randarts.cluster',
    'spr_amulets.randarts.drop',
    'spr_amulets.randarts.knot',
    'spr_amulets.randarts.scarab',
    'spr_amulets.randarts.sun',
    'spr_amulets.regeneration',
    'spr_amulets.ruby',
    'spr_amulets.sapphire',
    'spr_amulets.silver',
    'spr_amulets.skull',
    'spr_amulets.soapstone',
    'spr_amulets.spider',
    'spr_amulets.steel',
    'spr_amulets.urand_bloodlust',
    'spr_amulets.zirconium',
    'spr_armour.acid_dragon_armour',
    'spr_armour.animal_skin1',
    'spr_armour.animal_skin2',
    'spr_armour.animal_skin3',
    'spr_armour.blue_dragon_scale_mail',
    'spr_armour.buckler1',
    'spr_armour.buckler2',
    'spr_armour.buckler3',
    'spr_armour.buckler_spriggan',
    'spr_armour.cap1',
    'spr_armour.cap_jester',
    'spr_armour.centaur_barding_blue',
    'spr_armour.centaur_barding_magenta',
    'spr_armour.centaur_barding_metal',
    'spr_armour.centaur_barding_red',
    'spr_armour.chain_mail1',
    'spr_armour.chain_mail2',
    'spr_armour.chain_mail3',
    'spr_armour.cloak1_leather',
    'spr_armour.cloak2',
    'spr_armour.cloak3',
    'spr_armour.cloak4',
    'spr_armour.cornuthaum',
    'spr_armour.crystal_plate',
    'spr_armour.crystal_plate2',
    'spr_armour.crystal_plate3',
    'spr_armour.dwarven_buckler1',
    'spr_armour.dwarven_buckler2',
    'spr_armour.elven_buckler1',
    'spr_armour.elven_buckler2',
    'spr_armour.elven_leather_helm',
    'spr_armour.gauntlet1',
    'spr_armour.glove1',
    'spr_armour.glove2',
    'spr_armour.glove3',
    'spr_armour.glove4',
    'spr_armour.glove5',
    'spr_armour.gloves_confusion',
    'spr_armour.gloves_confusion_randart',
    'spr_armour.gloves_fear',
    'spr_armour.gloves_fear_randart',
    'spr_armour.gold_dragon_armour',
    'spr_armour.green_robe',
    'spr_armour.hat1',
    'spr_armour.hat2',
    'spr_armour.hat3',
    'spr_armour.hat4',
    'spr_armour.hat5',
    'spr_armour.helmet1',
    'spr_armour.helmet2',
    'spr_armour.helmet3',
    'spr_armour.helmet4',
    'spr_armour.helmet5',
    'spr_armour.helmet_art1',
    'spr_armour.helmet_art2',
    'spr_armour.helmet_art3',
    'spr_armour.helmet_ego1',
    'spr_armour.helmet_ego2',
    'spr_armour.helmet_ego3',
    'spr_armour.helmet_ego4',
    'spr_armour.i-archery',
    'spr_armour.i-archmagi',
    'spr_armour.i-cold-res',
    'spr_armour.i-dexterity',
    'spr_armour.i-fire-res',
    'spr_armour.i-flying',
    'spr_armour.i-intelligence',
    'spr_armour.i-invisibility',
    'spr_armour.i-jumping',
    'spr_armour.i-magic-res',
    'spr_armour.i-poison-res',
    'spr_armour.i-ponderous',
    'spr_armour.i-positive-energy',
    'spr_armour.i-preservation',
    'spr_armour.i-protection',
    'spr_armour.i-reflection',
    'spr_armour.i-resistance',
    'spr_armour.i-running',
    'spr_armour.i-see-invis',
    'spr_armour.i-spirit',
    'spr_armour.i-stealth',
    'spr_armour.i-strength',
    'spr_armour.ice_dragon_armour',
    'spr_armour.large_shield1',
    'spr_armour.large_shield2',
    'spr_armour.large_shield3',
    'spr_armour.leather_armour1',
    'spr_armour.leather_armour2',
    'spr_armour.leather_armour3',
    'spr_armour.lshield_dd_dk',
    'spr_armour.lshield_louise',
    'spr_armour.naga_barding_blue',
    'spr_armour.naga_barding_magenta',
    'spr_armour.naga_barding_metal',
    'spr_armour.naga_barding_red',
    'spr_armour.orcish_plate2',
    'spr_armour.pearl_dragon_armour',
    'spr_armour.plate1',
    'spr_armour.plate2',
    'spr_armour.plate3',
    'spr_armour.plumed_helmet',
    'spr_armour.poison_resist_leather',
    'spr_armour.quicksilver_dragon_scale_mail',
    'spr_armour.randart_glove1',
    'spr_armour.randart_glove2',
    'spr_armour.randart_glove3',
    'spr_armour.randart_glove4',
    'spr_armour.randart_hat',
    'spr_armour.randart_helmet',
    'spr_armour.randart_plate',
    'spr_armour.randart_robe1',
    'spr_armour.randart_robe2',
    'spr_armour.red_dragon_scale_mail',
    'spr_armour.ring_mail1',
    'spr_armour.ring_mail2',
    'spr_armour.ring_mail3',
    'spr_armour.robe1',
    'spr_armour.robe2',
    'spr_armour.robe_art1',
    'spr_armour.robe_art2',
    'spr_armour.robe_ego1',
    'spr_armour.robe_ego2',
    'spr_armour.robe_of_health',
    'spr_armour.robe_of_mana',
    'spr_armour.scale_mail1',
    'spr_armour.scale_mail2',
    'spr_armour.scale_mail3',
    'spr_armour.shadow_dragon_scale_mail',
    'spr_armour.shield1',
    'spr_armour.shield2',
    'spr_armour.shield3',
    'spr_armour.shield_dd',
    'spr_armour.shield_dd_scion',
    'spr_armour.shield_donald',
    'spr_armour.silver_dragon_scale_mail',
    'spr_armour.swamp_dragon_armour',
    'spr_armour.troll_leather_armour',
    'spr_armour.urand_alchemist',
    'spr_armour.urand_augmentation',
    'spr_armour.urand_bear',
    'spr_armour.urand_bk_barding',
    'spr_armour.urand_bullseye',
    'spr_armour.urand_clouds',
    'spr_armour.urand_dragon_king',
    'spr_armour.urand_dragonmask',
    'spr_armour.urand_dragonskin',
    'spr_armour.urand_dyrovepreva',
    'spr_armour.urand_eternal_torment',
    'spr_armour.urand_etheric_cage',
    'spr_armour.urand_faerie',
    'spr_armour.urand_fencer',
    'spr_armour.urand_flash',
    'spr_armour.urand_folly',
    'spr_armour.urand_gong',
    'spr_armour.urand_high_council',
    'spr_armour.urand_ignorance',
    'spr_armour.urand_kryias',
    'spr_armour.urand_lear',
    'spr_armour.urand_lightning_scales',
    'spr_armour.urand_maxwell',
    'spr_armour.urand_misfortune',
    'spr_armour.urand_moon_troll_leather_armour',
    'spr_armour.urand_night',
    'spr_armour.urand_orange_crystal',
    'spr_armour.urand_pondering',
    'spr_armour.urand_ratskin_cloak',
    'spr_armour.urand_resistance',
    'spr_armour.urand_salamander',
    'spr_armour.urand_starlight',
    'spr_armour.urand_talos',
    'spr_armour.urand_thief',
    'spr_armour.urand_vines',
    'spr_armour.urand_war',
    'spr_armour.urand_warlock',
    'spr_armour.urand_zhor',
    'spr_armour.white_robe',
    'spr_belts.base-belt',
    'spr_belts.life-belt',
    'spr_belts.poison',
    'spr_belts.protection',
    'spr_belts.randarts.dark',
    'spr_belts.randarts.emo',
    'spr_belts.randarts.flashy',
    'spr_belts.slaying',
    'spr_belts.spike',
    'spr_belts.warped',
    'spr_belts.wishful',
    'spr_books.book_of_the_dead',
    'spr_books.bronze',
    'spr_books.cloth',
    'spr_books.copper',
    'spr_books.cyan',
    'spr_books.dark_blue',
    'spr_books.dark_brown',
    'spr_books.dark_gray',
    'spr_books.dark_green',
    'spr_books.gold',
    'spr_books.leather',
    'spr_books.light_blue',
    'spr_books.light_brown',
    'spr_books.light_gray',
    'spr_books.light_green',
    'spr_books.magenta',
    'spr_books.manual1',
    'spr_books.manual2',
    'spr_books.metal_blue',
    'spr_books.metal_cyan',
    'spr_books.metal_green',
    'spr_books.parchment',
    'spr_books.pink',
    'spr_books.plaid',
    'spr_books.purple',
    'spr_books.red',
    'spr_books.silver',
    'spr_books.tan',
    'spr_books.turquoise',
    'spr_books.white',
    'spr_books.yellow',
    'spr_boots.boots1_brown',
    'spr_boots.boots2_jackboots',
    'spr_boots.boots3_stripe',
    'spr_boots.boots4_green',
    'spr_boots.boots_iron2',
    'spr_boots.festive_boots',
    'spr_boots.randart_leather_boots',
    'spr_boots.shield2',
    'spr_boots.urand_assassin',
    'spr_boots.urand_spider',
    'spr_classes.black_mage1',
    'spr_classes.black_mage2',
    'spr_classes.blue_mage1',
    'spr_classes.blue_mage2',
    'spr_classes.green_mage1',
    'spr_classes.green_mage2',
    'spr_classes.icons.archer',
    'spr_classes.icons.blackmage',
    'spr_classes.icons.bluemage',
    'spr_classes.icons.druid',
    'spr_classes.icons.fighter',
    'spr_classes.icons.greenmage',
    'spr_classes.icons.lifelinker',
    'spr_classes.icons.necromancer',
    'spr_classes.icons.redmage',
    'spr_classes.icons.rogue',
    'spr_classes.icons.whitemage',
    'spr_classes.red_mage1',
    'spr_classes.red_mage2',
    'spr_classes.rogue1',
    'spr_classes.rogue2',
    'spr_classes.white_mage1',
    'spr_classes.white_mage2',
    'spr_doors.closed_door',
    'spr_doors.closed_door_crypt',
    'spr_doors.fleshy_orifice_closed',
    'spr_doors.fleshy_orifice_open',
    'spr_doors.gate_closed_left',
    'spr_doors.gate_closed_left_crypt',
    'spr_doors.gate_closed_middle',
    'spr_doors.gate_closed_middle_crypt',
    'spr_doors.gate_closed_right',
    'spr_doors.gate_closed_right_crypt',
    'spr_doors.gate_open_left',
    'spr_doors.gate_open_left_crypt',
    'spr_doors.gate_open_middle',
    'spr_doors.gate_open_middle_crypt',
    'spr_doors.gate_open_right',
    'spr_doors.gate_open_right_crypt',
    'spr_doors.gate_runed_left',
    'spr_doors.gate_runed_middle',
    'spr_doors.gate_runed_right',
    'spr_doors.gate_sealed_left',
    'spr_doors.gate_sealed_middle',
    'spr_doors.gate_sealed_right',
    'spr_doors.healingsqr',
    'spr_doors.open_door',
    'spr_doors.open_door_crypt',
    'spr_doors.runed_door',
    'spr_doors.sealed_door',
    'spr_doors.vgate_closed_down',
    'spr_doors.vgate_closed_down_crypt',
    'spr_doors.vgate_closed_middle',
    'spr_doors.vgate_closed_middle_crypt',
    'spr_doors.vgate_closed_up',
    'spr_doors.vgate_closed_up_crypt',
    'spr_doors.vgate_open_down',
    'spr_doors.vgate_open_down_crypt',
    'spr_doors.vgate_open_middle',
    'spr_doors.vgate_open_middle_crypt',
    'spr_doors.vgate_open_up',
    'spr_doors.vgate_open_up_crypt',
    'spr_doors.vgate_runed_down',
    'spr_doors.vgate_runed_middle',
    'spr_doors.vgate_runed_up',
    'spr_doors.vgate_sealed_down',
    'spr_doors.vgate_sealed_middle',
    'spr_doors.vgate_sealed_up',
    'spr_effects.animated_weapon',
    'spr_effects.berserk',
    'spr_effects.black-power',
    'spr_effects.black-resist',
    'spr_effects.blind',
    'spr_effects.bound_soul',
    'spr_effects.confusion',
    'spr_effects.constricted',
    'spr_effects.deathnote',
    'spr_effects.deaths_door',
    'spr_effects.demon_pentagram1',
    'spr_effects.demon_pentagram2',
    'spr_effects.demon_pentagram3',
    'spr_effects.demon_pentagram4',
    'spr_effects.demon_pentagram5',
    'spr_effects.dragon_fireball',
    'spr_effects.drain',
    'spr_effects.fire-anim',
    'spr_effects.fireball2',
    'spr_effects.fireball_small',
    'spr_effects.firebolt',
    'spr_effects.fleeing',
    'spr_effects.friendly',
    'spr_effects.glowing',
    'spr_effects.good_neutral',
    'spr_effects.hasted',
    'spr_effects.i-c-teleport',
    'spr_effects.i-cold-big',
    'spr_effects.i-dex',
    'spr_effects.i-evasion',
    'spr_effects.i-fire',
    'spr_effects.i-fire-big',
    'spr_effects.i-flight',
    'spr_effects.i-ice',
    'spr_effects.i-int',
    'spr_effects.i-life-protection',
    'spr_effects.i-loudness',
    'spr_effects.i-magical-power',
    'spr_effects.i-poison-big',
    'spr_effects.i-protection',
    'spr_effects.i-protection-big',
    'spr_effects.i-r-cold',
    'spr_effects.i-r-cold-big',
    'spr_effects.i-r-corrosion',
    'spr_effects.i-r-fire',
    'spr_effects.i-r-fire-big',
    'spr_effects.i-r-magic',
    'spr_effects.i-r-poison',
    'spr_effects.i-r-poison-big',
    'spr_effects.i-s-attr',
    'spr_effects.i-see-invis',
    'spr_effects.i-slaying',
    'spr_effects.i-stealth',
    'spr_effects.i-str',
    'spr_effects.i-teleport',
    'spr_effects.i-wizardry',
    'spr_effects.iceball',
    'spr_effects.idealised',
    'spr_effects.infested',
    'spr_effects.inner_flame',
    'spr_effects.lightningbolt',
    'spr_effects.may_stab_brand',
    'spr_effects.might',
    'spr_effects.neutral',
    'spr_effects.new_stair',
    'spr_effects.pain_mirror',
    'spr_effects.petrified',
    'spr_effects.petrifying',
    'spr_effects.poison',
    'spr_effects.recall',
    'spr_effects.shock',
    'spr_effects.shock-resist',
    'spr_effects.skullnado',
    'spr_effects.sleeping',
    'spr_effects.slowed',
    'spr_effects.something_under',
    'spr_effects.sticky_flame',
    'spr_effects.stormcloud',
    'spr_effects.stormcloud_shadow',
    'spr_effects.summoned',
    'spr_effects.summoned_durable',
    'spr_effects.sword',
    'spr_effects.tornado',
    'spr_effects.waterbolt',
    'spr_effects.weapon_confusion',
    'spr_effects.weapon_poison',
    'spr_effects.weapon_vampirism',
    'spr_enemies.animals.adder',
    'spr_enemies.animals.alligator',
    'spr_enemies.animals.alligator_snapping_turtle',
    'spr_enemies.animals.anaconda',
    'spr_enemies.animals.ball_python',
    'spr_enemies.animals.basilisk',
    'spr_enemies.animals.bat',
    'spr_enemies.animals.bennu',
    'spr_enemies.animals.black_bear',
    'spr_enemies.animals.black_mamba',
    'spr_enemies.animals.blink_frog',
    'spr_enemies.animals.bullfrog',
    'spr_enemies.animals.butterfly',
    'spr_enemies.animals.butterfly1',
    'spr_enemies.animals.butterfly10',
    'spr_enemies.animals.butterfly2',
    'spr_enemies.animals.butterfly3',
    'spr_enemies.animals.butterfly4',
    'spr_enemies.animals.butterfly5',
    'spr_enemies.animals.butterfly6',
    'spr_enemies.animals.butterfly7',
    'spr_enemies.animals.butterfly8',
    'spr_enemies.animals.butterfly9',
    'spr_enemies.animals.catoblepas',
    'spr_enemies.animals.caustic_shrike',
    'spr_enemies.animals.chicken',
    'spr_enemies.animals.chicken_boss1',
    'spr_enemies.animals.chicken_boss2',
    'spr_enemies.animals.chicken_boss3',
    'spr_enemies.animals.chicken_giant',
    'spr_enemies.animals.crocodile',
    'spr_enemies.animals.dart_slug',
    'spr_enemies.animals.deadhydra',
    'spr_enemies.animals.death_yak',
    'spr_enemies.animals.doom_hound',
    'spr_enemies.animals.dream_sheep',
    'spr_enemies.animals.elephant',
    'spr_enemies.animals.elephant_demonic',
    'spr_enemies.animals.elephant_dire',
    'spr_enemies.animals.elephant_slug',
    'spr_enemies.animals.emperor_scorpion',
    'spr_enemies.animals.fire_bat',
    'spr_enemies.animals.fire_crab',
    'spr_enemies.animals.frilled_lizard',
    'spr_enemies.animals.ghost_crab',
    'spr_enemies.animals.ghost_moth',
    'spr_enemies.animals.giant_cockroach',
    'spr_enemies.animals.giant_frog',
    'spr_enemies.animals.giant_rat',
    'spr_enemies.animals.goliath_beetle',
    'spr_enemies.animals.green_rat',
    'spr_enemies.animals.hell_hog',
    'spr_enemies.animals.hell_hound',
    'spr_enemies.animals.hog',
    'spr_enemies.animals.holy_swine',
    'spr_enemies.animals.hornet',
    'spr_enemies.animals.horse',
    'spr_enemies.animals.hound',
    'spr_enemies.animals.howler',
    'spr_enemies.animals.hydra',
    'spr_enemies.animals.ice_beast',
    'spr_enemies.animals.iguana',
    'spr_enemies.animals.jackal',
    'spr_enemies.animals.jumping_spider',
    'spr_enemies.animals.killer_bee',
    'spr_enemies.animals.komodo_dragon',
    'spr_enemies.animals.lava_fish',
    'spr_enemies.animals.leopard_gecko',
    'spr_enemies.animals.mana_viper',
    'spr_enemies.animals.moth_of_wrath',
    'spr_enemies.animals.orange_rat',
    'spr_enemies.animals.orb_spider',
    'spr_enemies.animals.polar_bear',
    'spr_enemies.animals.porcupine',
    'spr_enemies.animals.poulter',
    'spr_enemies.animals.queen_ant',
    'spr_enemies.animals.queen_bee',
    'spr_enemies.animals.quokka',
    'spr_enemies.animals.raiju',
    'spr_enemies.animals.rat',
    'spr_enemies.animals.redback',
    'spr_enemies.animals.scorpion',
    'spr_enemies.animals.sea_snake',
    'spr_enemies.animals.shard_shrike',
    'spr_enemies.animals.sheep',
    'spr_enemies.animals.shock_serpent',
    'spr_enemies.animals.sky_beast',
    'spr_enemies.animals.snapping_turtle',
    'spr_enemies.animals.soldier_ant',
    'spr_enemies.animals.spark_wasp',
    'spr_enemies.animals.spider',
    'spr_enemies.animals.spiny_frog',
    'spr_enemies.animals.superchicken',
    'spr_enemies.animals.tarantella',
    'spr_enemies.animals.torpor_snail',
    'spr_enemies.animals.tyrant_leech',
    'spr_enemies.animals.vampire_bat',
    'spr_enemies.animals.vampire_mosquito',
    'spr_enemies.animals.warg',
    'spr_enemies.animals.water_moccasin',
    'spr_enemies.animals.wolf',
    'spr_enemies.animals.wolf_spider',
    'spr_enemies.animals.worker_ant',
    'spr_enemies.animals.worm',
    'spr_enemies.animals.yak',
    'spr_enemies.bosses.Stormcaller',
    'spr_enemies.bosses.abomination',
    'spr_enemies.bosses.agnes',
    'spr_enemies.bosses.agnes_staveless',
    'spr_enemies.bosses.aizul',
    'spr_enemies.bosses.antaeus',
    'spr_enemies.bosses.arachne',
    'spr_enemies.bosses.arachne_staveless',
    'spr_enemies.bosses.asmodeus',
    'spr_enemies.bosses.asterion',
    'spr_enemies.bosses.azrael',
    'spr_enemies.bosses.bai_suizhen',
    'spr_enemies.bosses.bai_suizhen_dragon',
    'spr_enemies.bosses.blork_the_orc',
    'spr_enemies.bosses.boris',
    'spr_enemies.bosses.boss_bee',
    'spr_enemies.bosses.cerebov',
    'spr_enemies.bosses.chuck',
    'spr_enemies.bosses.crazy_yiuf',
    'spr_enemies.bosses.deathdragon',
    'spr_enemies.bosses.dispater',
    'spr_enemies.bosses.dissolution',
    'spr_enemies.bosses.donald',
    'spr_enemies.bosses.dowan',
    'spr_enemies.bosses.dowan2',
    'spr_enemies.bosses.duvessa',
    'spr_enemies.bosses.duvessa2',
    'spr_enemies.bosses.edmund',
    'spr_enemies.bosses.enchantress',
    'spr_enemies.bosses.ereshkigal',
    'spr_enemies.bosses.erica',
    'spr_enemies.bosses.erolcha',
    'spr_enemies.bosses.eustachio',
    'spr_enemies.bosses.fannar',
    'spr_enemies.bosses.frances',
    'spr_enemies.bosses.frederick',
    'spr_enemies.bosses.gastronok',
    'spr_enemies.bosses.geryon',
    'spr_enemies.bosses.gloorx_vloq',
    'spr_enemies.bosses.gragh',
    'spr_enemies.bosses.grinder',
    'spr_enemies.bosses.grum',
    'spr_enemies.bosses.harold',
    'spr_enemies.bosses.helldemon',
    'spr_enemies.bosses.ignacio',
    'spr_enemies.bosses.ijyb',
    'spr_enemies.bosses.ilsuiw',
    'spr_enemies.bosses.ilsuiw_water',
    'spr_enemies.bosses.jessica',
    'spr_enemies.bosses.jester',
    'spr_enemies.bosses.jorgrun',
    'spr_enemies.bosses.jory',
    'spr_enemies.bosses.joseph',
    'spr_enemies.bosses.josephine',
    'spr_enemies.bosses.khufu',
    'spr_enemies.bosses.kirke',
    'spr_enemies.bosses.lom_lobon',
    'spr_enemies.bosses.louise',
    'spr_enemies.bosses.mara',
    'spr_enemies.bosses.margery',
    'spr_enemies.bosses.maurice',
    'spr_enemies.bosses.menkaure',
    'spr_enemies.bosses.mennas',
    'spr_enemies.bosses.mnoleg',
    'spr_enemies.bosses.murray',
    'spr_enemies.bosses.natasha',
    'spr_enemies.bosses.nellie',
    'spr_enemies.bosses.nergalle',
    'spr_enemies.bosses.nessos',
    'spr_enemies.bosses.nikola',
    'spr_enemies.bosses.pikel',
    'spr_enemies.bosses.polyphemus',
    'spr_enemies.bosses.prince_ribbit',
    'spr_enemies.bosses.psyche',
    'spr_enemies.bosses.purgy',
    'spr_enemies.bosses.robin',
    'spr_enemies.bosses.roxanne',
    'spr_enemies.bosses.royal_jelly',
    'spr_enemies.bosses.rupert',
    'spr_enemies.bosses.saint_roka',
    'spr_enemies.bosses.serpent_of_hell-coc',
    'spr_enemies.bosses.serpent_of_hell-dis',
    'spr_enemies.bosses.serpent_of_hell-geh',
    'spr_enemies.bosses.serpent_of_hell-tar',
    'spr_enemies.bosses.sigmund',
    'spr_enemies.bosses.skulldragon',
    'spr_enemies.bosses.snorg',
    'spr_enemies.bosses.sojobo',
    'spr_enemies.bosses.sonja',
    'spr_enemies.bosses.spider',
    'spr_enemies.bosses.stara',
    'spr_enemies.bosses.terence',
    'spr_enemies.bosses.tiamat_black',
    'spr_enemies.bosses.tiamat_green',
    'spr_enemies.bosses.tiamat_grey',
    'spr_enemies.bosses.tiamat_mottled',
    'spr_enemies.bosses.tiamat_pale',
    'spr_enemies.bosses.tiamat_purple',
    'spr_enemies.bosses.tiamat_red',
    'spr_enemies.bosses.tiamat_white',
    'spr_enemies.bosses.tiamat_yellow',
    'spr_enemies.bosses.urug',
    'spr_enemies.bosses.vashnia',
    'spr_enemies.bosses.xtahua',
    'spr_enemies.demons.balrug',
    'spr_enemies.demons.blizzard_demon',
    'spr_enemies.demons.brimstone_fiend',
    'spr_enemies.demons.cacodemon',
    'spr_enemies.demons.chaos_spawn1',
    'spr_enemies.demons.chaos_spawn2',
    'spr_enemies.demons.chaos_spawn3',
    'spr_enemies.demons.chaos_spawn4',
    'spr_enemies.demons.chaos_spawn5',
    'spr_enemies.demons.crimson_imp',
    'spr_enemies.demons.demonic_crawler',
    'spr_enemies.demons.efreet',
    'spr_enemies.demons.executioner',
    'spr_enemies.demons.green_death',
    'spr_enemies.demons.hell_beast',
    'spr_enemies.demons.hell_sentinel',
    'spr_enemies.demons.hellion',
    'spr_enemies.demons.hellwing',
    'spr_enemies.demons.ice_devil',
    'spr_enemies.demons.ice_fiend',
    'spr_enemies.demons.iron_imp',
    'spr_enemies.demons.lorocyproca',
    'spr_enemies.demons.manasapper',
    'spr_enemies.demons.neqoxec',
    'spr_enemies.demons.orange_demon',
    'spr_enemies.demons.quasit',
    'spr_enemies.demons.rakshasa',
    'spr_enemies.demons.reaper',
    'spr_enemies.demons.red_devil',
    'spr_enemies.demons.rust_devil',
    'spr_enemies.demons.shadow_demon',
    'spr_enemies.demons.shadow_imp',
    'spr_enemies.demons.sixfirhy',
    'spr_enemies.demons.smoke_demon',
    'spr_enemies.demons.soul_eater',
    'spr_enemies.demons.sun_demon',
    'spr_enemies.demons.tormentor',
    'spr_enemies.demons.tzitzimitl',
    'spr_enemies.demons.ufetubus',
    'spr_enemies.demons.white_imp',
    'spr_enemies.demons.ynoxinul',
    'spr_enemies.demonspawn.black_sun',
    'spr_enemies.demonspawn.blood_saint',
    'spr_enemies.demonspawn.corrupter',
    'spr_enemies.demonspawn.demonspawn',
    'spr_enemies.demonspawn.gelid',
    'spr_enemies.demonspawn.infernal',
    'spr_enemies.demonspawn.monstrous',
    'spr_enemies.demonspawn.torturous',
    'spr_enemies.demonspawn.warmonger',
    'spr_enemies.draco.draco-base-black',
    'spr_enemies.draco.draco-base-brown',
    'spr_enemies.draco.draco-base-green',
    'spr_enemies.draco.draco-base-grey',
    'spr_enemies.draco.draco-base-mottle',
    'spr_enemies.draco.draco-base-pale',
    'spr_enemies.draco.draco-base-purple',
    'spr_enemies.draco.draco-base-red',
    'spr_enemies.draco.draco-base-white',
    'spr_enemies.draco.draco-base-yellow',
    'spr_enemies.draco.draco-job-annihilator',
    'spr_enemies.draco.draco-job-knight',
    'spr_enemies.draco.draco-job-monk',
    'spr_enemies.draco.draco-job-scorcher',
    'spr_enemies.draco.draco-job-shifter',
    'spr_enemies.draco.draco-job-stormcaller',
    'spr_enemies.dragons.acid_dragon',
    'spr_enemies.dragons.death_drake',
    'spr_enemies.dragons.fire_dragon',
    'spr_enemies.dragons.fire_drake',
    'spr_enemies.dragons.golden_dragon',
    'spr_enemies.dragons.hydra1',
    'spr_enemies.dragons.hydra2',
    'spr_enemies.dragons.hydra3',
    'spr_enemies.dragons.hydra4',
    'spr_enemies.dragons.hydra5',
    'spr_enemies.dragons.ice_dragon',
    'spr_enemies.dragons.iron_dragon',
    'spr_enemies.dragons.lindwurm',
    'spr_enemies.dragons.quicksilver_dragon',
    'spr_enemies.dragons.rime_drake',
    'spr_enemies.dragons.shadow_dragon',
    'spr_enemies.dragons.steam_dragon',
    'spr_enemies.dragons.storm_dragon',
    'spr_enemies.dragons.swamp_dragon',
    'spr_enemies.dragons.swamp_drake',
    'spr_enemies.dragons.wind_drake',
    'spr_enemies.dragons.wyvern',
    'spr_enemies.good_neutral',
    'spr_enemies.humanoid.big_kobold',
    'spr_enemies.humanoid.boggart',
    'spr_enemies.humanoid.centaur',
    'spr_enemies.humanoid.centaur-melee',
    'spr_enemies.humanoid.centaur_warrior',
    'spr_enemies.humanoid.centaur_warrior-melee',
    'spr_enemies.humanoid.cyclops',
    'spr_enemies.humanoid.death_knight',
    'spr_enemies.humanoid.deep_dwarf',
    'spr_enemies.humanoid.deep_elf_annihilator',
    'spr_enemies.humanoid.deep_elf_archer',
    'spr_enemies.humanoid.deep_elf_blademaster',
    'spr_enemies.humanoid.deep_elf_death_mage',
    'spr_enemies.humanoid.deep_elf_demonologist',
    'spr_enemies.humanoid.deep_elf_elementalist',
    'spr_enemies.humanoid.deep_elf_high_priest',
    'spr_enemies.humanoid.deep_elf_knight',
    'spr_enemies.humanoid.deep_elf_mage',
    'spr_enemies.humanoid.deep_elf_master_archer',
    'spr_enemies.humanoid.deep_elf_sorcerer',
    'spr_enemies.humanoid.deep_troll',
    'spr_enemies.humanoid.deep_troll_earth_mage',
    'spr_enemies.humanoid.deep_troll_shaman',
    'spr_enemies.humanoid.demigod',
    'spr_enemies.humanoid.dryad',
    'spr_enemies.humanoid.dwarf',
    'spr_enemies.humanoid.elf',
    'spr_enemies.humanoid.entropy_weaver',
    'spr_enemies.humanoid.ettin',
    'spr_enemies.humanoid.faun',
    'spr_enemies.humanoid.fire_giant',
    'spr_enemies.humanoid.formicid',
    'spr_enemies.humanoid.frost_giant',
    'spr_enemies.humanoid.glowing_orange_brain',
    'spr_enemies.humanoid.glowing_shapeshifter',
    'spr_enemies.humanoid.gnoll',
    'spr_enemies.humanoid.gnoll_sergeant',
    'spr_enemies.humanoid.gnoll_shaman',
    'spr_enemies.humanoid.goblin',
    'spr_enemies.humanoid.guardian_serpent',
    'spr_enemies.humanoid.halfling',
    'spr_enemies.humanoid.harpy',
    'spr_enemies.humanoid.hell_knight',
    'spr_enemies.humanoid.hill_giant',
    'spr_enemies.humanoid.hippogriff',
    'spr_enemies.humanoid.hobgoblin',
    'spr_enemies.humanoid.human',
    'spr_enemies.humanoid.human2',
    'spr_enemies.humanoid.human3',
    'spr_enemies.humanoid.imperial_myrmidon',
    'spr_enemies.humanoid.iron_giant',
    'spr_enemies.humanoid.iron_troll',
    'spr_enemies.humanoid.ironbrand_convoker',
    'spr_enemies.humanoid.ironheart_preserver',
    'spr_enemies.humanoid.juggernaut',
    'spr_enemies.humanoid.killer_klown_blue',
    'spr_enemies.humanoid.killer_klown_green',
    'spr_enemies.humanoid.killer_klown_purple',
    'spr_enemies.humanoid.killer_klown_red',
    'spr_enemies.humanoid.killer_klown_yellow',
    'spr_enemies.humanoid.kobold',
    'spr_enemies.humanoid.kobold_demonologist',
    'spr_enemies.humanoid.manticore',
    'spr_enemies.humanoid.meliai',
    'spr_enemies.humanoid.merfolk',
    'spr_enemies.humanoid.merfolk_aquamancer',
    'spr_enemies.humanoid.merfolk_aquamancer_water',
    'spr_enemies.humanoid.merfolk_avatar',
    'spr_enemies.humanoid.merfolk_avatar_water',
    'spr_enemies.humanoid.merfolk_impaler',
    'spr_enemies.humanoid.merfolk_impaler_water',
    'spr_enemies.humanoid.merfolk_javelineer',
    'spr_enemies.humanoid.merfolk_javelineer_water',
    'spr_enemies.humanoid.merfolk_siren',
    'spr_enemies.humanoid.merfolk_siren_water',
    'spr_enemies.humanoid.merfolk_water',
    'spr_enemies.humanoid.minotaur',
    'spr_enemies.humanoid.naga',
    'spr_enemies.humanoid.naga_mage',
    'spr_enemies.humanoid.naga_ritualist',
    'spr_enemies.humanoid.naga_sharpshooter',
    'spr_enemies.humanoid.naga_warrior',
    'spr_enemies.humanoid.nagaraja',
    'spr_enemies.humanoid.necromancer',
    'spr_enemies.humanoid.ogre',
    'spr_enemies.humanoid.ogre_mage',
    'spr_enemies.humanoid.orb_guardian',
    'spr_enemies.humanoid.orc',
    'spr_enemies.humanoid.orc_high_priest',
    'spr_enemies.humanoid.orc_knight',
    'spr_enemies.humanoid.orc_priest',
    'spr_enemies.humanoid.orc_sorcerer',
    'spr_enemies.humanoid.orc_warlord',
    'spr_enemies.humanoid.orc_warrior',
    'spr_enemies.humanoid.orc_wizard',
    'spr_enemies.humanoid.ragged_hierophant',
    'spr_enemies.humanoid.salamander',
    'spr_enemies.humanoid.salamander_mystic',
    'spr_enemies.humanoid.satyr',
    'spr_enemies.humanoid.servant_of_whispers',
    'spr_enemies.humanoid.shapeshifter',
    'spr_enemies.humanoid.slave',
    'spr_enemies.humanoid.slave_freed',
    'spr_enemies.humanoid.sphinx',
    'spr_enemies.humanoid.stone_giant',
    'spr_enemies.humanoid.tengu',
    'spr_enemies.humanoid.tengu_conjurer',
    'spr_enemies.humanoid.tengu_reaver',
    'spr_enemies.humanoid.tengu_warrior',
    'spr_enemies.humanoid.titan',
    'spr_enemies.humanoid.troll',
    'spr_enemies.humanoid.two_headed_ogre',
    'spr_enemies.humanoid.vault_guard',
    'spr_enemies.humanoid.vault_sentinel',
    'spr_enemies.humanoid.vault_warden',
    'spr_enemies.humanoid.water_nymph',
    'spr_enemies.humanoid.wizard',
    'spr_enemies.humanoid.yaktaur',
    'spr_enemies.humanoid.yaktaur-melee',
    'spr_enemies.humanoid.yaktaur_captain',
    'spr_enemies.humanoid.yaktaur_captain-melee',
    'spr_enemies.undead.ancient_champion',
    'spr_enemies.undead.ancient_lich',
    'spr_enemies.undead.bog_body',
    'spr_enemies.undead.bone_dragon',
    'spr_enemies.undead.crawling_corpse',
    'spr_enemies.undead.curse_skull',
    'spr_enemies.undead.curse_toe',
    'spr_enemies.undead.death_cob',
    'spr_enemies.undead.death_scarab',
    'spr_enemies.undead.drowned_soul',
    'spr_enemies.undead.eidolon',
    'spr_enemies.undead.flayed_ghost',
    'spr_enemies.undead.flying_skull',
    'spr_enemies.undead.freezing_wraith',
    'spr_enemies.undead.ghost',
    'spr_enemies.undead.ghoul',
    'spr_enemies.undead.greater_mummy',
    'spr_enemies.undead.guardian_mummy',
    'spr_enemies.undead.halazid_warlock',
    'spr_enemies.undead.hungry_ghost',
    'spr_enemies.undead.jiangshi',
    'spr_enemies.undead.lich',
    'spr_enemies.undead.lost_soul',
    'spr_enemies.undead.macabre_mass',
    'spr_enemies.undead.missing_ghost',
    'spr_enemies.undead.mummy',
    'spr_enemies.undead.mummy_priest',
    'spr_enemies.undead.necrophage',
    'spr_enemies.undead.phantasmal_warrior',
    'spr_enemies.undead.phantom',
    'spr_enemies.undead.profane_servitor',
    'spr_enemies.undead.revenant',
    'spr_enemies.undead.shadow',
    'spr_enemies.undead.shadow_wraith',
    'spr_enemies.undead.silent_spectre',
    'spr_enemies.undead.skeletal_warrior',
    'spr_enemies.undead.skeleton_bat',
    'spr_enemies.undead.skeleton_bird',
    'spr_enemies.undead.skeleton_centaur',
    'spr_enemies.undead.skeleton_dragon',
    'spr_enemies.undead.skeleton_drake',
    'spr_enemies.undead.skeleton_fish',
    'spr_enemies.undead.skeleton_frog',
    'spr_enemies.undead.skeleton_humanoid_large',
    'spr_enemies.undead.skeleton_humanoid_medium',
    'spr_enemies.undead.skeleton_humanoid_small',
    'spr_enemies.undead.skeleton_hydra1',
    'spr_enemies.undead.skeleton_hydra2',
    'spr_enemies.undead.skeleton_hydra3',
    'spr_enemies.undead.skeleton_hydra4',
    'spr_enemies.undead.skeleton_hydra5',
    'spr_enemies.undead.skeleton_lizard',
    'spr_enemies.undead.skeleton_naga',
    'spr_enemies.undead.skeleton_quadruped_large',
    'spr_enemies.undead.skeleton_quadruped_small',
    'spr_enemies.undead.skeleton_quadruped_winged',
    'spr_enemies.undead.skeleton_snake',
    'spr_enemies.undead.skeleton_troll',
    'spr_enemies.undead.skeleton_turtle',
    'spr_enemies.undead.skeleton_ugly_thing',
    'spr_enemies.undead.spectral_ant',
    'spr_enemies.undead.spectral_bat',
    'spr_enemies.undead.spectral_bee',
    'spr_enemies.undead.spectral_centaur',
    'spr_enemies.undead.spectral_dragon',
    'spr_enemies.undead.spectral_drake',
    'spr_enemies.undead.spectral_fish',
    'spr_enemies.undead.spectral_frog',
    'spr_enemies.undead.spectral_hydra1',
    'spr_enemies.undead.spectral_hydra2',
    'spr_enemies.undead.spectral_hydra3',
    'spr_enemies.undead.spectral_hydra4',
    'spr_enemies.undead.spectral_hydra5',
    'spr_enemies.undead.spectral_kraken',
    'spr_enemies.undead.spectral_large',
    'spr_enemies.undead.spectral_lizard',
    'spr_enemies.undead.spectral_naga',
    'spr_enemies.undead.spectral_quadruped_large',
    'spr_enemies.undead.spectral_quadruped_small',
    'spr_enemies.undead.spectral_small',
    'spr_enemies.undead.spectral_snake',
    'spr_enemies.undead.spectral_spider',
    'spr_enemies.undead.vampire',
    'spr_enemies.undead.vampire_knight',
    'spr_enemies.undead.vampire_mage',
    'spr_enemies.undead.wight',
    'spr_enemies.undead.wraith',
    'spr_enemies.undead.zombie_adder',
    'spr_enemies.undead.zombie_bat',
    'spr_enemies.undead.zombie_bee',
    'spr_enemies.undead.zombie_beetle',
    'spr_enemies.undead.zombie_bird',
    'spr_enemies.undead.zombie_bug',
    'spr_enemies.undead.zombie_centaur',
    'spr_enemies.undead.zombie_crab',
    'spr_enemies.undead.zombie_draconian',
    'spr_enemies.undead.zombie_dragon',
    'spr_enemies.undead.zombie_drake',
    'spr_enemies.undead.zombie_elephant',
    'spr_enemies.undead.zombie_elf',
    'spr_enemies.undead.zombie_fawn',
    'spr_enemies.undead.zombie_fish',
    'spr_enemies.undead.zombie_frog',
    'spr_enemies.undead.zombie_gnoll',
    'spr_enemies.undead.zombie_goblin',
    'spr_enemies.undead.zombie_golden_dragon',
    'spr_enemies.undead.zombie_guardian_serpent',
    'spr_enemies.undead.zombie_harpy',
    'spr_enemies.undead.zombie_hobgoblin',
    'spr_enemies.undead.zombie_hound',
    'spr_enemies.undead.zombie_human',
    'spr_enemies.undead.zombie_hydra1',
    'spr_enemies.undead.zombie_hydra2',
    'spr_enemies.undead.zombie_hydra3',
    'spr_enemies.undead.zombie_hydra4',
    'spr_enemies.undead.zombie_hydra5',
    'spr_enemies.undead.zombie_iron_dragon',
    'spr_enemies.undead.zombie_jackal',
    'spr_enemies.undead.zombie_juggernaut',
    'spr_enemies.undead.zombie_kobold',
    'spr_enemies.undead.zombie_kraken_head',
    'spr_enemies.undead.zombie_large',
    'spr_enemies.undead.zombie_lernaean_hydra01',
    'spr_enemies.undead.zombie_lernaean_hydra02',
    'spr_enemies.undead.zombie_lernaean_hydra03',
    'spr_enemies.undead.zombie_lernaean_hydra04',
    'spr_enemies.undead.zombie_lernaean_hydra05',
    'spr_enemies.undead.zombie_lernaean_hydra06',
    'spr_enemies.undead.zombie_lernaean_hydra07',
    'spr_enemies.undead.zombie_lernaean_hydra08',
    'spr_enemies.undead.zombie_lernaean_hydra09',
    'spr_enemies.undead.zombie_lernaean_hydra10',
    'spr_enemies.undead.zombie_lindwurm',
    'spr_enemies.undead.zombie_lizard',
    'spr_enemies.undead.zombie_merfolk',
    'spr_enemies.undead.zombie_minotaur',
    'spr_enemies.undead.zombie_monkey',
    'spr_enemies.undead.zombie_naga',
    'spr_enemies.undead.zombie_octopode',
    'spr_enemies.undead.zombie_ogre',
    'spr_enemies.undead.zombie_orc',
    'spr_enemies.undead.zombie_quadruped_large',
    'spr_enemies.undead.zombie_quadruped_small',
    'spr_enemies.undead.zombie_quadruped_winged',
    'spr_enemies.undead.zombie_quicksilver_dragon',
    'spr_enemies.undead.zombie_quokka',
    'spr_enemies.undead.zombie_rat',
    'spr_enemies.undead.zombie_roach',
    'spr_enemies.undead.zombie_salamander',
    'spr_enemies.undead.zombie_scorpion',
    'spr_enemies.undead.zombie_small',
    'spr_enemies.undead.zombie_snake',
    'spr_enemies.undead.zombie_spider_large',
    'spr_enemies.undead.zombie_spider_small',
    'spr_enemies.undead.zombie_spriggan',
    'spr_enemies.undead.zombie_troll',
    'spr_enemies.undead.zombie_turtle',
    'spr_enemies.undead.zombie_ugly_thing',
    'spr_enemies.undead.zombie_worm',
    'spr_enemies.undead.zombie_wyvern',
    'spr_enemies.undead.zombie_yaktaur',
    'spr_gamepad.xbox_axis_left_trigger',
    'spr_gamepad.xbox_axis_right_trigger',
    'spr_gamepad.xbox_button_a',
    'spr_gamepad.xbox_button_b',
    'spr_gamepad.xbox_button_back',
    'spr_gamepad.xbox_button_guide',
    'spr_gamepad.xbox_button_left_shoulder',
    'spr_gamepad.xbox_button_right_shoulder',
    'spr_gamepad.xbox_button_start',
    'spr_gamepad.xbox_button_x',
    'spr_gamepad.xbox_button_y',
    'spr_gamepad.xbox_dpad',
    'spr_gamepad.xbox_right_axis_down',
    'spr_gamepad.xbox_right_axis_left',
    'spr_gamepad.xbox_right_axis_right',
    'spr_gamepad.xbox_right_axis_up',
    'spr_gamepad.xbox_right_shoulder',
    'spr_gates.abyssal_stair',
    'spr_gates.bailey_gone',
    'spr_gates.bailey_portal',
    'spr_gates.bazaar_gone',
    'spr_gates.bazaar_portal',
    'spr_gates.chest-closed',
    'spr_gates.chest-open',
    'spr_gates.desolation_portal',
    'spr_gates.desolation_portal_closed',
    'spr_gates.enter',
    'spr_gates.enter_abyss1',
    'spr_gates.enter_abyss2',
    'spr_gates.enter_abyss3',
    'spr_gates.enter_cocytus1',
    'spr_gates.enter_cocytus2',
    'spr_gates.enter_cocytus3',
    'spr_gates.enter_crypt',
    'spr_gates.enter_depths',
    'spr_gates.enter_dis1',
    'spr_gates.enter_dis2',
    'spr_gates.enter_dis3',
    'spr_gates.enter_elf',
    'spr_gates.enter_gehenna1',
    'spr_gates.enter_gehenna2',
    'spr_gates.enter_gehenna3',
    'spr_gates.enter_hell1',
    'spr_gates.enter_hell2',
    'spr_gates.enter_hell3',
    'spr_gates.enter_lair',
    'spr_gates.enter_orc',
    'spr_gates.enter_pandemonium',
    'spr_gates.enter_shoals',
    'spr_gates.enter_slime',
    'spr_gates.enter_snake',
    'spr_gates.enter_spider',
    'spr_gates.enter_swamp',
    'spr_gates.enter_tartarus1',
    'spr_gates.enter_tartarus2',
    'spr_gates.enter_tartarus3',
    'spr_gates.enter_temple',
    'spr_gates.enter_tomb',
    'spr_gates.enter_vaults_closed',
    'spr_gates.enter_vaults_open',
    'spr_gates.enter_zot_closed',
    'spr_gates.enter_zot_open',
    'spr_gates.epic_store',
    'spr_gates.escape_hatch_down',
    'spr_gates.escape_hatch_up',
    'spr_gates.exit_abyss',
    'spr_gates.exit_abyss_flickering',
    'spr_gates.exit_crypt',
    'spr_gates.exit_dungeon',
    'spr_gates.exit_elf',
    'spr_gates.exit_lair',
    'spr_gates.exit_orc',
    'spr_gates.exit_pandemonium',
    'spr_gates.exit_pandemonium_flickering',
    'spr_gates.exit_shoals',
    'spr_gates.exit_slime',
    'spr_gates.exit_snake',
    'spr_gates.exit_spider',
    'spr_gates.exit_swamp',
    'spr_gates.exit_temple',
    'spr_gates.exit_tomb',
    'spr_gates.exit_vaults',
    'spr_gates.expired_portal',
    'spr_gates.ice_cave_gone',
    'spr_gates.ice_cave_portal',
    'spr_gates.lab_gone',
    'spr_gates.lab_portal',
    'spr_gates.ossuary_gone',
    'spr_gates.ossuary_portal',
    'spr_gates.portal',
    'spr_gates.portal_rotated',
    'spr_gates.portal_unknown',
    'spr_gates.return',
    'spr_gates.return_depths',
    'spr_gates.return_hell',
    'spr_gates.return_vestibule',
    'spr_gates.return_zot',
    'spr_gates.sealed_stairs_down',
    'spr_gates.sealed_stairs_up',
    'spr_gates.sewer_portal',
    'spr_gates.sewer_portal_rusted',
    'spr_gates.shoals_stairs_down',
    'spr_gates.shoals_stairs_up',
    'spr_gates.starry_portal',
    'spr_gates.stone_arch',
    'spr_gates.stone_arch_hell',
    'spr_gates.stone_stairs_down',
    'spr_gates.stone_stairs_up',
    'spr_gates.transit_pandemonium',
    'spr_gates.trove_gone',
    'spr_gates.trove_portal',
    'spr_gates.volcano_exit',
    'spr_gates.volcano_gone',
    'spr_gates.volcano_portal',
    'spr_gates.wizlab_gone',
    'spr_gates.wizlab_portal0',
    'spr_gates.wizlab_portal1',
    'spr_gates.wizlab_portal2',
    'spr_gates.wizlab_portal3',
    'spr_gates.wizlab_portal4',
    'spr_gates.wizlab_portal5',
    'spr_gates.wizlab_portal6',
    'spr_gates.wizlab_portal7',
    'spr_gates.zig_portal',
    'spr_gates.zig_used',
    'spr_keys.door01',
    'spr_keys.door02',
    'spr_keys.door03',
    'spr_keys.dragon_key',
    'spr_keys.key01',
    'spr_keys.key02',
    'spr_keys.key03',
    'spr_keys.magentite_door',
    'spr_keys.magentite_key',
    'spr_legwear.gallanthorskirt',
    'spr_legwear.platelegs',
    'spr_legwear.randarts.pants',
    'spr_legwear.randarts.pants2',
    'spr_legwear.randarts.pants3',
    'spr_legwear.randarts.platelegs',
    'spr_legwear.skirt',
    'spr_rings.abolishment',
    'spr_rings.agate',
    'spr_rings.big-skull-ring',
    'spr_rings.brass',
    'spr_rings.bronze',
    'spr_rings.clay',
    'spr_rings.copper',
    'spr_rings.coral',
    'spr_rings.diamond',
    'spr_rings.emerald',
    'spr_rings.ethereal',
    'spr_rings.glass',
    'spr_rings.gold',
    'spr_rings.gold_blue',
    'spr_rings.gold_green',
    'spr_rings.gold_red',
    'spr_rings.granite',
    'spr_rings.iron',
    'spr_rings.ivory',
    'spr_rings.jade',
    'spr_rings.moonstone',
    'spr_rings.opal',
    'spr_rings.pearl',
    'spr_rings.plain_black',
    'spr_rings.plain_red',
    'spr_rings.plain_yellow',
    'spr_rings.randarts.anvil',
    'spr_rings.randarts.blood',
    'spr_rings.randarts.bronze-flower',
    'spr_rings.randarts.dark',
    'spr_rings.randarts.double',
    'spr_rings.randarts.eye',
    'spr_rings.randarts.fire',
    'spr_rings.randarts.flower',
    'spr_rings.randarts.four-colour',
    'spr_rings.randarts.green',
    'spr_rings.randarts.ice',
    'spr_rings.randarts.pink',
    'spr_rings.randarts.red-blue',
    'spr_rings.randarts.snake',
    'spr_rings.randarts.urand_mage',
    'spr_rings.randarts.urand_octoring',
    'spr_rings.randarts.urand_robustness',
    'spr_rings.randarts.urand_shadows',
    'spr_rings.randarts.urand_shaolin',
    'spr_rings.randarts.vampirism',
    'spr_rings.randarts.zircon',
    'spr_rings.ruby',
    'spr_rings.silver',
    'spr_rings.steel',
    'spr_rings.tiger_eye',
    'spr_rings.tourmaline',
    'spr_rings.vampirism',
    'spr_rings.wizardsring',
    'spr_rings.wooden',
    'spr_runes.generic',
    'spr_runes.rune_abyss',
    'spr_runes.rune_cerebov',
    'spr_runes.rune_cocytus',
    'spr_runes.rune_demonic_1',
    'spr_runes.rune_demonic_2',
    'spr_runes.rune_demonic_3',
    'spr_runes.rune_demonic_4',
    'spr_runes.rune_demonic_5',
    'spr_runes.rune_demonic_6',
    'spr_runes.rune_dis',
    'spr_runes.rune_elven',
    'spr_runes.rune_gehenna',
    'spr_runes.rune_gloorx_vloq',
    'spr_runes.rune_lom_lobon',
    'spr_runes.rune_mnoleg',
    'spr_runes.rune_shoals',
    'spr_runes.rune_slime',
    'spr_runes.rune_snake',
    'spr_runes.rune_spider',
    'spr_runes.rune_swamp',
    'spr_runes.rune_tartarus',
    'spr_runes.rune_tomb',
    'spr_runes.rune_vaults',
    'spr_scrolls.acquirement',
    'spr_scrolls.fear',
    'spr_scrolls.identify',
    'spr_scrolls.magic-map',
    'spr_scrolls.red_mana_potion',
    'spr_scrolls.teleportation',
    'spr_scrolls.vulnerability',
    'spr_spells.agony',
    'spr_spells.air_elementals',
    'spr_spells.airstrike',
    'spr_spells.alistairs_intoxication',
    'spr_spells.animate_dead',
    'spr_spells.animate_skeleton',
    'spr_spells.apportation',
    'spr_spells.arrow',
    'spr_spells.bat_form',
    'spr_spells.battlesphere',
    'spr_spells.beastly_appendage',
    'spr_spells.beckoning',
    'spr_spells.beogh',
    'spr_spells.berserker_rage',
    'spr_spells.blade_hands',
    'spr_spells.blink',
    'spr_spells.bolt_corrosive',
    'spr_spells.bolt_explosive',
    'spr_spells.bolt_inacc',
    'spr_spells.bolt_of_cold',
    'spr_spells.bolt_of_draining',
    'spr_spells.bolt_of_fire',
    'spr_spells.bolt_of_magma',
    'spr_spells.bolt_random',
    'spr_spells.bolt_thunder',
    'spr_spells.borgnjors_revivification',
    'spr_spells.brain_feed',
    'spr_spells.breathe_acid',
    'spr_spells.breathe_energy',
    'spr_spells.breathe_fire',
    'spr_spells.breathe_frost',
    'spr_spells.breathe_lightning',
    'spr_spells.breathe_mephitic',
    'spr_spells.breathe_poison',
    'spr_spells.breathe_steam',
    'spr_spells.call_canine_familiar',
    'spr_spells.call_down_damnation',
    'spr_spells.call_imp',
    'spr_spells.cantrip',
    'spr_spells.cause_fear',
    'spr_spells.chain_lightning',
    'spr_spells.chain_lightning2',
    'spr_spells.cigotuvis_embrace',
    'spr_spells.cloud',
    'spr_spells.cloud_cone',
    'spr_spells.cold_breath',
    'spr_spells.confuse',
    'spr_spells.confusing_touch',
    'spr_spells.conjure_ball_lightning',
    'spr_spells.conjure_flame',
    'spr_spells.control_undead',
    'spr_spells.controlled_blink',
    'spr_spells.corona',
    'spr_spells.corpse_rot',
    'spr_spells.darkness',
    'spr_spells.dazzling_spray',
    'spr_spells.death_channel',
    'spr_spells.deaths_door',
    'spr_spells.deflect_missiles',
    'spr_spells.delayed_fireball',
    'spr_spells.dig',
    'spr_spells.discord',
    'spr_spells.disjunction',
    'spr_spells.dispel_undead',
    'spr_spells.dispersal',
    'spr_spells.dragon_form',
    'spr_spells.earth_elementals',
    'spr_spells.end_transformation',
    'spr_spells.enslavement',
    'spr_spells.ensorcelled_hibernation',
    'spr_spells.evoke_berserk',
    'spr_spells.evoke_fog',
    'spr_spells.evoke_invisibility',
    'spr_spells.evoke_invisibility_end',
    'spr_spells.excruciating_wounds',
    'spr_spells.fake_mara_summon',
    'spr_spells.fake_rakshasa_summon',
    'spr_spells.fear_strike',
    'spr_spells.fire_breath',
    'spr_spells.fire_elementals',
    'spr_spells.fire_storm',
    'spr_spells.fireball',
    'spr_spells.flame_tongue',
    'spr_spells.flight',
    'spr_spells.flight_end',
    'spr_spells.force_lance',
    'spr_spells.forgelink',
    'spr_spells.freeze',
    'spr_spells.freezing_cloud',
    'spr_spells.fulminant_prism',
    'spr_spells.gravitas',
    'spr_spells.greaterpain',
    'spr_spells.haste',
    'spr_spells.haste_other',
    'spr_spells.haunt',
    'spr_spells.hurl_damnation',
    'spr_spells.hydra_form',
    'spr_spells.ice_form',
    'spr_spells.ice_storm',
    'spr_spells.iceblast',
    'spr_spells.iceform',
    'spr_spells.ignite_poison',
    'spr_spells.infestation',
    'spr_spells.infusion',
    'spr_spells.inner_flame',
    'spr_spells.invisibility',
    'spr_spells.iron_elementals',
    'spr_spells.iron_shot',
    'spr_spells.irradiate',
    'spr_spells.iskenderuns_mystic_blast',
    'spr_spells.ledas_liquefaction',
    'spr_spells.lees_rapid_deconstruction',
    'spr_spells.lehudibs_crystal_spear',
    'spr_spells.lightning_bolt',
    'spr_spells.ludaze',
    'spr_spells.magic_dart',
    'spr_spells.malign_gateway',
    'spr_spells.manatake',
    'spr_spells.mass_abjuration',
    'spr_spells.mass_confusion',
    'spr_spells.memorise',
    'spr_spells.mephitic_cloud',
    'spr_spells.metabolic_englaciation',
    'spr_spells.metal_splinters',
    'spr_spells.miasma_breath',
    'spr_spells.monstrous_menagerie',
    'spr_spells.necromutation',
    'spr_spells.olgrebs_toxic_radiance',
    'spr_spells.orb_of_destruction',
    'spr_spells.ozocubus_armour',
    'spr_spells.ozocubus_refrigeration',
    'spr_spells.pain',
    'spr_spells.paralyse',
    'spr_spells.passage_of_golubria',
    'spr_spells.passwall',
    'spr_spells.petrify',
    'spr_spells.poison_arrow',
    'spr_spells.poisonous_cloud',
    'spr_spells.polymorph',
    'spr_spells.porkalator',
    'spr_spells.portal_projectile',
    'spr_spells.quicksilver_bolt',
    'spr_spells.recall',
    'spr_spells.recharge',
    'spr_spells.regeneration',
    'spr_spells.repel_missiles',
    'spr_spells.ring_of_flames',
    'spr_spells.sandblast',
    'spr_spells.scattershot',
    'spr_spells.searing_ray',
    'spr_spells.shaft_self',
    'spr_spells.shatter',
    'spr_spells.shock',
    'spr_spells.shroud_of_golubria',
    'spr_spells.silence',
    'spr_spells.simulacrum',
    'spr_spells.skullthrow',
    'spr_spells.sloading',
    'spr_spells.slow',
    'spr_spells.song_of_slaying',
    'spr_spells.spectral_weapon',
    'spr_spells.spell-wall',
    'spr_spells.spell_icon_chain_lightning',
    'spr_spells.spell_icon_inner_fire',
    'spr_spells.spell_icon_lightning_bolt',
    'spr_spells.spell_icon_ring_of_flames',
    'spr_spells.spellforged_servitor',
    'spr_spells.spider_form',
    'spr_spells.spit_acid',
    'spr_spells.spit_poison',
    'spr_spells.static_discharge',
    'spr_spells.statue_form',
    'spr_spells.steam_ball',
    'spr_spells.sticks_to_snakes',
    'spr_spells.sticky_flame',
    'spr_spells.sticky_flame_range',
    'spr_spells.sticky_flame_splash',
    'spr_spells.sting',
    'spr_spells.stone_arrow',
    'spr_spells.stop_recall',
    'spr_spells.stop_singing',
    'spr_spells.sublimation_of_blood',
    'spr_spells.summon',
    'spr_spells.summon_butterflies',
    'spr_spells.summon_demon',
    'spr_spells.summon_dragon',
    'spr_spells.summon_drakes',
    'spr_spells.summon_eyeballs',
    'spr_spells.summon_forest',
    'spr_spells.summon_greater_demon',
    'spr_spells.summon_guardian_golem',
    'spr_spells.summon_hell_beast',
    'spr_spells.summon_horrible_things',
    'spr_spells.summon_hydra',
    'spr_spells.summon_ice_beast',
    'spr_spells.summon_lightning_spire',
    'spr_spells.summon_mana_viper',
    'spr_spells.summon_minor_demon',
    'spr_spells.summon_mushrooms',
    'spr_spells.summon_shadow_creatures',
    'spr_spells.summon_small_mammal',
    'spr_spells.summon_ufetubus',
    'spr_spells.summon_undead',
    'spr_spells.summon_vermin',
    'spr_spells.sure_blade',
    'spr_spells.swiftness',
    'spr_spells.symbol_of_torment',
    'spr_spells.symbol_of_torment2',
    'spr_spells.teleport_other',
    'spr_spells.throw_flame',
    'spr_spells.throw_frost',
    'spr_spells.throw_icicle',
    'spr_spells.tornado',
    'spr_spells.tukimas_dance',
    'spr_spells.twisted_resurrection',
    'spr_spells.unlink',
    'spr_spells.vampiric_draining',
    'spr_spells.venom_bolt',
    'spr_spells.violent_unravelling',
    'spr_spells.water_elementals',
    'spr_weapons.arbalest1',
    'spr_weapons.arbalest2',
    'spr_weapons.arbalest3',
    'spr_weapons.arrow1',
    'spr_weapons.arrow2',
    'spr_weapons.bardiche1',
    'spr_weapons.bardiche2',
    'spr_weapons.bardiche3',
    'spr_weapons.battle_axe1',
    'spr_weapons.battle_axe2',
    'spr_weapons.battle_axe3',
    'spr_weapons.blessed_blade',
    'spr_weapons.blowgun1',
    'spr_weapons.blowgun2',
    'spr_weapons.broad_axe1',
    'spr_weapons.broad_axe2',
    'spr_weapons.broad_axe3',
    'spr_weapons.bullwhip',
    'spr_weapons.bullwhip2',
    'spr_weapons.bullwhip3',
    'spr_weapons.club',
    'spr_weapons.club2',
    'spr_weapons.crossbow_bolt1',
    'spr_weapons.crossbow_bolt2',
    'spr_weapons.dagger',
    'spr_weapons.dagger2',
    'spr_weapons.dagger3',
    'spr_weapons.demon_blade',
    'spr_weapons.demon_blade2',
    'spr_weapons.demon_blade3',
    'spr_weapons.demon_trident',
    'spr_weapons.demon_trident2',
    'spr_weapons.demon_trident3',
    'spr_weapons.demon_whip',
    'spr_weapons.demon_whip2',
    'spr_weapons.demon_whip3',
    'spr_weapons.dire_flail1',
    'spr_weapons.dire_flail2',
    'spr_weapons.dire_flail3',
    'spr_weapons.double_sword',
    'spr_weapons.double_sword2',
    'spr_weapons.double_sword3',
    'spr_weapons.epic_staff',
    'spr_weapons.eveningstar1',
    'spr_weapons.eveningstar2',
    'spr_weapons.eveningstar3',
    'spr_weapons.executioner_axe1',
    'spr_weapons.executioner_axe2',
    'spr_weapons.executioner_axe3',
    'spr_weapons.falchion1',
    'spr_weapons.falchion2',
    'spr_weapons.falchion3',
    'spr_weapons.flail1',
    'spr_weapons.flail2',
    'spr_weapons.flail3',
    'spr_weapons.fustibalus',
    'spr_weapons.fustibalus2',
    'spr_weapons.giant_club',
    'spr_weapons.giant_club2',
    'spr_weapons.giant_club3',
    'spr_weapons.giant_spiked_club',
    'spr_weapons.giant_spiked_club2',
    'spr_weapons.giant_spiked_club3',
    'spr_weapons.glaive1',
    'spr_weapons.glaive2',
    'spr_weapons.glaive3',
    'spr_weapons.greatsword1',
    'spr_weapons.greatsword2',
    'spr_weapons.greatsword3',
    'spr_weapons.halberd1',
    'spr_weapons.halberd2',
    'spr_weapons.halberd3',
    'spr_weapons.hand_axe1',
    'spr_weapons.hand_axe2',
    'spr_weapons.hand_axe3',
    'spr_weapons.hand_crossbow',
    'spr_weapons.hand_crossbow2',
    'spr_weapons.hand_crossbow3',
    'spr_weapons.i-antimagic',
    'spr_weapons.i-chaos',
    'spr_weapons.i-confusion',
    'spr_weapons.i-curare',
    'spr_weapons.i-dispersal',
    'spr_weapons.i-distortion',
    'spr_weapons.i-draining',
    'spr_weapons.i-electrocution',
    'spr_weapons.i-evasion',
    'spr_weapons.i-explosion',
    'spr_weapons.i-flaming',
    'spr_weapons.i-freezing',
    'spr_weapons.i-frenzy',
    'spr_weapons.i-holy_wrath',
    'spr_weapons.i-pain',
    'spr_weapons.i-paralysis',
    'spr_weapons.i-penetration',
    'spr_weapons.i-protection',
    'spr_weapons.i-reaping',
    'spr_weapons.i-returning',
    'spr_weapons.i-sickness',
    'spr_weapons.i-sleep',
    'spr_weapons.i-slowing',
    'spr_weapons.i-speed',
    'spr_weapons.i-vampirism',
    'spr_weapons.i-venom',
    'spr_weapons.i-vorpal',
    'spr_weapons.javelin1',
    'spr_weapons.javelin2',
    'spr_weapons.lajatang1',
    'spr_weapons.lajatang2',
    'spr_weapons.lajatang3',
    'spr_weapons.long_sword1',
    'spr_weapons.long_sword2',
    'spr_weapons.long_sword3',
    'spr_weapons.longbow1',
    'spr_weapons.longbow2',
    'spr_weapons.longbow3',
    'spr_weapons.mace1',
    'spr_weapons.mace2',
    'spr_weapons.mace3',
    'spr_weapons.mace_large1',
    'spr_weapons.mace_large2',
    'spr_weapons.mace_large3',
    'spr_weapons.morningstar1',
    'spr_weapons.morningstar2',
    'spr_weapons.morningstar3',
    'spr_weapons.needle-c',
    'spr_weapons.needle-p',
    'spr_weapons.needle1',
    'spr_weapons.needle2',
    'spr_weapons.quarterstaff',
    'spr_weapons.quarterstaff2',
    'spr_weapons.quarterstaff3',
    'spr_weapons.quickblade1',
    'spr_weapons.quickblade2',
    'spr_weapons.quickblade3',
    'spr_weapons.randart_dagger1',
    'spr_weapons.randart_dagger2',
    'spr_weapons.randart_mace1',
    'spr_weapons.randart_mace2',
    'spr_weapons.randart_mace3',
    'spr_weapons.randart_short_sword1',
    'spr_weapons.randart_short_sword2',
    'spr_weapons.randart_shortbow',
    'spr_weapons.randart_triple_sword1',
    'spr_weapons.randart_triple_sword2',
    'spr_weapons.rapier1',
    'spr_weapons.rapier2',
    'spr_weapons.rapier3',
    'spr_weapons.rock',
    'spr_weapons.sacred_scourge',
    'spr_weapons.scimitar1',
    'spr_weapons.scimitar2',
    'spr_weapons.scimitar3',
    'spr_weapons.scythe1',
    'spr_weapons.scythe2',
    'spr_weapons.scythe3',
    'spr_weapons.short_sword1',
    'spr_weapons.short_sword2',
    'spr_weapons.short_sword3',
    'spr_weapons.shortbow1',
    'spr_weapons.shortbow2',
    'spr_weapons.shortbow3',
    'spr_weapons.silver_arrow1',
    'spr_weapons.silver_arrow2',
    'spr_weapons.silver_crossbow_bolt1',
    'spr_weapons.silver_crossbow_bolt2',
    'spr_weapons.silver_javelin1',
    'spr_weapons.silver_javelin2',
    'spr_weapons.silver_sling_bullet1',
    'spr_weapons.silver_sling_bullet2',
    'spr_weapons.silver_tomahawk',
    'spr_weapons.sling1',
    'spr_weapons.sling2',
    'spr_weapons.sling_bullet1',
    'spr_weapons.sling_bullet2',
    'spr_weapons.spear1',
    'spr_weapons.spear2',
    'spr_weapons.spear3',
    'spr_weapons.spwpn_demon_axe',
    'spr_weapons.spwpn_glaive_of_prune',
    'spr_weapons.spwpn_mace_of_variability',
    'spr_weapons.spwpn_majin',
    'spr_weapons.spwpn_sceptre_of_asmodeus',
    'spr_weapons.spwpn_sceptre_of_torment',
    'spr_weapons.spwpn_scythe_of_curses',
    'spr_weapons.spwpn_singing_sword',
    'spr_weapons.spwpn_staff_of_dispater',
    'spr_weapons.spwpn_staff_of_olgreb',
    'spr_weapons.spwpn_sword_of_cerebov',
    'spr_weapons.spwpn_sword_of_power',
    'spr_weapons.spwpn_sword_of_zonguldrok',
    'spr_weapons.spwpn_vampires_tooth',
    'spr_weapons.spwpn_wrath_of_trog',
    'spr_weapons.spwpn_wucad_mu',
    'spr_weapons.staff',
    'spr_weapons.staff_mummy',
    'spr_weapons.staff_of_elements',
    'spr_weapons.steel_arrow1',
    'spr_weapons.steel_arrow2',
    'spr_weapons.steel_crossbow_bolt1',
    'spr_weapons.steel_crossbow_bolt2',
    'spr_weapons.steel_javelin1',
    'spr_weapons.steel_javelin2',
    'spr_weapons.steel_sling_bullet1',
    'spr_weapons.steel_sling_bullet2',
    'spr_weapons.steel_tomahawk',
    'spr_weapons.stone',
    'spr_weapons.stone0',
    'spr_weapons.stone_randart',
    'spr_weapons.stone_randart2',
    'spr_weapons.stone_randart3',
    'spr_weapons.sword',
    'spr_weapons.throwing_net',
    'spr_weapons.tomahawk1',
    'spr_weapons.tomahawk2',
    'spr_weapons.trident1',
    'spr_weapons.trident2',
    'spr_weapons.trident3',
    'spr_weapons.triple_crossbow',
    'spr_weapons.triple_crossbow2',
    'spr_weapons.triple_sword',
    'spr_weapons.triple_sword2',
    'spr_weapons.triple_sword3',
    'spr_weapons.trishula',
    'spr_weapons.urand_arc_blade',
    'spr_weapons.urand_arga',
    'spr_weapons.urand_axe_of_woe',
    'spr_weapons.urand_bloodbane',
    'spr_weapons.urand_blowgun',
    'spr_weapons.urand_botono',
    'spr_weapons.urand_brilliance',
    'spr_weapons.urand_chilly_death',
    'spr_weapons.urand_crystal_spear',
    'spr_weapons.urand_cutlass',
    'spr_weapons.urand_damnation',
    'spr_weapons.urand_dark_maul',
    'spr_weapons.urand_doom_knight',
    'spr_weapons.urand_elemental',
    'spr_weapons.urand_eos',
    'spr_weapons.urand_finisher',
    'spr_weapons.urand_firestarter',
    'spr_weapons.urand_flaming_death',
    'spr_weapons.urand_frostbite',
    'spr_weapons.urand_guard',
    'spr_weapons.urand_gyre',
    'spr_weapons.urand_jihad',
    'spr_weapons.urand_katana',
    'spr_weapons.urand_knife_of_accuracy',
    'spr_weapons.urand_krishna',
    'spr_weapons.urand_leech',
    'spr_weapons.urand_morg',
    'spr_weapons.urand_octopus_king',
    'spr_weapons.urand_order',
    'spr_weapons.urand_piercer',
    'spr_weapons.urand_plutonium',
    'spr_weapons.urand_punk',
    'spr_weapons.urand_shillelagh',
    'spr_weapons.urand_skullcrusher',
    'spr_weapons.urand_snakebite',
    'spr_weapons.urand_sniper',
    'spr_weapons.urand_spellbinder',
    'spr_weapons.urand_spriggans_knife',
    'spr_weapons.urand_storm_bow',
    'spr_weapons.urand_undeadhunter',
    'spr_weapons.urand_wyrmbane',
    'spr_weapons.war_axe1',
    'spr_weapons.war_axe2',
    'spr_weapons.war_axe3',
}
return M
